// Direction C — Insights Briefing
// Off-white with warmth · Instrument Serif display · Geist body · oxblood accent.
// The dashboard reads like a morning briefing: the AI's observation is the headline,
// the numbers support the story. Less data per square inch, more interpretation.

const C = {
  bg:      '#f6f2ec',
  bg2:     '#ffffff',
  ink:     '#1a1a1a',
  ink2:    '#666058',
  ink3:    '#a39e96',
  rule:    'rgba(26,26,26,0.08)',
  rule2:   'rgba(26,26,26,0.14)',
  accent:  '#8a2f2a',          // oxblood
  accent2: '#c7503e',          // brighter cherry
  good:    '#2f6b3f',
  warn:    '#a85a1a',
  card:    '#ffffff',
};

const cFonts = {
  display: '"Instrument Serif", "Newsreader", Georgia, serif',
  body:    '"Geist", "IBM Plex Sans", system-ui, sans-serif',
  mono:    '"JetBrains Mono", ui-monospace, monospace',
};

function cFmt(n, { sign=false, decimals=2 } = {}) {
  const abs = Math.abs(n).toLocaleString('en-US', { minimumFractionDigits: decimals, maximumFractionDigits: decimals });
  if (sign && n > 0) return '+$' + abs;
  if (n < 0) return '\u2212$' + abs;
  return '$' + abs;
}

function CSpark({ data, width=440, height=60, color=C.ink, fill }) {
  const padX = 2, padY = 6;
  const min = Math.min(...data), max = Math.max(...data);
  const xs = data.map((_, i) => padX + (i * (width - padX*2)) / (data.length - 1));
  const ys = data.map(v => height - padY - ((v - min) / (max - min || 1)) * (height - padY*2));
  const line = xs.map((x, i) => `${i ? 'L' : 'M'} ${x.toFixed(1)} ${ys[i].toFixed(1)}`).join(' ');
  const area = `${line} L ${xs[xs.length-1]} ${height} L ${xs[0]} ${height} Z`;
  return (
    <svg viewBox={`0 0 ${width} ${height}`} style={{ width: '100%', height: 'auto', display: 'block' }}>
      {fill && <path d={area} fill={fill} />}
      <path d={line} stroke={color} strokeWidth="1.5" fill="none" strokeLinecap="round" />
      <circle cx={xs[xs.length-1]} cy={ys[ys.length-1]} r={3} fill={color} />
    </svg>
  );
}

// Big donut for spending by category — the visual centerpiece of the report card
function CDonut({ categories, size=220, stroke=22 }) {
  const r = (size - stroke) / 2;
  const cx = size / 2, cy = size / 2;
  const circ = 2 * Math.PI * r;
  let acc = 0;
  return (
    <svg viewBox={`0 0 ${size} ${size}`} style={{ width: size, height: size, transform: 'rotate(-90deg)' }}>
      <circle cx={cx} cy={cy} r={r} fill="none" stroke={C.rule} strokeWidth={stroke} />
      {categories.map(c => {
        const len = (c.percent / 100) * circ;
        const dasharray = `${len} ${circ - len}`;
        const dashoffset = -acc;
        acc += len;
        return (
          <circle key={c.id} cx={cx} cy={cy} r={r} fill="none"
            stroke={c.color} strokeWidth={stroke}
            strokeDasharray={dasharray} strokeDashoffset={dashoffset}
          />
        );
      })}
    </svg>
  );
}

// A "pull-quote" insight card — large serif headline, supporting body, kbd-style tag
function CInsight({ tag, headline, detail, severity, big }) {
  const sev = {
    warn:    { stripe: C.warn,   tag: C.warn },
    good:    { stripe: C.good,   tag: C.good },
    bad:     { stripe: C.accent, tag: C.accent },
    neutral: { stripe: C.ink3,   tag: C.ink2 },
    info:    { stripe: C.accent2,tag: C.accent2 },
  }[severity] || { stripe: C.ink3, tag: C.ink2 };

  return (
    <article style={{
      background: C.card,
      borderRadius: 14,
      padding: big ? '28px 32px' : '22px 24px',
      border: `1px solid ${C.rule}`,
      boxShadow: '0 1px 0 rgba(26,26,26,0.02)',
      position: 'relative',
      overflow: 'hidden',
    }}>
      <div style={{ position: 'absolute', left: 0, top: 16, bottom: 16, width: 3, background: sev.stripe, borderRadius: 2 }} />
      <div style={{
        display: 'inline-flex', alignItems: 'center', gap: 6,
        font: `500 10px/1 ${cFonts.mono}`,
        color: sev.tag, letterSpacing: '0.16em', textTransform: 'uppercase',
        marginBottom: big ? 18 : 10,
      }}>
        <span>{tag}</span>
      </div>
      <h2 style={{
        margin: 0,
        font: `400 ${big ? 44 : 24}px/${big ? 1.08 : 1.2} ${cFonts.display}`,
        letterSpacing: big ? '-0.025em' : '-0.012em',
        color: C.ink,
        textWrap: 'pretty',
      }}>{headline}</h2>
      <p style={{
        margin: big ? '18px 0 0' : '10px 0 0',
        font: `400 ${big ? 16 : 13.5}px/1.55 ${cFonts.body}`,
        color: C.ink2,
        maxWidth: 640,
      }}>{detail}</p>
    </article>
  );
}

function InsightsBriefing() {
  const d = window.LEDGER_DATA;
  const headline = d.insights[0];
  const supporting = d.insights.slice(1);

  return (
    <div style={{
      width: '100%', minHeight: '100%',
      background: C.bg, color: C.ink,
      font: `400 14px/1.55 ${cFonts.body}`,
      padding: '36px 56px 56px',
      boxSizing: 'border-box',
    }}>
      {/* ───────── briefing nameplate ───────── */}
      <header style={{
        display: 'flex', alignItems: 'center', justifyContent: 'space-between',
        paddingBottom: 14, borderBottom: `1px solid ${C.rule2}`,
      }}>
        <div style={{ display: 'flex', alignItems: 'baseline', gap: 14 }}>
          <span style={{ font: `400 28px/1 ${cFonts.display}`, fontStyle: 'italic' }}>
            The Briefing
          </span>
          <span style={{ font: `400 12px/1 ${cFonts.mono}`, color: C.ink2, letterSpacing: '0.06em' }}>
            morning edition · viernes, 23 enero 2026
          </span>
        </div>
        <div style={{ display: 'flex', alignItems: 'center', gap: 16, font: `400 12px/1 ${cFonts.mono}`, color: C.ink2 }}>
          <span><span style={{ color: C.good }}>●</span> auto-sync on · 35 logged this mes</span>
          <span style={{ color: C.ink3 }}>│</span>
          <span>Carlos M.</span>
          <span style={{
            width: 28, height: 28, borderRadius: '50%',
            background: C.accent, color: '#fff',
            display: 'inline-flex', alignItems: 'center', justifyContent: 'center',
            font: `500 12px/1 ${cFonts.body}`,
          }}>CM</span>
        </div>
      </header>

      {/* ───────── lede ───────── */}
      <div style={{ marginTop: 36, marginBottom: 36 }}>
        <div style={{ font: `500 11px/1 ${cFonts.mono}`, letterSpacing: '0.2em', textTransform: 'uppercase', color: C.accent, marginBottom: 16 }}>
          Lede ·
          <span style={{ color: C.ink2, marginLeft: 6 }}>what to know first</span>
        </div>

        <div style={{ display: 'grid', gridTemplateColumns: '1.5fr 1fr', gap: 56, alignItems: 'start' }}>
          {/* HUGE headline — the AI observation */}
          <div>
            <h1 style={{
              margin: 0,
              font: `400 76px/1.02 ${cFonts.display}`,
              letterSpacing: '-0.028em',
              color: C.ink,
              textWrap: 'balance',
            }}>
              You're on pace to overspend by{' '}
              <em style={{ color: C.accent, fontStyle: 'italic' }}>$312</em>{' '}
              this month.
            </h1>
            <p style={{
              margin: '20px 0 0',
              font: `400 17px/1.55 ${cFonts.body}`,
              color: C.ink2, maxWidth: 620,
            }}>
              At your current rate you'll close January at <strong style={{ color: C.ink, fontWeight: 600 }}>$3,152</strong> —
              about $312 over your $2,800 budget, with 8 days to go. Most of the drift is in Restaurantes
              and Uber Eats: cutting two weekday delivery orders puts you back to neutral.
            </p>
            <div style={{ display: 'flex', gap: 10, marginTop: 22 }}>
              {['See the offending transactions', 'Adjust budget'].map((b, i) => (
                <span key={b} style={{
                  display: 'inline-flex', alignItems: 'center', gap: 6,
                  padding: '8px 14px',
                  background: i === 0 ? C.ink : 'transparent',
                  color: i === 0 ? '#fff' : C.ink,
                  border: i === 0 ? 'none' : `1px solid ${C.rule2}`,
                  borderRadius: 999,
                  font: `500 13px/1 ${cFonts.body}`,
                }}>{b} <span style={{ opacity: 0.5 }}>→</span></span>
              ))}
            </div>
          </div>

          {/* Net worth as a quiet right-rail — the steady backdrop to the daily story */}
          <aside style={{
            background: C.card, borderRadius: 16, padding: 24,
            border: `1px solid ${C.rule}`,
          }}>
            <div style={{ font: `500 10px/1 ${cFonts.mono}`, letterSpacing: '0.18em', textTransform: 'uppercase', color: C.ink2, marginBottom: 10 }}>
              Patrimonio neto
            </div>
            <div style={{ display: 'flex', alignItems: 'baseline', gap: 10 }}>
              <span style={{ font: `400 56px/1 ${cFonts.display}`, letterSpacing: '-0.02em' }}>
                $12,450
              </span>
              <span style={{ font: `500 14px/1 ${cFonts.mono}`, color: C.good }}>+2.56%</span>
            </div>
            <div style={{ font: `400 13px/1 ${cFonts.body}`, color: C.ink2, marginTop: 4 }}>
              +$310.50 desde diciembre
            </div>
            <div style={{ marginTop: 14, marginBottom: 6 }}>
              <CSpark data={d.netWorth.series} width={400} height={64} color={C.accent} fill="rgba(138,47,42,0.07)" />
            </div>
            <div style={{
              display: 'flex', justifyContent: 'space-between',
              font: `400 10px/1 ${cFonts.mono}`,
              color: C.ink3,
            }}>
              <span>feb '25</span><span>ene '26</span>
            </div>
            <hr style={{ border: 0, borderTop: `1px solid ${C.rule}`, margin: '16px 0' }} />
            <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 16, fontSize: 12 }}>
              <div>
                <div style={{ color: C.ink3, font: `500 9px/1 ${cFonts.mono}`, letterSpacing: '0.16em', textTransform: 'uppercase' }}>ytd</div>
                <div style={{ font: `500 16px/1.2 ${cFonts.mono}`, color: C.good, marginTop: 4 }}>+$2,630</div>
              </div>
              <div>
                <div style={{ color: C.ink3, font: `500 9px/1 ${cFonts.mono}`, letterSpacing: '0.16em', textTransform: 'uppercase' }}>tasa ahorro</div>
                <div style={{ font: `500 16px/1.2 ${cFonts.mono}`, color: C.good, marginTop: 4 }}>44.3%</div>
              </div>
            </div>
          </aside>
        </div>
      </div>

      {/* ───────── more observations ───────── */}
      <section style={{ marginBottom: 40 }}>
        <div style={{ font: `500 11px/1 ${cFonts.mono}`, letterSpacing: '0.2em', textTransform: 'uppercase', color: C.accent, marginBottom: 16 }}>
          Also worth knowing
        </div>
        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(3, 1fr)', gap: 20 }}>
          {supporting.map(ins => (
            <CInsight key={ins.tag} {...ins} />
          ))}
        </div>
      </section>

      {/* ───────── the report card ───────── */}
      <section style={{ marginBottom: 40 }}>
        <div style={{ font: `500 11px/1 ${cFonts.mono}`, letterSpacing: '0.2em', textTransform: 'uppercase', color: C.accent, marginBottom: 16 }}>
          The report · January
        </div>
        <div style={{
          background: C.card, borderRadius: 18, border: `1px solid ${C.rule}`,
          padding: 28,
          display: 'grid', gridTemplateColumns: '260px 1fr', gap: 36, alignItems: 'center',
        }}>
          {/* big donut */}
          <div style={{ position: 'relative', display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
            <CDonut categories={d.categories} size={240} stroke={26} />
            <div style={{ position: 'absolute', inset: 0, display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center' }}>
              <div style={{ font: `500 9px/1 ${cFonts.mono}`, letterSpacing: '0.18em', textTransform: 'uppercase', color: C.ink3 }}>gastado en enero</div>
              <div style={{ font: `400 36px/1 ${cFonts.display}`, color: C.ink, marginTop: 8 }}>$2,340</div>
              <div style={{ font: `500 11px/1 ${cFonts.mono}`, color: C.warn, marginTop: 6 }}>83.6% del presupuesto</div>
            </div>
          </div>

          {/* category list */}
          <div>
            <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '6px 32px' }}>
              {d.categories.map(c => {
                const diff = ((c.amount - c.prevMonth) / c.prevMonth) * 100;
                return (
                  <div key={c.id} style={{
                    display: 'grid', gridTemplateColumns: '12px 1fr auto auto', alignItems: 'center', gap: 10,
                    padding: '8px 0', borderBottom: `1px solid ${C.rule}`,
                  }}>
                    <span style={{ width: 10, height: 10, borderRadius: 3, background: c.color }} />
                    <span style={{ color: C.ink, fontSize: 14 }}>{c.name}</span>
                    <span style={{
                      font: `500 11px/1 ${cFonts.mono}`,
                      color: diff > 0 ? C.warn : diff < 0 ? C.good : C.ink3,
                      fontVariantNumeric: 'tabular-nums',
                    }}>
                      {diff > 0 ? '↑' : diff < 0 ? '↓' : '·'} {Math.abs(diff).toFixed(0)}%
                    </span>
                    <span style={{
                      font: `500 14px/1 ${cFonts.mono}`,
                      color: C.ink, fontVariantNumeric: 'tabular-nums',
                      minWidth: 64, textAlign: 'right',
                    }}>${c.amount.toFixed(0)}</span>
                  </div>
                );
              })}
            </div>
            <div style={{ display: 'flex', justifyContent: 'space-between', marginTop: 16, font: `400 12px/1 ${cFonts.body}`, color: C.ink2 }}>
              <span>63 transacciones</span>
              <span>presupuesto restante: <strong style={{ color: C.ink, fontWeight: 600 }}>$459.50</strong> · 8 días</span>
            </div>
          </div>
        </div>
      </section>

      {/* ───────── two-up: automation hero + accounts ───────── */}
      <section style={{ display: 'grid', gridTemplateColumns: '1fr 1.3fr', gap: 20, marginBottom: 40 }}>
        {/* Automation — the differentiator gets a real moment */}
        <div style={{
          background: C.ink, color: '#f6f2ec', borderRadius: 18, padding: 28,
          position: 'relative', overflow: 'hidden',
        }}>
          <div style={{ font: `500 10px/1 ${cFonts.mono}`, letterSpacing: '0.2em', textTransform: 'uppercase', color: 'rgba(246,242,236,0.6)', marginBottom: 16 }}>
            Automation
          </div>
          <h3 style={{
            margin: 0, font: `400 30px/1.15 ${cFonts.display}`, letterSpacing: '-0.018em', textWrap: 'pretty',
          }}>
            <em style={{ color: '#e8b75c', fontStyle: 'italic' }}>35</em> of <em style={{ fontStyle: 'italic' }}>63</em> transactions this month logged themselves.
          </h3>
          <p style={{ margin: '14px 0 0', color: 'rgba(246,242,236,0.7)', fontSize: 13.5, lineHeight: 1.55 }}>
            55.6% capture rate. You spent zero minutes typing them in.
          </p>
          <div style={{ marginTop: 22, display: 'grid', gap: 10 }}>
            {[
              { name: 'WhatsApp', count: 24, last: '2 min ago', color: '#25D366' },
              { name: 'Email forwarding', count: 11, last: '12 min ago', color: '#e8b75c' },
            ].map(ch => (
              <div key={ch.name} style={{
                display: 'flex', alignItems: 'center', gap: 12,
                padding: '10px 14px',
                background: 'rgba(255,255,255,0.06)', borderRadius: 10,
              }}>
                <span style={{ width: 8, height: 8, borderRadius: '50%', background: ch.color, boxShadow: `0 0 0 4px ${ch.color}22` }} />
                <span style={{ fontSize: 14 }}>{ch.name}</span>
                <span style={{ flex: 1 }} />
                <span style={{ font: `500 14px/1 ${cFonts.mono}`, color: '#fff' }}>{ch.count}</span>
                <span style={{ font: `400 11px/1 ${cFonts.mono}`, color: 'rgba(246,242,236,0.5)' }}>{ch.last}</span>
              </div>
            ))}
          </div>
          {/* decorative dot grid */}
          <div style={{ position: 'absolute', right: -40, bottom: -40, width: 160, height: 160, opacity: 0.08,
            backgroundImage: 'radial-gradient(circle, #e8b75c 1.5px, transparent 1.5px)', backgroundSize: '12px 12px' }} />
        </div>

        {/* Accounts — bento-ish */}
        <div>
          <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'baseline', marginBottom: 12 }}>
            <div style={{ font: `500 11px/1 ${cFonts.mono}`, letterSpacing: '0.2em', textTransform: 'uppercase', color: C.accent }}>
              Cuentas
            </div>
            <div style={{ font: `400 12px/1 ${cFonts.body}`, color: C.ink2 }}>
              4 activas · total <strong style={{ color: C.ink, fontFamily: cFonts.mono, fontWeight: 500 }}>$10,449.20</strong>
            </div>
          </div>
          <div style={{ display: 'grid', gridTemplateColumns: 'repeat(2, 1fr)', gap: 14 }}>
            {d.accounts.map(a => {
              const debt = a.type === 'credit_card' || a.type === 'loan';
              const label = { checking: 'Cuenta corriente', savings: 'Ahorros', credit_card: 'Tarjeta de crédito', wallet: 'Efectivo', loan: 'Préstamo' }[a.type];
              return (
                <div key={a.id} style={{
                  background: C.card, borderRadius: 14, border: `1px solid ${C.rule}`,
                  padding: '18px 20px',
                }}>
                  <div style={{
                    display: 'flex', justifyContent: 'space-between', alignItems: 'baseline',
                  }}>
                    <div>
                      <div style={{ font: `500 10px/1 ${cFonts.mono}`, letterSpacing: '0.14em', textTransform: 'uppercase', color: C.ink3 }}>
                        {label}
                      </div>
                      <div style={{ font: `400 18px/1.2 ${cFonts.display}`, color: C.ink, marginTop: 4 }}>{a.name}</div>
                      <div style={{ font: `400 12px/1 ${cFonts.body}`, color: C.ink2, marginTop: 2 }}>
                        {a.bank || 'Efectivo'}{a.last4 ? ` ····${a.last4}` : ''}
                      </div>
                    </div>
                  </div>
                  <div style={{
                    font: `400 30px/1 ${cFonts.display}`,
                    color: debt ? C.accent : C.ink,
                    marginTop: 16, letterSpacing: '-0.01em',
                  }}>
                    {debt ? '\u2212' : ''}${Math.abs(a.balance).toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
                  </div>
                  <div style={{
                    font: `500 12px/1 ${cFonts.mono}`,
                    color: a.change > 0 ? C.good : a.change < 0 ? C.accent : C.ink3,
                    marginTop: 6,
                  }}>
                    {a.change > 0 ? '↑' : a.change < 0 ? '↓' : '·'} {cFmt(a.change, { sign: true })} este mes
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      </section>

      {/* ───────── recent in plain language ───────── */}
      <section>
        <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'baseline', marginBottom: 12 }}>
          <div style={{ font: `500 11px/1 ${cFonts.mono}`, letterSpacing: '0.2em', textTransform: 'uppercase', color: C.accent }}>
            Movimientos recientes
          </div>
          <span style={{ font: `500 12px/1 ${cFonts.body}`, color: C.ink2 }}>Ver todos →</span>
        </div>
        <div style={{
          background: C.card, borderRadius: 16, border: `1px solid ${C.rule}`, overflow: 'hidden',
        }}>
          {d.transactions.slice(0, 6).map((t, i) => {
            const isInc = t.amount > 0;
            return (
              <div key={t.id} style={{
                display: 'grid',
                gridTemplateColumns: '52px 1fr auto 110px',
                gap: 18, alignItems: 'center',
                padding: '16px 22px',
                borderTop: i === 0 ? 'none' : `1px solid ${C.rule}`,
              }}>
                <div style={{
                  width: 40, height: 40, borderRadius: 10,
                  background: isInc ? 'rgba(47,107,63,0.08)' : 'rgba(138,47,42,0.06)',
                  color: isInc ? C.good : C.accent,
                  display: 'flex', alignItems: 'center', justifyContent: 'center',
                  font: `500 16px/1 ${cFonts.mono}`,
                }}>{isInc ? '↗' : '↙'}</div>
                <div>
                  <div style={{ font: `400 17px/1.2 ${cFonts.display}`, color: C.ink }}>{t.desc}</div>
                  <div style={{ font: `400 12px/1.3 ${cFonts.body}`, color: C.ink2, marginTop: 3 }}>
                    {t.cat} · {t.account} · {t.date.slice(5)} {t.time}
                  </div>
                </div>
                <div>
                  {t.source !== 'manual' ? (
                    <span style={{
                      font: `500 10px/1 ${cFonts.mono}`,
                      letterSpacing: '0.1em', textTransform: 'uppercase',
                      padding: '5px 9px', borderRadius: 999,
                      background: t.source === 'whatsapp' ? 'rgba(37,211,102,0.1)' : 'rgba(232,183,92,0.14)',
                      color: t.source === 'whatsapp' ? '#1ba858' : '#b88842',
                    }}>● auto · {t.source}</span>
                  ) : (
                    <span style={{ font: `500 10px/1 ${cFonts.mono}`, color: C.ink3, letterSpacing: '0.1em', textTransform: 'uppercase' }}>manual</span>
                  )}
                </div>
                <div style={{
                  textAlign: 'right',
                  font: `500 18px/1 ${cFonts.mono}`,
                  color: isInc ? C.good : C.ink,
                  fontVariantNumeric: 'tabular-nums',
                }}>{isInc ? '+' : '\u2212'}${Math.abs(t.amount).toFixed(2)}</div>
              </div>
            );
          })}
        </div>
      </section>

      <div style={{
        marginTop: 36, paddingTop: 16, borderTop: `1px solid ${C.rule2}`,
        display: 'flex', justifyContent: 'space-between',
        font: `400 11px/1 ${cFonts.mono}`, color: C.ink3, letterSpacing: '0.06em',
      }}>
        <span>generated by Claude · 23 enero, 06:01</span>
        <span>next briefing tomorrow, 06:00</span>
      </div>
    </div>
  );
}

window.InsightsBriefing = InsightsBriefing;
