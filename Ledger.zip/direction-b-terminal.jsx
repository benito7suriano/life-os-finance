// Direction B — Terminal Pro
// Warm-dark · JetBrains Mono everywhere · ASCII box drawing · pro-tool density.
// Inspiration: btop, k9s, neofetch, a really nice .tmux.conf.

const B = {
  bg:      '#0f0e0a',
  bg2:     '#171510',
  bg3:     '#1f1c15',
  fg:      '#d8d2c0',
  fg2:     '#8e8674',
  fg3:     '#5a5446',
  rule:    '#2a2620',
  accent:  '#e8b75c',   // amber prompt
  good:    '#7cba6a',   // soft terminal green
  bad:     '#e07a5f',   // muted coral
  warn:    '#e8b75c',
  cyan:    '#7ec8c4',
  magenta: '#c08aaa',
};

const bFonts = {
  mono: '"JetBrains Mono", "IBM Plex Mono", ui-monospace, monospace',
  sans: '"IBM Plex Sans", system-ui, sans-serif',
};

function bFmt(n, { decimals=2, sign=false } = {}) {
  const abs = Math.abs(n).toLocaleString('en-US', { minimumFractionDigits: decimals, maximumFractionDigits: decimals });
  if (sign && n > 0) return '+' + abs;
  if (n < 0) return '-' + abs;
  return abs;
}

// A box-drawing panel with a heading like ┌─ NET WORTH ───────┐
function BPanel({ title, right, children, style={}, accent }) {
  const ac = accent || B.fg3;
  return (
    <div style={{
      border: `1px solid ${B.rule}`,
      background: B.bg2,
      borderRadius: 4,
      padding: '14px 16px 16px',
      position: 'relative',
      ...style,
    }}>
      <div style={{
        position: 'absolute', top: -8, left: 12, right: 12,
        display: 'flex', alignItems: 'center', gap: 8,
        background: B.bg, padding: '0 6px',
        font: `500 10.5px/1 ${bFonts.mono}`,
        color: ac, letterSpacing: '0.14em', textTransform: 'uppercase',
      }}>
        <span style={{ color: B.fg3 }}>┌─</span>
        <span>{title}</span>
        <span style={{ color: B.fg3, flex: 1, letterSpacing: 0 }}>
          {'─'.repeat(120)}
        </span>
        {right && <span style={{ color: B.fg3, fontSize: 10, letterSpacing: '0.08em' }}>{right}</span>}
        <span style={{ color: B.fg3 }}>─┐</span>
      </div>
      {children}
    </div>
  );
}

// Sparkline rendered as block characters - feels terminal-native
function BBlockSpark({ data, color, width=60 }) {
  const blocks = ['▁','▂','▃','▄','▅','▆','▇','█'];
  const min = Math.min(...data), max = Math.max(...data);
  const out = data.slice(-width).map(v => {
    const t = (v - min) / (max - min || 1);
    return blocks[Math.round(t * 7)];
  }).join('');
  return <span style={{ color, font: `400 14px/1 ${bFonts.mono}`, letterSpacing: 0 }}>{out}</span>;
}

// Smooth SVG sparkline for net-worth hero
function BSparkSVG({ data, width=920, height=130, color=B.accent }) {
  const padX = 4, padY = 8;
  const min = Math.min(...data), max = Math.max(...data);
  const xs = data.map((_, i) => padX + (i * (width - padX*2)) / (data.length - 1));
  const ys = data.map(v => height - padY - ((v - min) / (max - min || 1)) * (height - padY*2));
  const linePath = xs.map((x, i) => `${i ? 'L' : 'M'} ${x.toFixed(1)} ${ys[i].toFixed(1)}`).join(' ');
  const areaPath = `${linePath} L ${xs[xs.length-1]} ${height-padY} L ${xs[0]} ${height-padY} Z`;
  return (
    <svg viewBox={`0 0 ${width} ${height}`} style={{ width: '100%', height: 'auto', display: 'block' }}>
      <defs>
        <linearGradient id="b-spark-grad" x1="0" y1="0" x2="0" y2="1">
          <stop offset="0%" stopColor={color} stopOpacity="0.22" />
          <stop offset="100%" stopColor={color} stopOpacity="0" />
        </linearGradient>
      </defs>
      {/* grid */}
      {[0.25,0.5,0.75].map(g => (
        <line key={g} x1={0} x2={width} y1={padY + (height-padY*2)*g} y2={padY + (height-padY*2)*g} stroke={B.rule} strokeDasharray="2 4" />
      ))}
      <path d={areaPath} fill="url(#b-spark-grad)" />
      <path d={linePath} stroke={color} strokeWidth="1.5" fill="none" />
      {xs.map((x, i) => (
        <circle key={i} cx={x} cy={ys[i]} r={i === xs.length-1 ? 3 : 1.5} fill={i === xs.length-1 ? color : B.fg3} />
      ))}
    </svg>
  );
}

// Horizontal bar with terminal block characters
function BTerminalBar({ pct, color, width=24 }) {
  const filled = Math.round((pct/100) * width);
  return (
    <span style={{ font: `400 12px/1 ${bFonts.mono}`, letterSpacing: 0 }}>
      <span style={{ color }}>{'█'.repeat(filled)}</span>
      <span style={{ color: B.rule }}>{'░'.repeat(width - filled)}</span>
    </span>
  );
}

function TerminalPro() {
  const d = window.LEDGER_DATA;
  return (
    <div style={{
      width: '100%', minHeight: '100%',
      background: B.bg, color: B.fg,
      font: `400 13px/1.5 ${bFonts.mono}`,
      padding: '20px 24px 28px',
      boxSizing: 'border-box',
    }}>
      {/* ───────── prompt line + tabs ───────── */}
      <header style={{
        display: 'flex', alignItems: 'center', gap: 14,
        paddingBottom: 14, borderBottom: `1px solid ${B.rule}`,
        font: `400 13px/1 ${bFonts.mono}`,
      }}>
        <span style={{ color: B.accent }}>carlos@ledger</span>
        <span style={{ color: B.fg2 }}>:</span>
        <span style={{ color: B.cyan }}>~/finanzas</span>
        <span style={{ color: B.fg2 }}>$</span>
        <span style={{ color: B.fg }}>ledger dashboard --month=jan26</span>
        <span style={{ flex: 1 }} />
        <span style={{ color: B.fg2 }}>[{d.asOf}]</span>
        <span style={{ color: B.good }}>● online</span>
        <span style={{ color: B.fg3 }}>│</span>
        <span style={{ color: B.fg2 }}>sync:</span>
        <span style={{ color: B.good }}>2m ago</span>
      </header>

      {/* ───────── nav row of tabs/keys ───────── */}
      <div style={{
        display: 'flex', gap: 0, marginTop: 14, marginBottom: 18,
        font: `500 11px/1 ${bFonts.mono}`, letterSpacing: '0.06em',
      }}>
        {[
          { k: '1', label: 'DASHBOARD', active: true },
          { k: '2', label: 'TXNS' },
          { k: '3', label: 'ACCOUNTS' },
          { k: '4', label: 'BUDGETS' },
          { k: '5', label: 'AUTO' },
          { k: '6', label: 'CATS' },
        ].map(t => (
          <span key={t.k} style={{
            display: 'flex', alignItems: 'center', gap: 6,
            padding: '6px 14px',
            border: `1px solid ${t.active ? B.accent : B.rule}`,
            color: t.active ? B.accent : B.fg2,
            background: t.active ? 'rgba(232,183,92,0.05)' : 'transparent',
            marginRight: -1,
          }}>
            <span style={{ color: t.active ? B.accent : B.fg3 }}>[{t.k}]</span>
            <span>{t.label}</span>
          </span>
        ))}
        <span style={{ flex: 1 }} />
        <span style={{ display: 'flex', gap: 14, color: B.fg2, alignItems: 'center' }}>
          <span><span style={{ color: B.fg3 }}>n</span> new</span>
          <span><span style={{ color: B.fg3 }}>/</span> search</span>
          <span><span style={{ color: B.fg3 }}>?</span> help</span>
        </span>
      </div>

      {/* ───────── hero net worth ───────── */}
      <BPanel title="net_worth.usd" right={`series ▷ 12mo`} accent={B.accent}>
        <div style={{ display: 'grid', gridTemplateColumns: '1fr 280px', gap: 28, alignItems: 'center', marginTop: 4 }}>
          <div>
            <div style={{ display: 'flex', alignItems: 'baseline', gap: 16 }}>
              <span style={{ font: `500 56px/1 ${bFonts.mono}`, color: B.fg, fontVariantNumeric: 'tabular-nums', letterSpacing: '-0.02em' }}>
                $12,450.<span style={{ color: B.fg2 }}>00</span>
              </span>
              <span style={{ color: B.good, fontSize: 14 }}>
                ▲ +$310.50 <span style={{ color: B.fg2 }}>(+2.56% MoM)</span>
              </span>
            </div>
            <div style={{ marginTop: 14 }}>
              <BSparkSVG data={d.netWorth.series} width={820} height={120} color={B.accent} />
              <div style={{
                display: 'flex', justifyContent: 'space-between',
                font: `400 10px/1 ${bFonts.mono}`,
                color: B.fg3, marginTop: 4,
              }}>
                {d.netWorth.labels.map(l => <span key={l}>{l.toLowerCase()}</span>)}
              </div>
            </div>
          </div>
          {/* mini stats — vertical, key=value */}
          <div style={{ display: 'flex', flexDirection: 'column', gap: 4, font: `400 12px/1.4 ${bFonts.mono}`, paddingLeft: 18, borderLeft: `1px solid ${B.rule}` }}>
            {[
              ['min_12mo',  '$9,820.00',  B.fg2],
              ['max_12mo',  '$12,450.00', B.fg],
              ['avg_12mo',  '$10,925.79', B.fg2],
              ['delta_ytd', '+$2,630.00', B.good],
              ['delta_pct', '+26.78%',    B.good],
              ['volatility','σ 3.4%',     B.fg2],
            ].map(([k,v,c]) => (
              <div key={k} style={{ display: 'flex', justifyContent: 'space-between' }}>
                <span style={{ color: B.fg3 }}>{k}</span>
                <span style={{ color: c, fontVariantNumeric: 'tabular-nums' }}>{v}</span>
              </div>
            ))}
          </div>
        </div>
      </BPanel>

      {/* ───────── 3-col KPI row ───────── */}
      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(3, 1fr)', gap: 24, marginTop: 28 }}>
        {[
          {
            title: 'income.january',
            big: '+$4,200.00',
            color: B.good,
            sub: 'salario · 1 depósito',
            bar: ['INCOME', 100, B.good],
            note: 'paycheck #2 of 2 received',
            sparkData: [3800, 4200, 4200, 4450, 4200, 5800, 4200],
          },
          {
            title: 'expenses.january',
            big: '-$2,340.50',
            color: B.bad,
            sub: '63 transactions · 8 days left',
            bar: ['SPENT vs BUDGET', 83.6, B.warn],
            note: 'pace: $3,152 by month end',
            sparkData: [2050, 2320, 2180, 2890, 3450, 2340.5],
          },
          {
            title: 'savings_rate',
            big: '44.3%',
            color: B.good,
            sub: '$1,859.50 saved',
            bar: ['VS TARGET 35%', 100, B.good],
            note: 'best rate since aug 2025',
            sparkData: [42, 39, 41, 31, 28, 44.3],
          },
        ].map((k, i) => (
          <BPanel key={i} title={k.title} accent={k.color}>
            <div style={{ display: 'flex', alignItems: 'baseline', gap: 10, marginTop: 4 }}>
              <span style={{ font: `500 26px/1 ${bFonts.mono}`, color: k.color, fontVariantNumeric: 'tabular-nums' }}>
                {k.big}
              </span>
              <BBlockSpark data={k.sparkData} color={k.color} width={k.sparkData.length} />
            </div>
            <div style={{ color: B.fg2, marginTop: 8, fontSize: 12 }}>{k.sub}</div>
            <div style={{ marginTop: 12, display: 'flex', alignItems: 'center', gap: 10 }}>
              <span style={{ color: B.fg3, fontSize: 10, letterSpacing: '0.08em' }}>{k.bar[0]}</span>
              <BTerminalBar pct={k.bar[1]} color={k.bar[2]} width={22} />
              <span style={{ color: k.bar[2], fontSize: 11 }}>{k.bar[1]}%</span>
            </div>
            <div style={{ marginTop: 10, color: B.fg3, fontSize: 11 }}>
              <span style={{ color: B.accent }}>›</span> {k.note}
            </div>
          </BPanel>
        ))}
      </div>

      {/* ───────── insights stream (log style) ───────── */}
      <div style={{ marginTop: 28 }}>
        <BPanel title="insights.log" right="claude-haiku · 4 events">
          <div style={{ marginTop: 6, fontSize: 12.5 }}>
            {d.insights.map((ins, i) => {
              const tone = ins.severity;
              const lvl = tone === 'warn' ? ['WARN', B.warn] : tone === 'good' ? ['INFO', B.good] : tone === 'bad' ? ['CRIT', B.bad] : ['NOTE', B.cyan];
              const t = ['09:14', '08:32', '07:48', '06:01'][i];
              return (
                <div key={ins.tag} style={{ display: 'grid', gridTemplateColumns: '64px 72px 1fr', gap: 14, padding: '8px 0', borderTop: i ? `1px dashed ${B.rule}` : 'none' }}>
                  <span style={{ color: B.fg3 }}>{t}</span>
                  <span style={{ color: lvl[1], fontWeight: 500 }}>[{lvl[0]}]</span>
                  <span>
                    <span style={{ color: B.fg }}>{ins.headline}</span>
                    <span style={{ color: B.fg2, display: 'block', marginTop: 2, fontSize: 11.5 }}>
                      {ins.detail}
                    </span>
                  </span>
                </div>
              );
            })}
          </div>
        </BPanel>
      </div>

      {/* ───────── two-up: transactions tail + categories + accounts/auto ───────── */}
      <div style={{ display: 'grid', gridTemplateColumns: '1.4fr 1fr', gap: 24, marginTop: 28 }}>
        <BPanel title="transactions.tail" right="last 10">
          <div style={{ marginTop: 6, fontSize: 12, fontVariantNumeric: 'tabular-nums' }}>
            <div style={{ display: 'grid', gridTemplateColumns: '88px 1fr 130px 70px 96px', color: B.fg3, padding: '4px 0', borderBottom: `1px solid ${B.rule}`, fontSize: 10, letterSpacing: '0.08em' }}>
              <span>DATE</span><span>DESCRIPTION</span><span>CATEGORY</span><span>SRC</span><span style={{ textAlign: 'right' }}>AMOUNT</span>
            </div>
            {d.transactions.map((t, i) => {
              const isInc = t.amount > 0;
              const srcColor = { whatsapp: B.good, email: B.cyan, manual: B.fg2 }[t.source];
              return (
                <div key={t.id} style={{ display: 'grid', gridTemplateColumns: '88px 1fr 130px 70px 96px', padding: '6px 0', borderBottom: `1px dotted ${B.rule}`, color: B.fg }}>
                  <span style={{ color: B.fg3 }}>{t.date.slice(5)} {t.time}</span>
                  <span style={{ color: B.fg }}>{t.desc}</span>
                  <span style={{ color: B.fg2 }}>{t.cat}</span>
                  <span style={{ color: srcColor }}>{t.source.toUpperCase()}</span>
                  <span style={{ textAlign: 'right', color: isInc ? B.good : B.fg }}>
                    {isInc ? '+' : '-'}{bFmt(t.amount)}
                  </span>
                </div>
              );
            })}
            <div style={{ color: B.fg3, padding: '6px 0', fontSize: 11 }}>
              <span style={{ color: B.accent }}>›</span> showing 10 of 63 · press <span style={{ color: B.fg }}>[2]</span> to view all
            </div>
          </div>
        </BPanel>

        <div style={{ display: 'flex', flexDirection: 'column', gap: 24 }}>
          <BPanel title="spend.by_category" right="january">
            <div style={{ marginTop: 6 }}>
              {d.categories.map(c => (
                <div key={c.id} style={{ display: 'grid', gridTemplateColumns: '120px 1fr 80px', alignItems: 'center', padding: '5px 0', fontSize: 12 }}>
                  <span style={{ color: B.fg }}>{c.name}</span>
                  <BTerminalBar pct={c.percent * 2.5} color={c.color} width={22} />
                  <span style={{ textAlign: 'right', color: B.fg, fontVariantNumeric: 'tabular-nums' }}>
                    ${c.amount.toFixed(2)}
                  </span>
                </div>
              ))}
            </div>
          </BPanel>

          <BPanel title="auto.channels" right="2 active" accent={B.good}>
            <div style={{ marginTop: 6, fontSize: 12 }}>
              {[
                { name: 'whatsapp', status: 'CONNECTED', count: 24, last: '2m ago', color: B.good },
                { name: 'email',    status: 'CONNECTED', count: 11, last: '12m ago', color: B.good },
              ].map(ch => (
                <div key={ch.name} style={{ display: 'grid', gridTemplateColumns: '90px 110px 1fr auto', gap: 12, padding: '7px 0', borderBottom: `1px dotted ${B.rule}`, alignItems: 'center' }}>
                  <span style={{ color: B.fg }}>{ch.name}</span>
                  <span style={{ color: ch.color, fontSize: 10, letterSpacing: '0.08em' }}>● {ch.status}</span>
                  <span style={{ color: B.fg2, fontSize: 11 }}>{ch.count} txns this month</span>
                  <span style={{ color: B.fg3, fontSize: 11 }}>{ch.last}</span>
                </div>
              ))}
              <div style={{ marginTop: 10, color: B.fg3, fontSize: 11 }}>
                <span style={{ color: B.accent }}>›</span> 35/63 transactions auto-captured (55.6%)
              </div>
            </div>
          </BPanel>

          <BPanel title="accounts.summary" right="4 active">
            <div style={{ marginTop: 6, fontSize: 12 }}>
              {d.accounts.map(a => {
                const debt = a.type === 'credit_card' || a.type === 'loan';
                return (
                  <div key={a.id} style={{ display: 'grid', gridTemplateColumns: '1fr 110px', padding: '6px 0', borderBottom: `1px dotted ${B.rule}` }}>
                    <span>
                      <span style={{ color: B.fg }}>{a.name}</span>
                      <span style={{ color: B.fg3, marginLeft: 6, fontSize: 11 }}>
                        {a.bank ? `· ${a.bank}` : '· efectivo'}{a.last4 ? ` ····${a.last4}` : ''}
                      </span>
                    </span>
                    <span style={{ textAlign: 'right', color: debt ? B.bad : B.fg, fontVariantNumeric: 'tabular-nums' }}>
                      {debt ? '-' : ''}${Math.abs(a.balance).toFixed(2)}
                    </span>
                  </div>
                );
              })}
            </div>
          </BPanel>
        </div>
      </div>

      {/* ───────── status bar ───────── */}
      <div style={{
        marginTop: 24, paddingTop: 12, borderTop: `1px solid ${B.rule}`,
        display: 'flex', gap: 18, fontSize: 11, color: B.fg3,
      }}>
        <span><span style={{ color: B.good }}>●</span> all systems operational</span>
        <span>db: postgres@supabase</span>
        <span>llm: claude-haiku-4-5</span>
        <span style={{ flex: 1 }} />
        <span>q to quit · : to command · ↑↓ navigate</span>
      </div>
    </div>
  );
}

window.TerminalPro = TerminalPro;
