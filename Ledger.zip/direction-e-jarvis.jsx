// Direction E — JARVIS HUD
// Tony Stark's workshop. Cyan holographic chrome on near-black. Radial dials,
// crosshair reticles, corner brackets, technical readouts. The dashboard as a
// threat-assessment board for personal finance.

const E = {
  bg:      '#020812',
  bg2:     '#040d1f',
  panel:   'rgba(8,30,58,0.35)',
  fg:      '#cfeeff',
  fg2:     '#7fb7d8',
  fg3:     '#4a7a98',
  cyan:    '#3fd4ff',
  cyan2:   '#8be8ff',
  amber:   '#ffaa3a',
  red:     '#ff5a5a',
  green:   '#5fffaa',
  rule:    'rgba(63,212,255,0.18)',
  rule2:   'rgba(63,212,255,0.06)',
  glow:    '0 0 12px rgba(63,212,255,0.35)',
};

const eFonts = {
  display: '"Rajdhani", "Orbitron", "Geist", system-ui, sans-serif',
  body:    '"Rajdhani", "Geist", system-ui, sans-serif',
  mono:    '"JetBrains Mono", "Geist Mono", ui-monospace, monospace',
};

function eFmt(n, { decimals=2, sign=false } = {}) {
  const abs = Math.abs(n).toLocaleString('en-US', { minimumFractionDigits: decimals, maximumFractionDigits: decimals });
  if (sign && n > 0) return '+' + abs;
  if (n < 0) return '-' + abs;
  return abs;
}

// Corner brackets that frame any panel — the signature Jarvis chrome
function EBrackets({ size=14, color=E.cyan, thickness=1 }) {
  const s = { stroke: color, strokeWidth: thickness, fill: 'none' };
  return (
    <>
      {/* top-left */}
      <svg width={size} height={size} style={{ position: 'absolute', left: 0, top: 0 }}>
        <path d={`M 0 ${size} L 0 0 L ${size} 0`} {...s} />
      </svg>
      <svg width={size} height={size} style={{ position: 'absolute', right: 0, top: 0 }}>
        <path d={`M 0 0 L ${size} 0 L ${size} ${size}`} {...s} />
      </svg>
      <svg width={size} height={size} style={{ position: 'absolute', left: 0, bottom: 0 }}>
        <path d={`M 0 0 L 0 ${size} L ${size} ${size}`} {...s} />
      </svg>
      <svg width={size} height={size} style={{ position: 'absolute', right: 0, bottom: 0 }}>
        <path d={`M ${size} 0 L ${size} ${size} L 0 ${size}`} {...s} />
      </svg>
    </>
  );
}

function EPanel({ id, title, right, children, style={}, pad=18 }) {
  return (
    <div style={{
      background: E.panel,
      border: `1px solid ${E.rule}`,
      position: 'relative',
      padding: pad,
      boxShadow: 'inset 0 0 60px rgba(63,212,255,0.04)',
      ...style,
    }}>
      <EBrackets />
      {(title || id) && (
        <div style={{
          display: 'flex', alignItems: 'center', gap: 8, marginBottom: 14,
        }}>
          <span style={{
            font: `500 10px/1 ${eFonts.mono}`,
            color: E.cyan, letterSpacing: '0.18em', textTransform: 'uppercase',
            padding: '3px 8px', border: `1px solid ${E.rule}`,
            background: 'rgba(63,212,255,0.05)',
          }}>{id || '//'}</span>
          {title && (
            <span style={{
              font: `600 13px/1 ${eFonts.display}`,
              color: E.fg, letterSpacing: '0.14em', textTransform: 'uppercase',
            }}>{title}</span>
          )}
          <span style={{ flex: 1, height: 1, borderTop: `1px dashed ${E.rule}` }} />
          {right && (
            <span style={{ font: `500 10px/1 ${eFonts.mono}`, color: E.fg2, letterSpacing: '0.12em' }}>
              {right}
            </span>
          )}
        </div>
      )}
      {children}
    </div>
  );
}

// Concentric arc gauge — the visual centerpiece
function EArcGauge({ value, label, sub, max=100, size=300, danger=false }) {
  const cx = size / 2, cy = size / 2;
  const r1 = size/2 - 8;  // outer ticks
  const r2 = size/2 - 28; // main arc
  const r3 = size/2 - 56; // inner arc
  const startA = 135, endA = 405; // sweep 270deg
  const sweep = endA - startA;
  const pct = Math.min(value / max, 1.5);

  // ticks every 9 degrees
  const ticks = [];
  for (let a = startA; a <= endA; a += 9) {
    const t = (a - startA) / sweep;
    const major = Math.round(t * 10) % 1 === 0 && Math.abs((t * 10) - Math.round(t * 10)) < 0.01;
    const inner = major ? r1 - 10 : r1 - 5;
    const rad = (a * Math.PI) / 180;
    ticks.push({
      x1: cx + Math.cos(rad) * r1, y1: cy + Math.sin(rad) * r1,
      x2: cx + Math.cos(rad) * inner, y2: cy + Math.sin(rad) * inner,
      strong: major,
    });
  }

  const valueAngle = startA + pct * sweep;
  const arc = (rA, fromA, toA) => {
    const f = (fromA * Math.PI) / 180, t = (toA * Math.PI) / 180;
    const x1 = cx + Math.cos(f) * rA, y1 = cy + Math.sin(f) * rA;
    const x2 = cx + Math.cos(t) * rA, y2 = cy + Math.sin(t) * rA;
    const large = toA - fromA > 180 ? 1 : 0;
    return `M ${x1} ${y1} A ${rA} ${rA} 0 ${large} 1 ${x2} ${y2}`;
  };

  const c = danger ? E.amber : E.cyan;
  return (
    <svg viewBox={`0 0 ${size} ${size}`} style={{ width: '100%', height: 'auto', display: 'block' }}>
      <defs>
        <filter id="e-arc-glow" x="-20%" y="-20%" width="140%" height="140%">
          <feGaussianBlur stdDeviation="2.5" />
          <feMerge><feMergeNode /><feMergeNode in="SourceGraphic" /></feMerge>
        </filter>
      </defs>

      {/* outer faint ring */}
      <circle cx={cx} cy={cy} r={r1+4} stroke={E.rule2} fill="none" />
      <circle cx={cx} cy={cy} r={r1} stroke={E.rule2} fill="none" />

      {/* tick marks */}
      {ticks.map((t, i) => (
        <line key={i} {...t} stroke={t.strong ? c : E.fg3} strokeWidth={t.strong ? 1.5 : 1} opacity={t.strong ? 0.9 : 0.4} />
      ))}

      {/* main arc base */}
      <path d={arc(r2, startA, endA)} stroke={E.rule} strokeWidth="2" fill="none" />
      {/* main arc fill */}
      <path d={arc(r2, startA, valueAngle)} stroke={c} strokeWidth="3" fill="none" filter="url(#e-arc-glow)" />

      {/* inner second ring (danger overflow) */}
      <path d={arc(r3, startA, endA)} stroke={E.rule2} strokeWidth="1" fill="none" />
      {danger && (
        <path d={arc(r3, startA, startA + Math.min(((value-max)/max) * sweep, sweep))} stroke={E.red} strokeWidth="2" fill="none" filter="url(#e-arc-glow)" />
      )}

      {/* center: label + value */}
      <text x={cx} y={cy - 18} textAnchor="middle" fill={E.fg2}
        style={{ font: `500 11px/1 ${eFonts.mono}`, letterSpacing: '0.2em', textTransform: 'uppercase' }}>{label}</text>
      <text x={cx} y={cy + 16} textAnchor="middle" fill={E.fg}
        style={{ font: `500 38px/1 ${eFonts.display}`, letterSpacing: '0.02em' }}>{value}{typeof value === 'number' ? '' : ''}</text>
      <text x={cx} y={cy + 40} textAnchor="middle" fill={c}
        style={{ font: `500 10px/1 ${eFonts.mono}`, letterSpacing: '0.18em', textTransform: 'uppercase' }}>{sub}</text>

      {/* crosshair behind */}
      <line x1={cx} x2={cx} y1={8} y2={20} stroke={c} strokeWidth="1" opacity="0.5" />
      <line x1={cx} x2={cx} y1={size-20} y2={size-8} stroke={c} strokeWidth="1" opacity="0.5" />
    </svg>
  );
}

// Holographic line chart — multi-line with glow
function EHoloChart({ width=600, height=160 }) {
  const series = [
    { color: E.cyan,  data: [40, 50, 45, 60, 55, 75, 65, 90, 80, 100, 92, 124], label: 'NET' },
    { color: E.amber, data: [30, 35, 32, 45, 40, 50, 45, 65, 58, 72, 64, 84],   label: 'OUT' },
  ];
  const padX = 14, padY = 12;
  const max = Math.max(...series.flatMap(s => s.data));
  const xs = series[0].data.map((_, i) => padX + (i * (width - padX*2)) / (series[0].data.length - 1));
  const pathOf = (data) => {
    const ys = data.map(v => height - padY - (v / max) * (height - padY*2));
    let p = `M ${xs[0]} ${ys[0]}`;
    for (let i = 1; i < xs.length; i++) {
      const mx = (xs[i-1] + xs[i]) / 2;
      p += ` C ${mx} ${ys[i-1]}, ${mx} ${ys[i]}, ${xs[i]} ${ys[i]}`;
    }
    return { p, ys };
  };

  return (
    <svg viewBox={`0 0 ${width} ${height}`} style={{ width: '100%', height: 'auto', display: 'block' }}>
      <defs>
        <filter id="e-line-glow"><feGaussianBlur stdDeviation="2" /><feMerge><feMergeNode /><feMergeNode in="SourceGraphic" /></feMerge></filter>
      </defs>
      {/* grid */}
      {[0,1,2,3,4].map(i => {
        const y = padY + (i * (height - padY*2)) / 4;
        return <line key={i} x1={padX} x2={width-padX} y1={y} y2={y} stroke={E.rule2} />;
      })}
      {xs.map((x, i) => (
        <line key={i} x1={x} x2={x} y1={padY} y2={height-padY} stroke={E.rule2} />
      ))}
      {series.map((s, i) => {
        const { p, ys } = pathOf(s.data);
        return (
          <g key={i}>
            <path d={p} stroke={s.color} strokeWidth="1.5" fill="none" filter="url(#e-line-glow)" />
            {xs.map((x, j) => (
              <circle key={j} cx={x} cy={ys[j]} r={j === xs.length-1 ? 4 : 2} fill={E.bg} stroke={s.color} strokeWidth="1.5" />
            ))}
          </g>
        );
      })}
    </svg>
  );
}

// Hexagonal accent block — used as a decorative "module" marker
function EHexBlock({ size=42, color=E.cyan, label }) {
  const w = size, h = size * 0.866;
  return (
    <div style={{ position: 'relative', width: w, height: h, display: 'inline-block' }}>
      <svg viewBox={`0 0 ${w} ${h}`} width={w} height={h} style={{ display: 'block' }}>
        <polygon points={`${w*0.25},0 ${w*0.75},0 ${w},${h*0.5} ${w*0.75},${h} ${w*0.25},${h} 0,${h*0.5}`}
          stroke={color} strokeWidth="1" fill="rgba(63,212,255,0.06)" />
      </svg>
      {label && (
        <span style={{
          position: 'absolute', inset: 0, display: 'flex', alignItems: 'center', justifyContent: 'center',
          font: `600 11px/1 ${eFonts.mono}`, color, letterSpacing: '0.04em',
        }}>{label}</span>
      )}
    </div>
  );
}

function JarvisHUD() {
  const d = window.LEDGER_DATA;

  // 12 categories simulated as targets
  return (
    <div style={{
      width: '100%', minHeight: '100%',
      background: `
        radial-gradient(ellipse 80% 50% at 50% 0%, rgba(63,212,255,0.06), transparent 70%),
        radial-gradient(circle at 50% 50%, rgba(63,212,255,0.025), transparent 60%),
        ${E.bg}
      `,
      color: E.fg,
      font: `400 13px/1.4 ${eFonts.body}`,
      padding: '24px 28px 28px',
      boxSizing: 'border-box',
      position: 'relative',
      overflow: 'hidden',
    }}>
      {/* faint scan-line texture */}
      <div aria-hidden style={{
        position: 'absolute', inset: 0, pointerEvents: 'none',
        backgroundImage: 'repeating-linear-gradient(0deg, rgba(63,212,255,0.04) 0 1px, transparent 1px 3px)',
      }} />
      {/* dot grid */}
      <div aria-hidden style={{
        position: 'absolute', inset: 0, pointerEvents: 'none', opacity: 0.4,
        backgroundImage: 'radial-gradient(rgba(63,212,255,0.12) 1px, transparent 1px)',
        backgroundSize: '32px 32px',
      }} />

      {/* ═════════ top status bar ═════════ */}
      <header style={{
        position: 'relative', zIndex: 1,
        display: 'grid', gridTemplateColumns: 'auto 1fr auto',
        gap: 18, alignItems: 'center',
        paddingBottom: 14, borderBottom: `1px solid ${E.rule}`,
      }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: 12 }}>
          <svg width="32" height="32" viewBox="0 0 40 40">
            <polygon points="20,3 35,12 35,28 20,37 5,28 5,12" stroke={E.cyan} strokeWidth="1.5" fill="rgba(63,212,255,0.08)" />
            <polygon points="20,9 30,14.5 30,25.5 20,31 10,25.5 10,14.5" stroke={E.cyan} strokeWidth="1" fill="none" />
            <circle cx="20" cy="20" r="3" fill={E.cyan} />
          </svg>
          <div>
            <div style={{ font: `600 16px/1 ${eFonts.display}`, color: E.cyan, letterSpacing: '0.3em' }}>L · E · D · G · E · R</div>
            <div style={{ font: `400 10px/1 ${eFonts.mono}`, color: E.fg3, letterSpacing: '0.18em', marginTop: 4 }}>
              FINANCIAL ANALYSIS SYSTEM · v3.1.4
            </div>
          </div>
        </div>

        <div style={{ display: 'flex', justifyContent: 'center', gap: 10 }}>
          {[
            { l: 'OVERVIEW', a: true },
            { l: 'LEDGER' },
            { l: 'ASSETS' },
            { l: 'PROJECTIONS' },
            { l: 'PROTOCOLS' },
          ].map(t => (
            <span key={t.l} style={{
              padding: '5px 14px',
              border: `1px solid ${t.a ? E.cyan : E.rule}`,
              background: t.a ? 'rgba(63,212,255,0.1)' : 'transparent',
              color: t.a ? E.cyan : E.fg2,
              font: `500 11px/1 ${eFonts.mono}`,
              letterSpacing: '0.18em',
              clipPath: 'polygon(8px 0, 100% 0, calc(100% - 8px) 100%, 0 100%)',
            }}>{t.l}</span>
          ))}
        </div>

        <div style={{ display: 'flex', alignItems: 'center', gap: 14, font: `500 11px/1 ${eFonts.mono}`, color: E.fg2 }}>
          <span><span style={{ color: E.green }}>●</span> SYSTEMS NOMINAL</span>
          <span style={{ color: E.fg3 }}>│</span>
          <span style={{ color: E.cyan }}>23·01·2026  </span>
          <span style={{ color: E.cyan, animation: 'none' }}>06:42:17</span>
          <span style={{ color: E.fg3 }}>│</span>
          <span style={{ color: E.cyan }}>OPERATOR: C. MENDOZA</span>
        </div>
      </header>

      {/* ═════════ row: alert banner ═════════ */}
      <div style={{
        position: 'relative', zIndex: 1,
        marginTop: 14, marginBottom: 18,
        padding: '10px 16px',
        border: `1px solid ${E.amber}`,
        background: 'rgba(255,170,58,0.06)',
        display: 'flex', alignItems: 'center', gap: 14,
        font: `500 12px/1 ${eFonts.mono}`,
        letterSpacing: '0.12em',
      }}>
        <span style={{ color: E.amber }}>▲ ADVISORY</span>
        <span style={{ flex: 0, color: E.amber, opacity: 0.6 }}>//</span>
        <span style={{ color: E.fg }}>BUDGET TRAJECTORY EXCEEDING TOLERANCE.</span>
        <span style={{ color: E.fg2 }}>Projected overrun: +$312.00 by 31·01.</span>
        <span style={{ flex: 1 }} />
        <span style={{ color: E.amber }}>RECOMMEND CORRECTIVE ACTION</span>
        <span style={{ color: E.amber }}>›</span>
      </div>

      {/* ═════════ main grid: left | center | right ═════════ */}
      <div style={{
        position: 'relative', zIndex: 1,
        display: 'grid', gridTemplateColumns: '300px 1fr 300px', gap: 16,
      }}>
        {/* ───── LEFT: asset roster ───── */}
        <div style={{ display: 'flex', flexDirection: 'column', gap: 14 }}>
          <EPanel id="01" title="Asset Roster" right="4 ACTIVE">
            {d.accounts.map((a) => {
              const debt = a.type === 'credit_card' || a.type === 'loan';
              return (
                <div key={a.id} style={{
                  padding: '10px 0', borderBottom: `1px dashed ${E.rule2}`,
                  display: 'grid', gridTemplateColumns: '36px 1fr', gap: 10, alignItems: 'center',
                }}>
                  <EHexBlock size={32} color={debt ? E.amber : E.cyan} label={
                    a.type === 'checking' ? 'CH' :
                    a.type === 'savings' ? 'SV' :
                    a.type === 'credit_card' ? 'CC' : 'C$'
                  } />
                  <div>
                    <div style={{ display: 'flex', justifyContent: 'space-between' }}>
                      <span style={{ font: `500 12px/1.2 ${eFonts.display}`, color: E.fg, letterSpacing: '0.06em' }}>{a.name.toUpperCase()}</span>
                      <span style={{ font: `500 13px/1 ${eFonts.mono}`, color: debt ? E.amber : E.fg }}>
                        {debt ? '-' : ''}${Math.abs(a.balance).toFixed(0)}
                      </span>
                    </div>
                    <div style={{ display: 'flex', justifyContent: 'space-between', marginTop: 4 }}>
                      <span style={{ font: `400 10px/1 ${eFonts.mono}`, color: E.fg3, letterSpacing: '0.1em' }}>{(a.bank||'EFECTIVO').toUpperCase()}</span>
                      <span style={{ font: `400 10px/1 ${eFonts.mono}`, color: a.change > 0 ? E.green : a.change < 0 ? E.red : E.fg3 }}>
                        {a.change > 0 ? '↑' : a.change < 0 ? '↓' : '·'} {eFmt(a.change, { sign: true, decimals: 0 })}
                      </span>
                    </div>
                  </div>
                </div>
              );
            })}
            <div style={{ marginTop: 10, paddingTop: 10, borderTop: `1px solid ${E.rule}`, display: 'flex', justifyContent: 'space-between' }}>
              <span style={{ font: `500 10px/1 ${eFonts.mono}`, color: E.fg2, letterSpacing: '0.16em' }}>NET POSITION</span>
              <span style={{ font: `500 15px/1 ${eFonts.mono}`, color: E.cyan, textShadow: E.glow }}>$10,449.20</span>
            </div>
          </EPanel>

          <EPanel id="02" title="Channels" right="2 LIVE">
            {[
              { name: 'WHATSAPP', state: 'ONLINE', latency: '2m', count: 24, color: E.green },
              { name: 'EMAIL',    state: 'ONLINE', latency: '12m', count: 11, color: E.green },
            ].map(c => (
              <div key={c.name} style={{ padding: '10px 0', borderBottom: `1px dashed ${E.rule2}` }}>
                <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
                  <span style={{ font: `500 12px/1 ${eFonts.display}`, color: E.fg, letterSpacing: '0.12em' }}>{c.name}</span>
                  <span style={{ font: `500 10px/1 ${eFonts.mono}`, color: c.color, letterSpacing: '0.12em' }}>● {c.state}</span>
                </div>
                <div style={{ display: 'flex', justifyContent: 'space-between', marginTop: 6 }}>
                  <span style={{ font: `400 10px/1 ${eFonts.mono}`, color: E.fg3, letterSpacing: '0.08em' }}>LAST PING {c.latency} AGO</span>
                  <span style={{ font: `500 11px/1 ${eFonts.mono}`, color: E.cyan }}>{c.count} CAPTURED</span>
                </div>
              </div>
            ))}
            <div style={{ marginTop: 8, font: `400 11px/1.4 ${eFonts.mono}`, color: E.fg2, letterSpacing: '0.08em' }}>
              <span style={{ color: E.cyan }}>›</span> 55.6% AUTO-CAPTURE RATE THIS CYCLE
            </div>
          </EPanel>

          <EPanel id="03" title="Threat Log" right="LIVE">
            {[
              { t: '06:42', l: 'INFO', c: E.cyan,  m: 'Netflix subscription renews tomorrow ($15.99)' },
              { t: '04:18', l: 'INFO', c: E.green, m: 'Salario credited · BAC Corriente · +$2,100.00' },
              { t: '01:02', l: 'WARN', c: E.amber, m: 'Restaurantes spend > 7d avg (+38%)' },
              { t: '19:43', l: 'INFO', c: E.cyan,  m: 'WhatsApp: 3 txns batch-logged' },
            ].map((row, i) => (
              <div key={i} style={{ padding: '6px 0', display: 'grid', gridTemplateColumns: '44px 56px 1fr', gap: 8, font: `400 11px/1.35 ${eFonts.mono}` }}>
                <span style={{ color: E.fg3 }}>{row.t}</span>
                <span style={{ color: row.c, letterSpacing: '0.1em' }}>[{row.l}]</span>
                <span style={{ color: E.fg2 }}>{row.m}</span>
              </div>
            ))}
          </EPanel>
        </div>

        {/* ───── CENTER: gauges + chart + transactions ───── */}
        <div style={{ display: 'flex', flexDirection: 'column', gap: 16 }}>
          {/* triple gauge */}
          <EPanel id="00" title="Primary Targets" right="JAN · 2026" pad={20}>
            <div style={{ display: 'grid', gridTemplateColumns: 'repeat(3, 1fr)', gap: 12, alignItems: 'center' }}>
              <div style={{ textAlign: 'center' }}>
                <EArcGauge value={'$12,450'} max={20000} sub="+2.56% MoM" label="Net Worth" size={240} />
              </div>
              <div style={{ textAlign: 'center' }}>
                <EArcGauge value={'83.6%'} max={100} sub="$312 PROJ. OVER" label="Budget" size={240} danger />
              </div>
              <div style={{ textAlign: 'center' }}>
                <EArcGauge value={'44.3%'} max={100} sub="HIGHEST SINCE AUG" label="Savings Rate" size={240} />
              </div>
            </div>
          </EPanel>

          {/* trajectory chart */}
          <EPanel id="04" title="Cashflow Trajectory" right="12 MO">
            <div style={{ display: 'flex', alignItems: 'center', gap: 14, marginBottom: 10 }}>
              {[
                { l: 'INCOME',    c: E.cyan,  v: '$4,200.00' },
                { l: 'OUTFLOW',   c: E.amber, v: '$2,340.50' },
                { l: 'NET',       c: E.green, v: '+$1,859.50' },
              ].map(it => (
                <div key={it.l} style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
                  <span style={{ width: 10, height: 10, background: it.c, boxShadow: `0 0 8px ${it.c}` }} />
                  <span style={{ font: `500 10px/1 ${eFonts.mono}`, color: E.fg2, letterSpacing: '0.14em' }}>{it.l}</span>
                  <span style={{ font: `500 12px/1 ${eFonts.mono}`, color: it.c }}>{it.v}</span>
                </div>
              ))}
              <span style={{ flex: 1 }} />
              <span style={{ font: `500 10px/1 ${eFonts.mono}`, color: E.fg3, letterSpacing: '0.12em' }}>
                CURRENT POSITION → JAN
              </span>
            </div>
            <EHoloChart width={700} height={170} />
            <div style={{ display: 'flex', justifyContent: 'space-between', font: `400 10px/1 ${eFonts.mono}`, color: E.fg3, letterSpacing: '0.1em', marginTop: 4 }}>
              {d.netWorth.labels.map(l => <span key={l}>{l.toUpperCase()}</span>)}
            </div>
          </EPanel>

          {/* transaction tail */}
          <EPanel id="05" title="Recent Activity" right="LAST 6">
            <div style={{ fontVariantNumeric: 'tabular-nums' }}>
              <div style={{ display: 'grid', gridTemplateColumns: '88px 1fr 110px 70px 96px', padding: '4px 0', borderBottom: `1px solid ${E.rule}`, font: `500 9px/1 ${eFonts.mono}`, color: E.fg3, letterSpacing: '0.16em' }}>
                <span>TIMESTAMP</span><span>EVENT</span><span>CATEGORY</span><span>SRC</span><span style={{ textAlign: 'right' }}>VECTOR</span>
              </div>
              {d.transactions.slice(0, 6).map((t, i) => {
                const isInc = t.amount > 0;
                return (
                  <div key={t.id} style={{
                    display: 'grid', gridTemplateColumns: '88px 1fr 110px 70px 96px',
                    padding: '8px 0', borderBottom: `1px dashed ${E.rule2}`,
                    font: `400 12px/1 ${eFonts.mono}`,
                  }}>
                    <span style={{ color: E.fg3 }}>{t.date.slice(5)} {t.time}</span>
                    <span style={{ color: E.fg, letterSpacing: '0.04em' }}>{t.desc.toUpperCase()}</span>
                    <span style={{ color: E.fg2 }}>{t.cat.toUpperCase()}</span>
                    <span style={{ color: t.source === 'whatsapp' ? E.green : t.source === 'email' ? E.cyan : E.fg3, letterSpacing: '0.1em' }}>{t.source.slice(0,4).toUpperCase()}</span>
                    <span style={{ textAlign: 'right', color: isInc ? E.green : E.fg }}>
                      {isInc ? '+' : '-'}{eFmt(t.amount)}
                    </span>
                  </div>
                );
              })}
            </div>
          </EPanel>
        </div>

        {/* ───── RIGHT: insights + spending breakdown ───── */}
        <div style={{ display: 'flex', flexDirection: 'column', gap: 14 }}>
          <EPanel id="06" title="Spend Breakdown" right="JAN">
            {d.categories.map(c => (
              <div key={c.id} style={{ padding: '8px 0', borderBottom: `1px dashed ${E.rule2}` }}>
                <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: 5 }}>
                  <span style={{ font: `500 11px/1 ${eFonts.display}`, color: E.fg, letterSpacing: '0.12em' }}>
                    {c.name.toUpperCase()}
                  </span>
                  <span style={{ font: `500 12px/1 ${eFonts.mono}`, color: E.cyan }}>${c.amount.toFixed(0)}</span>
                </div>
                <div style={{ position: 'relative', height: 4, background: 'rgba(63,212,255,0.08)' }}>
                  <div style={{ position: 'absolute', left: 0, top: 0, bottom: 0, width: `${c.percent}%`, background: E.cyan, boxShadow: `0 0 6px ${E.cyan}` }} />
                </div>
                <div style={{ display: 'flex', justifyContent: 'space-between', marginTop: 4, font: `400 9px/1 ${eFonts.mono}`, color: E.fg3, letterSpacing: '0.1em' }}>
                  <span>{c.percent.toFixed(1)}% OF SPEND</span>
                  <span>{c.count} EVENTS</span>
                </div>
              </div>
            ))}
          </EPanel>

          <EPanel id="07" title="Tactical Insights" right="J · A · R · V">
            {d.insights.slice(0,3).map((ins, i) => {
              const c = ins.severity === 'warn' ? E.amber : ins.severity === 'good' ? E.green : ins.severity === 'bad' ? E.red : E.cyan;
              return (
                <div key={ins.tag} style={{
                  padding: '10px 0',
                  borderBottom: i < 2 ? `1px dashed ${E.rule2}` : 'none',
                }}>
                  <div style={{ display: 'flex', alignItems: 'center', gap: 8, marginBottom: 6 }}>
                    <span style={{
                      font: `500 9px/1 ${eFonts.mono}`,
                      color: c, letterSpacing: '0.18em', padding: '3px 6px', border: `1px solid ${c}`,
                    }}>{ins.tag.toUpperCase()}</span>
                    <span style={{ flex: 1, height: 1, background: E.rule2 }} />
                  </div>
                  <div style={{
                    font: `500 13px/1.3 ${eFonts.display}`,
                    color: E.fg, letterSpacing: '0.04em',
                  }}>{ins.headline}</div>
                  <div style={{ font: `400 11px/1.5 ${eFonts.mono}`, color: E.fg2, marginTop: 6, letterSpacing: '0.02em' }}>
                    {ins.detail}
                  </div>
                </div>
              );
            })}
          </EPanel>

          {/* targeting reticle decoration */}
          <EPanel id="08" title="System Status">
            <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 12 }}>
              {[
                ['CPU·SYNC',  '98.4%',  E.green],
                ['LATENCY',   '14 ms',  E.green],
                ['LLM',       'HAIKU',  E.cyan],
                ['DB',        'PG·SB',  E.cyan],
                ['RULES',     '24 RUN', E.cyan],
                ['UPTIME',    '142 D',  E.green],
              ].map(([k,v,c]) => (
                <div key={k} style={{
                  padding: '10px 12px',
                  border: `1px solid ${E.rule2}`,
                  background: 'rgba(63,212,255,0.03)',
                  position: 'relative',
                }}>
                  <div style={{ font: `500 9px/1 ${eFonts.mono}`, color: E.fg3, letterSpacing: '0.18em' }}>{k}</div>
                  <div style={{ font: `500 16px/1 ${eFonts.display}`, color: c, marginTop: 6, letterSpacing: '0.06em' }}>{v}</div>
                </div>
              ))}
            </div>
          </EPanel>
        </div>
      </div>

      {/* ═════════ bottom status bar ═════════ */}
      <div style={{
        position: 'relative', zIndex: 1,
        marginTop: 18, paddingTop: 12,
        borderTop: `1px solid ${E.rule}`,
        display: 'flex', gap: 22, alignItems: 'center',
        font: `400 11px/1 ${eFonts.mono}`, color: E.fg3, letterSpacing: '0.14em',
      }}>
        <span>F1 HELP</span><span>F2 SCAN</span><span>F3 PROJECT</span><span>F4 ENCRYPT</span><span>F5 BRIEF</span>
        <span style={{ flex: 1 }} />
        <span style={{ color: E.cyan }}>● CONNECTED · ENCRYPTED · LIVE</span>
        <span style={{ color: E.cyan2 }}>JARVIS · STANDING BY</span>
      </div>
    </div>
  );
}

window.JarvisHUD = JarvisHUD;
