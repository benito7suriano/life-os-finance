// Shared sample data lifted from finance/components/dashboard/sample-data.json
// + a few extra fields (12-month sparkline, automation status, insights) to
// feed the redesign explorations.

window.LEDGER_DATA = {
  user: {
    firstName: 'Carlos',
    lastName: 'Mendoza',
    locale: 'es-SV',
  },
  asOf: '2026-01-23',
  netWorth: {
    amount: 12450.00,
    previousAmount: 12139.50,
    change: 310.50,
    changePercent: 2.56,
    // 12 months of monthly net-worth snapshots (oldest -> newest)
    series: [9820, 9985, 10240, 10510, 10780, 10905, 11140, 11380, 11620, 11890, 12139.5, 12450],
    labels: ['Feb','Mar','Apr','May','Jun','Jul','Aug','Sep','Oct','Nov','Dec','Jan'],
  },
  month: {
    label: 'January 2026',
    income: 4200.00,
    expenses: 2340.50,
    savingsRate: 0.443,
    budget: 2800.00,
    budgetUsed: 0.836,
    projectedOverspend: 312.00,
    daysLeft: 8,
  },
  accounts: [
    { id: 'a1', name: 'Cuenta Corriente',  bank: 'BAC',             type: 'checking',   balance: 3245.80, change: +180.20 },
    { id: 'a2', name: 'Ahorros',           bank: 'Banco Agricola',  type: 'savings',    balance: 8500.00, change: +150.00 },
    { id: 'a3', name: 'Visa Gold',         bank: 'BAC',             type: 'credit_card',balance: -1420.80, change: -340.50, last4: '4218', limit: 5000 },
    { id: 'a4', name: 'Efectivo',          bank: null,              type: 'wallet',     balance: 125.00,  change: -45.00 },
  ],
  categories: [
    { id: 'c1', name: 'Supermercado',    es: 'Supermercado',    amount: 680.45, percent: 29.1, count: 12, color: '#3a7d4f', prevMonth: 521.30 },
    { id: 'c2', name: 'Transporte',      es: 'Transporte',      amount: 425.00, percent: 18.2, count: 18, color: '#b88842', prevMonth: 410.00 },
    { id: 'c3', name: 'Restaurantes',    es: 'Restaurantes',    amount: 312.80, percent: 13.4, count: 8,  color: '#7a4a8a', prevMonth: 380.20 },
    { id: 'c4', name: 'Servicios',       es: 'Servicios',       amount: 285.00, percent: 12.2, count: 5,  color: '#c75555', prevMonth: 285.00 },
    { id: 'c5', name: 'Entretenimiento', es: 'Entretenimiento', amount: 245.50, percent: 10.5, count: 6,  color: '#5566a8', prevMonth: 180.00 },
    { id: 'c6', name: 'Otros',           es: 'Otros',           amount: 391.75, percent: 16.6, count: 14, color: '#8a8276', prevMonth: 403.75 },
  ],
  transactions: [
    { id: 't1', date: '2026-01-23', time: '14:32', desc: 'Super Selectos',        cat: 'Supermercado',    account: 'Visa Gold',    amount: -45.32,  source: 'whatsapp' },
    { id: 't2', date: '2026-01-22', time: '08:00', desc: 'Salario quincenal',     cat: 'Salario',         account: 'BAC',          amount: +2100.00, source: 'email' },
    { id: 't3', date: '2026-01-22', time: '19:14', desc: 'Uber Eats',             cat: 'Restaurantes',    account: 'Visa Gold',    amount: -18.40,  source: 'whatsapp' },
    { id: 't4', date: '2026-01-21', time: '07:45', desc: 'Uber',                  cat: 'Transporte',      account: 'BAC',          amount: -8.50,   source: 'whatsapp' },
    { id: 't5', date: '2026-01-20', time: '12:30', desc: 'La Pampa Argentina',    cat: 'Restaurantes',    account: 'Visa Gold',    amount: -24.50,  source: 'manual' },
    { id: 't6', date: '2026-01-19', time: '17:02', desc: 'Gasolinera Puma',       cat: 'Transporte',      account: 'Visa Gold',    amount: -42.00,  source: 'whatsapp' },
    { id: 't7', date: '2026-01-18', time: '00:00', desc: 'Netflix',               cat: 'Entretenimiento', account: 'Visa Gold',    amount: -15.99,  source: 'email' },
    { id: 't8', date: '2026-01-17', time: '11:20', desc: 'Walmart',               cat: 'Supermercado',    account: 'Visa Gold',    amount: -82.15,  source: 'whatsapp' },
    { id: 't9', date: '2026-01-16', time: '21:08', desc: 'Cine Multiplaza',       cat: 'Entretenimiento', account: 'BAC',          amount: -22.00,  source: 'manual' },
    { id: 't10',date: '2026-01-15', time: '09:45', desc: 'CAESS (luz)',           cat: 'Servicios',       account: 'BAC',          amount: -78.50,  source: 'email' },
  ],
  automation: {
    whatsapp: { connected: true, lastSync: '2 min ago', autoLoggedThisMonth: 24 },
    email:    { connected: true, lastSync: '12 min ago', autoLoggedThisMonth: 11 },
  },
  // AI-generated observations the dashboard should surface as plain language.
  insights: [
    {
      tag: 'pace',
      headline: 'On pace to overspend by $312 this month.',
      detail: 'At your current rate you\u2019ll close January at $3,152 \u2014 about $312 over your $2,800 budget. Cutting weekday Uber Eats orders gets you back to neutral.',
      severity: 'warn',
    },
    {
      tag: 'category',
      headline: 'Supermercado spending is up 30% vs December.',
      detail: 'Twelve grocery trips this month vs nine last month. Super Selectos accounts for $412 of the $680 total.',
      severity: 'info',
    },
    {
      tag: 'subscription',
      headline: 'Netflix renews tomorrow ($15.99).',
      detail: 'Charged to Visa Gold every 18th. This is your only active recurring subscription.',
      severity: 'neutral',
    },
    {
      tag: 'savings',
      headline: 'You\u2019ve saved $1,860 so far in January.',
      detail: '44% of your income \u2014 your best savings rate since August. Two paychecks plus lower restaurant spend.',
      severity: 'good',
    },
  ],
};
