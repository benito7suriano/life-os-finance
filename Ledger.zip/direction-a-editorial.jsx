// Direction A — Editorial Ledger
// Cream paper · warm ink · Newsreader display · IBM Plex Mono numerals
// Hairline rules, tabular calm, a financial-statement feel.

const A = {
  paper:   '#f4efe4',
  paper2:  '#ecdfca',     // a deeper cream for accents/bands
  ink:     '#1a1612',
  ink2:    '#5a5048',
  rule:    '#cdc1a6',
  good:    '#2f6b3f',     // moss green
  warn:    '#a85a1a',     // burnt sienna
  bad:     '#8a2d22',     // oxblood
  accent:  '#5a3a2a',     // ink-brown accent
};

const aFonts = {
  display: '"Newsreader", "Source Serif 4", Georgia, serif',
  body:    '"IBM Plex Sans", system-ui, sans-serif',
  mono:    '"IBM Plex Mono", ui-monospace, monospace',
};

function aFmt(n, opts={}) {
  const { sign=false, decimals=2 } = opts;
  const abs = Math.abs(n).toLocaleString('en-US', { minimumFractionDigits: decimals, maximumFractionDigits: decimals });
  if (sign && n > 0) return '+$' + abs;
  if (n < 0) return '\u2212$' + abs;
  return '$' + abs;
}

// Sparkline — clean editorial line, 1px stroke, no fill, baseline rule.
function ASparkline({ data, width=720, height=180, color=A.ink }) {
  const padX = 8, padY = 18;
  const min = Math.min(...data), max = Math.max(...data);
  const xs = data.map((_, i) => padX + (i * (width - padX*2)) / (data.length - 1));
  const ys = data.map(v => height - padY - ((v - min) / (max - min || 1)) * (height - padY*2));
  const path = xs.map((x, i) => `${i ? 'L' : 'M'} ${x.toFixed(1)} ${ys[i].toFixed(1)}`).join(' ');
  return (
    <svg viewBox={`0 0 ${width} ${height}`} style={{ width: '100%', height: 'auto', display: 'block' }}>
      <line x1={0} x2={width} y1={height-padY} y2={height-padY} stroke={A.rule} strokeWidth="1" />
      <path d={path} stroke={color} strokeWidth="1.5" fill="none" />
      <circle cx={xs[xs.length-1]} cy={ys[ys.length-1]} r={3.5} fill={color} />
    </svg>
  );
}

// Tiny bar pair for the category band
function ACatBar({ pct, color }) {
  return (
    <div style={{ width: '100%', height: 4, background: A.rule, position: 'relative' }}>
      <div style={{ position: 'absolute', inset: 0, width: `${pct}%`, background: color }} />
    </div>
  );
}

function APill({ children, tone='neutral' }) {
  const tones = {
    good:    { c: A.good, bg: 'rgba(47,107,63,0.08)' },
    warn:    { c: A.warn, bg: 'rgba(168,90,26,0.10)' },
    bad:     { c: A.bad,  bg: 'rgba(138,45,34,0.08)' },
    neutral: { c: A.ink2, bg: 'rgba(26,22,18,0.06)' },
  }[tone];
  return (
    <span style={{
      display: 'inline-flex', alignItems: 'center', gap: 6,
      padding: '3px 8px', borderRadius: 999,
      font: `500 11px/1 ${aFonts.body}`,
      letterSpacing: '0.04em', textTransform: 'uppercase',
      color: tones.c, background: tones.bg,
    }}>{children}</span>
  );
}

function EditorialLedger() {
  const d = window.LEDGER_DATA;
  return (
    <div style={{
      width: '100%', minHeight: '100%',
      background: A.paper, color: A.ink,
      font: `400 14px/1.55 ${aFonts.body}`,
      padding: '40px 56px 56px',
      boxSizing: 'border-box',
    }}>
      {/* ───────────────────────── masthead ───────────────────────── */}
      <header style={{
        display: 'grid', gridTemplateColumns: '1fr auto 1fr',
        alignItems: 'end', paddingBottom: 18,
        borderBottom: `2px solid ${A.ink}`,
      }}>
        <div style={{ font: `500 11px/1 ${aFonts.body}`, letterSpacing: '0.18em', textTransform: 'uppercase', color: A.ink2 }}>
          Viernes · 23 Enero 2026 · San Salvador
        </div>
        <div style={{ textAlign: 'center', font: `400 28px/1 ${aFonts.display}`, fontStyle: 'italic', letterSpacing: '0.02em' }}>
          Ledger
        </div>
        <div style={{ textAlign: 'right', font: `500 11px/1 ${aFonts.body}`, letterSpacing: '0.18em', textTransform: 'uppercase', color: A.ink2 }}>
          Vol. I · Núm. 23 · Carlos M.
        </div>
      </header>
      <div style={{ borderBottom: `1px solid ${A.ink}`, marginTop: 2, marginBottom: 32 }} />

      {/* ───────────────────────── hero: net worth ──────────────── */}
      <section style={{ display: 'grid', gridTemplateColumns: '1.4fr 1fr', gap: 48, marginBottom: 36 }}>
        <div>
          <div style={{ font: `500 11px/1 ${aFonts.body}`, letterSpacing: '0.2em', textTransform: 'uppercase', color: A.ink2, marginBottom: 14 }}>
            Patrimonio neto · twelve-month review
          </div>
          <div style={{ display: 'flex', alignItems: 'baseline', gap: 18, marginBottom: 6 }}>
            <div style={{ font: `400 84px/0.95 ${aFonts.display}`, letterSpacing: '-0.02em' }}>
              $12,450<span style={{ color: A.ink2 }}>.00</span>
            </div>
            <div style={{ font: `400 20px/1 ${aFonts.display}`, fontStyle: 'italic', color: A.good }}>
              ▲ {aFmt(d.netWorth.change, { sign: true })}
              <span style={{ color: A.ink2, fontStyle: 'normal', fontFamily: aFonts.mono, fontSize: 13, marginLeft: 8 }}>
                +2.56% MoM
              </span>
            </div>
          </div>
          <div style={{ marginTop: 18 }}>
            <ASparkline data={d.netWorth.series} width={720} height={150} color={A.ink} />
            <div style={{
              display: 'flex', justifyContent: 'space-between',
              font: `500 10px/1 ${aFonts.mono}`, letterSpacing: '0.08em',
              color: A.ink2, marginTop: 6,
            }}>
              {d.netWorth.labels.map(l => <span key={l}>{l.toUpperCase()}</span>)}
            </div>
          </div>
        </div>

        {/* This month summary — newspaper-style stat list */}
        <div style={{ paddingLeft: 32, borderLeft: `1px solid ${A.rule}` }}>
          <div style={{ font: `500 11px/1 ${aFonts.body}`, letterSpacing: '0.2em', textTransform: 'uppercase', color: A.ink2, marginBottom: 14 }}>
            Estado del mes · January
          </div>
          {[
            { k: 'Ingresos',  v: '+$4,200.00', sub: 'Salario · 1 depósito', tone: 'good' },
            { k: 'Gastos',    v: '−$2,340.50', sub: '63 transacciones',     tone: 'bad' },
            { k: 'Ahorro',    v: '$1,859.50',  sub: 'Tasa de ahorro 44.3%', tone: 'good' },
            { k: 'Presupuesto', v: '$2,800.00', sub: '83.6% utilizado · 8 días restantes', tone: 'warn' },
          ].map((row, i) => (
            <div key={row.k} style={{
              display: 'grid', gridTemplateColumns: '1fr auto',
              padding: '14px 0',
              borderTop: i === 0 ? `1px solid ${A.rule}` : 'none',
              borderBottom: `1px solid ${A.rule}`,
              alignItems: 'baseline',
            }}>
              <div>
                <div style={{ font: `500 13px/1.3 ${aFonts.body}`, color: A.ink }}>{row.k}</div>
                <div style={{ font: `400 12px/1.4 ${aFonts.body}`, color: A.ink2, marginTop: 2 }}>{row.sub}</div>
              </div>
              <div style={{
                font: `500 22px/1 ${aFonts.mono}`,
                color: row.tone === 'good' ? A.good : row.tone === 'bad' ? A.bad : row.tone === 'warn' ? A.warn : A.ink,
                fontVariantNumeric: 'tabular-nums',
              }}>{row.v}</div>
            </div>
          ))}
        </div>
      </section>

      {/* ───────────────────────── insights leader ─────────────────── */}
      <section style={{
        background: A.paper2,
        padding: '24px 28px',
        borderTop: `1px solid ${A.ink}`,
        borderBottom: `1px solid ${A.ink}`,
        marginBottom: 36,
      }}>
        <div style={{ font: `500 11px/1 ${aFonts.body}`, letterSpacing: '0.2em', textTransform: 'uppercase', color: A.ink2, marginBottom: 14 }}>
          Observaciones de la semana
        </div>
        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(2, 1fr)', columnGap: 32, rowGap: 18 }}>
          {d.insights.map((ins, i) => (
            <div key={ins.tag} style={{ display: 'grid', gridTemplateColumns: '36px 1fr', gap: 12 }}>
              <div style={{
                font: `400 28px/1 ${aFonts.display}`, fontStyle: 'italic',
                color: A.ink2, textAlign: 'right', paddingTop: 2,
              }}>§{i+1}</div>
              <div>
                <div style={{
                  font: `500 18px/1.3 ${aFonts.display}`,
                  letterSpacing: '-0.005em', color: A.ink, marginBottom: 4,
                }}>{ins.headline}</div>
                <div style={{ font: `400 13px/1.5 ${aFonts.body}`, color: A.ink2 }}>{ins.detail}</div>
              </div>
            </div>
          ))}
        </div>
      </section>

      {/* ───────────────────────── two-up: ledger + categories ──── */}
      <section style={{ display: 'grid', gridTemplateColumns: '1.5fr 1fr', gap: 40, marginBottom: 36 }}>
        {/* Recent transactions, presented as a register */}
        <div>
          <div style={{
            display: 'flex', alignItems: 'baseline', justifyContent: 'space-between',
            paddingBottom: 8, borderBottom: `1px solid ${A.ink}`, marginBottom: 0,
          }}>
            <div style={{ font: `500 20px/1 ${aFonts.display}`, fontStyle: 'italic' }}>The Register</div>
            <div style={{ font: `500 11px/1 ${aFonts.body}`, letterSpacing: '0.18em', textTransform: 'uppercase', color: A.ink2 }}>
              últimos 10 movimientos
            </div>
          </div>
          <table style={{ width: '100%', borderCollapse: 'collapse', font: `400 13px/1 ${aFonts.body}` }}>
            <thead>
              <tr style={{ textAlign: 'left', color: A.ink2 }}>
                <th style={{ padding: '10px 0 8px', font: `500 10px/1 ${aFonts.body}`, letterSpacing: '0.12em', textTransform: 'uppercase', width: 90, borderBottom: `1px solid ${A.rule}` }}>Date</th>
                <th style={{ padding: '10px 0 8px', font: `500 10px/1 ${aFonts.body}`, letterSpacing: '0.12em', textTransform: 'uppercase', borderBottom: `1px solid ${A.rule}` }}>Description</th>
                <th style={{ padding: '10px 0 8px', font: `500 10px/1 ${aFonts.body}`, letterSpacing: '0.12em', textTransform: 'uppercase', borderBottom: `1px solid ${A.rule}` }}>Category</th>
                <th style={{ padding: '10px 0 8px', font: `500 10px/1 ${aFonts.body}`, letterSpacing: '0.12em', textTransform: 'uppercase', textAlign: 'right', borderBottom: `1px solid ${A.rule}` }}>Amount</th>
              </tr>
            </thead>
            <tbody>
              {d.transactions.map((t) => {
                const isInc = t.amount > 0;
                return (
                  <tr key={t.id} style={{ borderBottom: `1px solid ${A.rule}` }}>
                    <td style={{ padding: '12px 0', font: `400 12px/1.2 ${aFonts.mono}`, color: A.ink2, verticalAlign: 'top' }}>
                      {t.date.slice(5).replace('-','·')}
                    </td>
                    <td style={{ padding: '12px 0', verticalAlign: 'top' }}>
                      <div style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
                        <span style={{ color: A.ink, font: `500 13px/1.2 ${aFonts.body}` }}>{t.desc}</span>
                        {t.source !== 'manual' && (
                          <span style={{
                            font: `500 9px/1 ${aFonts.body}`, letterSpacing: '0.1em', textTransform: 'uppercase',
                            color: A.accent, border: `1px solid ${A.accent}`, padding: '2px 5px', borderRadius: 2,
                          }}>{t.source}</span>
                        )}
                      </div>
                    </td>
                    <td style={{ padding: '12px 0', color: A.ink2, font: `400 12px/1.2 ${aFonts.body}`, fontStyle: 'italic', verticalAlign: 'top' }}>
                      {t.cat}
                    </td>
                    <td style={{
                      padding: '12px 0', textAlign: 'right',
                      font: `500 14px/1.2 ${aFonts.mono}`,
                      fontVariantNumeric: 'tabular-nums',
                      color: isInc ? A.good : A.ink,
                    }}>{aFmt(t.amount, { sign: true })}</td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>

        {/* Categories + automation */}
        <div>
          <div style={{
            display: 'flex', alignItems: 'baseline', justifyContent: 'space-between',
            paddingBottom: 8, borderBottom: `1px solid ${A.ink}`,
          }}>
            <div style={{ font: `500 20px/1 ${aFonts.display}`, fontStyle: 'italic' }}>By category</div>
            <div style={{ font: `500 11px/1 ${aFonts.body}`, letterSpacing: '0.18em', textTransform: 'uppercase', color: A.ink2 }}>
              vs Diciembre
            </div>
          </div>
          {d.categories.map(c => {
            const diff = ((c.amount - c.prevMonth) / c.prevMonth) * 100;
            return (
              <div key={c.id} style={{ padding: '14px 0', borderBottom: `1px solid ${A.rule}` }}>
                <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'baseline', marginBottom: 6 }}>
                  <div style={{ font: `500 14px/1.2 ${aFonts.body}`, color: A.ink }}>{c.name}</div>
                  <div style={{ font: `500 14px/1 ${aFonts.mono}`, color: A.ink, fontVariantNumeric: 'tabular-nums' }}>
                    {aFmt(c.amount)}
                  </div>
                </div>
                <ACatBar pct={c.percent} color={c.color} />
                <div style={{ display: 'flex', justifyContent: 'space-between', marginTop: 6, font: `400 11px/1 ${aFonts.body}`, color: A.ink2 }}>
                  <span>{c.count} transacciones · {c.percent.toFixed(1)}%</span>
                  <span style={{ color: diff > 0 ? A.warn : A.good, fontFamily: aFonts.mono, fontVariantNumeric: 'tabular-nums' }}>
                    {diff > 0 ? '▲' : '▼'} {Math.abs(diff).toFixed(0)}%
                  </span>
                </div>
              </div>
            );
          })}

          {/* Automation Notice — set like a classified ad */}
          <div style={{ marginTop: 28, padding: 18, border: `1px solid ${A.ink}`, background: A.paper }}>
            <div style={{ display: 'flex', alignItems: 'baseline', gap: 8, marginBottom: 6 }}>
              <div style={{ font: `400 18px/1 ${aFonts.display}`, fontStyle: 'italic' }}>Of the wire</div>
              <div style={{ flex: 1, borderBottom: `1px solid ${A.rule}`, transform: 'translateY(-4px)' }} />
            </div>
            <div style={{ font: `400 13px/1.55 ${aFonts.body}`, color: A.ink }}>
              <strong style={{ fontWeight: 600 }}>35 transactions</strong> automatically captured this month —
              24 from WhatsApp, 11 from email. Last sync 2 minutes ago.
            </div>
            <div style={{ marginTop: 10, display: 'flex', gap: 8 }}>
              <APill tone="good">● WhatsApp</APill>
              <APill tone="good">● Email</APill>
            </div>
          </div>
        </div>
      </section>

      {/* ───────────────────────── accounts strip ───────────────── */}
      <section>
        <div style={{
          display: 'flex', alignItems: 'baseline', justifyContent: 'space-between',
          paddingBottom: 8, borderBottom: `1px solid ${A.ink}`, marginBottom: 16,
        }}>
          <div style={{ font: `500 20px/1 ${aFonts.display}`, fontStyle: 'italic' }}>Holdings</div>
          <div style={{ font: `500 11px/1 ${aFonts.body}`, letterSpacing: '0.18em', textTransform: 'uppercase', color: A.ink2 }}>
            4 cuentas activas
          </div>
        </div>
        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(4, 1fr)', gap: 24 }}>
          {d.accounts.map(a => {
            const debt = a.type === 'credit_card' || a.type === 'loan';
            return (
              <div key={a.id} style={{ borderTop: `1px solid ${A.rule}`, paddingTop: 12 }}>
                <div style={{ font: `500 10px/1 ${aFonts.body}`, letterSpacing: '0.16em', textTransform: 'uppercase', color: A.ink2 }}>
                  {a.bank || 'efectivo'} · {a.type.replace('_',' ')}
                </div>
                <div style={{ font: `400 17px/1.2 ${aFonts.display}`, marginTop: 4 }}>{a.name}</div>
                <div style={{
                  font: `500 28px/1 ${aFonts.mono}`, marginTop: 10,
                  color: debt ? A.bad : A.ink,
                  fontVariantNumeric: 'tabular-nums',
                }}>
                  {debt ? '\u2212' : ''}${Math.abs(a.balance).toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
                </div>
                <div style={{ marginTop: 6, font: `400 11px/1.2 ${aFonts.mono}`, color: a.change > 0 ? A.good : a.change < 0 ? A.bad : A.ink2 }}>
                  {a.change > 0 ? '▲' : a.change < 0 ? '▼' : '·'} {aFmt(a.change, { sign: true })} este mes
                </div>
              </div>
            );
          })}
        </div>
      </section>

      {/* footer rule */}
      <div style={{ marginTop: 40, borderTop: `1px solid ${A.ink}`, paddingTop: 12, display: 'flex', justifyContent: 'space-between', font: `400 10px/1 ${aFonts.mono}`, color: A.ink2, letterSpacing: '0.1em', textTransform: 'uppercase' }}>
        <span>Ledger · personal accounts</span>
        <span>printed 23 · 01 · 26</span>
      </div>
    </div>
  );
}

window.EditorialLedger = EditorialLedger;
