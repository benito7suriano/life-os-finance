// Vault shared components — small atomic pieces used across every screen.
// All read from window.theme (a live, swappable theme object).
//
// Conventions:
//   - All components accept `style` for one-off overrides.
//   - Currency is always formatted via `fmt()`.
//   - Icons are inline SVG; the icon name maps to a single path string.
//
// To share these across other Babel script files we hang them on window.V at
// the end.

(function () {
  const { useState, useRef, useEffect, useCallback } = React;

  // ─── currency / number formatting ────────────────────────────────────
  function fmt(n, { sign=false, decimals=2, compact=false } = {}) {
    if (compact && Math.abs(n) >= 1000) {
      return (n < 0 ? '\u2212' : sign && n > 0 ? '+' : '') + '$' + (Math.abs(n)/1000).toFixed(1) + 'k';
    }
    const abs = Math.abs(n).toLocaleString('en-US', { minimumFractionDigits: decimals, maximumFractionDigits: decimals });
    if (sign && n > 0) return '+$' + abs;
    if (n < 0) return '\u2212$' + abs;
    return '$' + abs;
  }
  function fmtPct(n, { sign=true } = {}) {
    const abs = Math.abs(n).toFixed(1) + '%';
    if (sign && n > 0) return '+' + abs;
    if (n < 0) return '\u2212' + abs;
    return abs;
  }
  function fmtDate(d, locale='en-US') {
    return new Date(d).toLocaleDateString(locale, { month: 'short', day: 'numeric' });
  }

  // ─── icon library (lucide-style paths) ───────────────────────────────
  const ICONS = {
    dashboard:    'M3 12l9-9 9 9v9a2 2 0 0 1-2 2h-3v-7H8v7H5a2 2 0 0 1-2-2v-9z',
    transactions: 'M7 7h14m-4-4 4 4-4 4m0 6H3m4 4-4-4 4-4',
    accounts:     'M3 7h15v3H21v6h-3v3H3V7zm15 5h2v2h-2v-2z',
    budgets:      'M12 2v6m0 0a6 6 0 1 0 6 6m-6-6a6 6 0 0 1 6 6m-6-6L18 8',
    automation:   'M11.99 2 4.5 14h6.5v8l7.5-12h-6.5V2z',
    search:       'M11 19a8 8 0 1 0 0-16 8 8 0 0 0 0 16zm10 2-4.35-4.35',
    bell:         'M6 8a6 6 0 1 1 12 0c0 7 3 9 3 9H3s3-2 3-9M10 21a2 2 0 0 0 4 0',
    plus:         'M12 5v14M5 12h14',
    x:            'M6 6l12 12M6 18 18 6',
    check:        'M5 12l5 5L20 7',
    chevronDown:  'M6 9l6 6 6-6',
    chevronRight: 'M9 6l6 6-6 6',
    chevronLeft:  'M15 6l-6 6 6 6',
    arrowDown:    'M12 5v14m-6-6 6 6 6-6',
    arrowUp:      'M12 19V5m-6 6 6-6 6 6',
    arrowRight:   'M5 12h14m-6-6 6 6-6 6',
    arrowDownLeft:'M17 7 7 17m0 0h8m-8 0V9',
    arrowUpRight: 'M7 17 17 7m0 0H9m8 0v8',
    arrowExchange:'M7 16h14m-4-4 4 4-4 4M3 8h14M7 4 3 8l4 4',
    filter:       'M3 5h18l-7 9v6l-4-2v-4z',
    calendar:     'M3 9h18M5 5h14a2 2 0 0 1 2 2v12a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V7a2 2 0 0 1 2-2zm3-2v4m8-4v4',
    settings:     'M12 15a3 3 0 1 0 0-6 3 3 0 0 0 0 6zm9-3a8.95 8.95 0 0 0-.42-2.71l2.05-1.6-2-3.46-2.43.84a9.07 9.07 0 0 0-4.7-2.72L13 0h-4l-.5 2.35a9.07 9.07 0 0 0-4.7 2.72l-2.43-.84-2 3.46 2.05 1.6A8.95 8.95 0 0 0 1 12c0 .92.15 1.82.42 2.71l-2.05 1.6 2 3.46 2.43-.84a9.07 9.07 0 0 0 4.7 2.72L9 24h4l.5-2.35a9.07 9.07 0 0 0 4.7-2.72l2.43.84 2-3.46-2.05-1.6c.27-.89.42-1.79.42-2.71z',
    sparkles:     'M12 3l1.5 5L18 9.5 13.5 11 12 16l-1.5-5L6 9.5l4.5-1.5L12 3zm6 8 .8 2.5L21 14l-2.2.5L18 17l-.8-2.5L15 14l2.2-.5L18 11zM5 14l.8 2.5L8 17l-2.2.5L5 20l-.8-2.5L2 17l2.2-.5L5 14z',
    bot:          'M12 8V4m-4 4h8a2 2 0 0 1 2 2v6a2 2 0 0 1-2 2H8a2 2 0 0 1-2-2v-6a2 2 0 0 1 2-2zm1 5h.01M15 13h.01M9 17h6',
    mic:          'M12 14a3 3 0 0 0 3-3V5a3 3 0 1 0-6 0v6a3 3 0 0 0 3 3zm-7-3a7 7 0 1 0 14 0M12 18v3',
    image:        'M3 5h18v14H3V5zm0 10 5-5 4 4 3-3 6 6M9 10a2 2 0 1 1 0-4 2 2 0 0 1 0 4z',
    type:         'M4 7V5h16v2M9 19h6M12 5v14',
    edit:         'M12 20h9M16.5 3.5a2.12 2.12 0 1 1 3 3L7 19l-4 1 1-4z',
    trash:        'M3 6h18M8 6V4a2 2 0 0 1 2-2h4a2 2 0 0 1 2 2v2m3 0v14a2 2 0 0 1-2 2H7a2 2 0 0 1-2-2V6h14zm-9 4v6m4-6v6',
    more:         'M5 12h.01M12 12h.01M19 12h.01',
    upload:       'M12 19V5m-7 7 7-7 7 7',
    download:     'M12 5v14m-7-7 7 7 7-7',
    logOut:       'M9 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h4M16 17l5-5-5-5M21 12H9',
    help:         'M9.1 9a3 3 0 0 1 5.8 1c0 2-3 3-3 3M12 17h.01M21 12a9 9 0 1 1-18 0 9 9 0 0 1 18 0z',
    eye:          'M2 12s3.5-7 10-7 10 7 10 7-3.5 7-10 7-10-7-10-7zm10 3a3 3 0 1 0 0-6 3 3 0 0 0 0 6z',
    car:          'M5 17h14m0 0a2 2 0 1 0 0-4m0 4H5m0 0a2 2 0 1 1 0-4m0 4v-4m14 4v-4m0 0H5m0 0L7 7h10l2 6',
    plane:        'M2 12l4 2L20 4l-2 14-4-3-3 4-2-7L2 12z',
    laptop:       'M3 6h18v10H3V6zm-1 14h22',
    gift:         'M20 12v8H4v-8m16-4H4v4h16V8zm-8 0v12m4-16a2 2 0 0 0-4 0c0 2 0 4-2 4h4m2-4a2 2 0 0 1 4 0c0 2 0 4 2 4h-4',
    sendMoney:    'M22 2L11 13M22 2l-7 20-4-9-9-4 20-7z',
    wallet:       'M3 7h15v3H21v6h-3v3H3V7zm15 5h2v2h-2v-2z',
    credit:       'M3 7h18v10H3V7zm0 4h18m-12 4h2',
    pig:          'M11 4a8 8 0 0 0-8 8v3a2 2 0 0 0 2 2h1l1 2h6l1-2h2a3 3 0 0 0 3-3 3 3 0 0 0-3-3h-1V8h-4M15 11h.01',
    sliders:      'M4 6h12M16 6a2 2 0 1 0 4 0 2 2 0 0 0-4 0zM4 12h8M12 12a2 2 0 1 0 4 0 2 2 0 0 0-4 0zM4 18h4M8 18a2 2 0 1 0 4 0 2 2 0 0 0-4 0z',
    star:         'M12 2l3.09 6.26L22 9.27l-5 4.87 1.18 6.88L12 17.77l-6.18 3.25L7 14.14 2 9.27l6.91-1.01L12 2z',
  };

  function Icon({ name, size=18, color='currentColor', strokeWidth=1.8, style={} }) {
    return (
      <svg width={size} height={size} viewBox="0 0 24 24" fill="none" stroke={color}
        strokeWidth={strokeWidth} strokeLinecap="round" strokeLinejoin="round"
        style={{ display: 'inline-block', flexShrink: 0, ...style }}>
        <path d={ICONS[name] || ICONS.dashboard} />
      </svg>
    );
  }

  // ─── VCard ───────────────────────────────────────────────────────────
  function VCard({ children, style={}, pad=22, hoverable=false, onClick, accent=false }) {
    const t = window.theme;
    const [hover, setHover] = useState(false);
    const cardStyle = {
      background: accent
        ? `linear-gradient(135deg, ${t.accent.soft}, transparent 60%), ${t.card.bg}`
        : t.card.bg,
      border: `1px solid ${hover && hoverable ? t.card.borderHi : t.card.border}`,
      borderRadius: t.card.radius,
      padding: pad,
      boxShadow: t.card.shadow,
      position: 'relative',
      transition: 'border-color .15s, transform .15s',
      cursor: onClick ? 'pointer' : 'default',
      ...(hover && hoverable && { transform: 'translateY(-1px)' }),
      ...style,
    };
    return (
      <div style={cardStyle} onClick={onClick}
        onMouseEnter={() => hoverable && setHover(true)}
        onMouseLeave={() => hoverable && setHover(false)}>
        {children}
      </div>
    );
  }

  // ─── VButton ─────────────────────────────────────────────────────────
  function VButton({ children, variant='secondary', size='md', icon, iconRight, onClick, style={}, disabled=false, fullWidth=false }) {
    const t = window.theme;
    const sizes = {
      sm: { px: 10, py: 6, font: 12, gap: 6, icon: 14 },
      md: { px: 14, py: 9, font: 13, gap: 8, icon: 16 },
      lg: { px: 18, py: 12, font: 14, gap: 10, icon: 18 },
    }[size];
    const variants = {
      primary: {
        background: t.accentGradient,
        color: '#0b0d18',
        border: 'none',
        fontWeight: 600,
      },
      secondary: {
        background: 'rgba(255,255,255,0.04)',
        color: t.fg,
        border: `1px solid ${t.card.border}`,
        fontWeight: 500,
      },
      ghost: {
        background: 'transparent',
        color: t.fg2,
        border: 'none',
        fontWeight: 500,
      },
      danger: {
        background: 'rgba(251,113,133,0.1)',
        color: t.bad,
        border: `1px solid rgba(251,113,133,0.25)`,
        fontWeight: 500,
      },
      accent: {
        background: t.accent.soft,
        color: t.accent.a,
        border: `1px solid ${t.accent.soft}`,
        fontWeight: 500,
      },
    }[variant];
    return (
      <button onClick={onClick} disabled={disabled}
        style={{
          ...variants,
          padding: `${sizes.py}px ${sizes.px}px`,
          font: `${variants.fontWeight} ${sizes.font}px/1 ${t.fonts.body}`,
          borderRadius: 10,
          display: fullWidth ? 'flex' : 'inline-flex',
          alignItems: 'center', justifyContent: 'center', gap: sizes.gap,
          cursor: disabled ? 'not-allowed' : 'pointer',
          opacity: disabled ? 0.5 : 1,
          transition: 'transform .1s, opacity .15s',
          width: fullWidth ? '100%' : 'auto',
          whiteSpace: 'nowrap',
          ...style,
        }}>
        {icon && <Icon name={icon} size={sizes.icon} />}
        {children}
        {iconRight && <Icon name={iconRight} size={sizes.icon} />}
      </button>
    );
  }

  // ─── VIconButton ─────────────────────────────────────────────────────
  function VIconButton({ icon, onClick, badge, style={}, label, active=false }) {
    const t = window.theme;
    return (
      <button onClick={onClick} aria-label={label} title={label} style={{
        width: 40, height: 40, borderRadius: 12,
        background: active ? t.accent.soft : 'rgba(255,255,255,0.04)',
        border: `1px solid ${t.card.border}`,
        color: active ? t.accent.a : t.fg2,
        display: 'flex', alignItems: 'center', justifyContent: 'center',
        position: 'relative', cursor: 'pointer',
        ...style,
      }}>
        <Icon name={icon} size={18} />
        {badge !== undefined && (
          <span style={{
            position: 'absolute', top: 6, right: 7,
            width: 7, height: 7, borderRadius: '50%',
            background: t.accent.solid,
            boxShadow: `0 0 0 2px ${t.bg}`,
          }} />
        )}
      </button>
    );
  }

  // ─── VBadge ──────────────────────────────────────────────────────────
  function VBadge({ children, tone='neutral', dot=false, style={} }) {
    const t = window.theme;
    const tones = {
      neutral: { c: t.fg2, bg: 'rgba(255,255,255,0.06)' },
      good:    { c: t.good, bg: 'rgba(74,222,128,0.1)' },
      warn:    { c: t.warn, bg: 'rgba(251,191,36,0.1)' },
      bad:     { c: t.bad,  bg: 'rgba(251,113,133,0.1)' },
      info:    { c: t.info, bg: 'rgba(103,232,249,0.1)' },
      accent:  { c: t.accent.a, bg: t.accent.soft },
    }[tone];
    return (
      <span style={{
        display: 'inline-flex', alignItems: 'center', gap: 5,
        padding: '3px 8px', borderRadius: 999,
        font: `500 10px/1 ${t.fonts.mono}`,
        letterSpacing: '0.12em', textTransform: 'uppercase',
        color: tones.c, background: tones.bg,
        ...style,
      }}>
        {dot && <span style={{ width: 6, height: 6, borderRadius: '50%', background: tones.c }} />}
        {children}
      </span>
    );
  }

  // ─── VAvatar ─────────────────────────────────────────────────────────
  function VAvatar({ initials='?', size=40, style={} }) {
    const t = window.theme;
    return (
      <span style={{
        width: size, height: size, borderRadius: '50%',
        background: t.accentGradient,
        color: '#0b0d18', fontWeight: 700,
        fontSize: size * 0.36,
        display: 'inline-flex', alignItems: 'center', justifyContent: 'center',
        fontFamily: t.fonts.body,
        flexShrink: 0,
        ...style,
      }}>{initials}</span>
    );
  }

  // ─── VProgress ───────────────────────────────────────────────────────
  function VProgress({ value, max=100, height=6, color, style={} }) {
    const t = window.theme;
    const pct = Math.max(0, Math.min(1, value/max));
    return (
      <div style={{
        width: '100%', height,
        background: 'rgba(255,255,255,0.05)',
        borderRadius: height/2,
        overflow: 'hidden',
        ...style,
      }}>
        <div style={{
          width: `${pct*100}%`, height: '100%',
          background: color || t.accentGradient,
          borderRadius: height/2,
        }} />
      </div>
    );
  }

  // ─── VSpark (smooth line) ────────────────────────────────────────────
  function VSpark({ data, color, width=200, height=60, fill=false }) {
    const t = window.theme;
    color = color || t.accent.a;
    const min = Math.min(...data), max = Math.max(...data);
    const padX = 2, padY = 4;
    const xs = data.map((_, i) => padX + (i * (width - padX*2)) / (data.length - 1));
    const ys = data.map(v => height - padY - ((v - min) / (max - min || 1)) * (height - padY*2));
    let p = `M ${xs[0]} ${ys[0]}`;
    for (let i = 1; i < xs.length; i++) {
      const cx = (xs[i-1] + xs[i]) / 2;
      p += ` C ${cx} ${ys[i-1]}, ${cx} ${ys[i]}, ${xs[i]} ${ys[i]}`;
    }
    const area = `${p} L ${xs[xs.length-1]} ${height} L ${xs[0]} ${height} Z`;
    const gid = 'vspk-' + Math.random().toString(36).slice(2,8);
    return (
      <svg viewBox={`0 0 ${width} ${height}`} style={{ width, height, display: 'block', overflow: 'visible' }}>
        {fill && (
          <>
            <defs>
              <linearGradient id={gid} x1="0" y1="0" x2="0" y2="1">
                <stop offset="0%" stopColor={color} stopOpacity="0.25" />
                <stop offset="100%" stopColor={color} stopOpacity="0" />
              </linearGradient>
            </defs>
            <path d={area} fill={`url(#${gid})`} />
          </>
        )}
        <path d={p} stroke={color} strokeWidth="1.6" fill="none" strokeLinecap="round" />
      </svg>
    );
  }

  // ─── VMiniBars ───────────────────────────────────────────────────────
  function VMiniBars({ data, color, width=120, height=40 }) {
    const t = window.theme;
    color = color || t.accent.a;
    const max = Math.max(...data);
    const bw = (width - (data.length - 1) * 3) / data.length;
    return (
      <svg viewBox={`0 0 ${width} ${height}`} style={{ width, height, display: 'block' }}>
        {data.map((v, i) => {
          const h = (v / max) * (height - 4);
          return <rect key={i} x={i * (bw + 3)} y={height - h} width={bw} height={h} rx="2" fill={color} opacity={i === data.length - 1 ? 1 : 0.4} />;
        })}
      </svg>
    );
  }

  // ─── VSearchInput / VInput ───────────────────────────────────────────
  function VInput({ icon, placeholder, value, onChange, kbd, style={}, fullWidth=false, type='text' }) {
    const t = window.theme;
    return (
      <div style={{
        display: 'inline-flex', alignItems: 'center', gap: 10,
        background: 'rgba(255,255,255,0.04)',
        border: `1px solid ${t.card.border}`,
        borderRadius: 12, padding: '10px 14px',
        color: t.fg2, font: `400 13px/1 ${t.fonts.body}`,
        width: fullWidth ? '100%' : 'auto',
        ...style,
      }}>
        {icon && <Icon name={icon} size={16} />}
        <input type={type} placeholder={placeholder} value={value||''} onChange={onChange || (() => {})}
          style={{
            background: 'transparent', border: 'none', outline: 'none',
            color: t.fg, font: `400 13px/1 ${t.fonts.body}`,
            flex: 1, width: '100%',
          }} />
        {kbd && (
          <span style={{
            fontFamily: t.fonts.mono, fontSize: 11, padding: '2px 6px',
            border: `1px solid ${t.card.borderHi}`, borderRadius: 5, color: t.fg3,
          }}>{kbd}</span>
        )}
      </div>
    );
  }

  // ─── VChip (filter chip) ─────────────────────────────────────────────
  function VChip({ children, active=false, onClick, style={}, icon }) {
    const t = window.theme;
    return (
      <button onClick={onClick} style={{
        padding: '6px 12px', borderRadius: 999,
        background: active ? t.accent.soft : 'rgba(255,255,255,0.03)',
        border: `1px solid ${active ? 'transparent' : t.card.border}`,
        color: active ? t.accent.a : t.fg2,
        font: `500 12px/1 ${t.fonts.body}`,
        display: 'inline-flex', alignItems: 'center', gap: 6,
        cursor: 'pointer',
        ...style,
      }}>
        {icon && <Icon name={icon} size={13} />}
        {children}
      </button>
    );
  }

  // ─── VToggle (switch) ────────────────────────────────────────────────
  function VToggle({ checked, onChange, label, sublabel, style={} }) {
    const t = window.theme;
    return (
      <label style={{ display: 'flex', alignItems: 'center', gap: 12, cursor: 'pointer', ...style }}>
        {(label || sublabel) && (
          <div style={{ flex: 1 }}>
            {label && <div style={{ font: `500 13px/1.2 ${t.fonts.body}`, color: t.fg }}>{label}</div>}
            {sublabel && <div style={{ font: `400 12px/1.3 ${t.fonts.body}`, color: t.fg3, marginTop: 3 }}>{sublabel}</div>}
          </div>
        )}
        <span style={{
          width: 38, height: 22, borderRadius: 11, padding: 2,
          background: checked ? t.accentGradient : 'rgba(255,255,255,0.08)',
          transition: 'background .15s', flexShrink: 0,
        }}>
          <span style={{
            display: 'block', width: 18, height: 18, borderRadius: '50%',
            background: '#fff',
            transform: `translateX(${checked ? 16 : 0}px)`,
            transition: 'transform .15s',
          }} />
        </span>
        <input type="checkbox" checked={checked} onChange={(e) => onChange(e.target.checked)} style={{ display: 'none' }} />
      </label>
    );
  }

  // ─── VEmpty (small empty state) ──────────────────────────────────────
  function VEmpty({ icon, title, body, action }) {
    const t = window.theme;
    return (
      <div style={{
        padding: '40px 20px', textAlign: 'center', color: t.fg3,
      }}>
        {icon && (
          <div style={{
            width: 44, height: 44, borderRadius: 12,
            background: 'rgba(255,255,255,0.04)', display: 'inline-flex',
            alignItems: 'center', justifyContent: 'center', color: t.fg2,
            marginBottom: 14,
          }}><Icon name={icon} size={20} /></div>
        )}
        {title && <div style={{ font: `500 14px/1.3 ${t.fonts.body}`, color: t.fg, marginBottom: 6 }}>{title}</div>}
        {body && <div style={{ font: `400 13px/1.5 ${t.fonts.body}`, color: t.fg3, maxWidth: 360, margin: '0 auto' }}>{body}</div>}
        {action}
      </div>
    );
  }

  // ─── helpers ─────────────────────────────────────────────────────────
  function sectionTitle(text, t) {
    return (
      <div style={{ font: `500 10px/1 ${t.fonts.mono}`, color: t.fg3, letterSpacing: '0.18em', textTransform: 'uppercase' }}>
        {text}
      </div>
    );
  }

  // Account labels and icon hints
  const ACCOUNT_LABELS = {
    checking: 'Cuenta corriente', savings: 'Ahorros',
    credit_card: 'Tarjeta de crédito', wallet: 'Efectivo', loan: 'Préstamo',
  };
  const ACCOUNT_ICONS = {
    checking: 'credit', savings: 'pig',
    credit_card: 'credit', wallet: 'wallet', loan: 'credit',
  };

  // ─── publish ─────────────────────────────────────────────────────────
  window.V = {
    fmt, fmtPct, fmtDate, Icon, ICONS,
    VCard, VButton, VIconButton, VBadge, VAvatar,
    VProgress, VSpark, VMiniBars,
    VInput, VChip, VToggle, VEmpty,
    sectionTitle,
    ACCOUNT_LABELS, ACCOUNT_ICONS,
  };
})();
