// Vault · Login — personal, single-user.
// Just for Beno. Email pre-filled, password, one button. Clean and classy.

(function () {
  const { useState } = React;
  const { VButton, Icon } = window.V;

  function Login({ onContinue }) {
    const t = window.theme;
    const [pw, setPw] = useState('••••••••••');
    const [showPw, setShowPw] = useState(false);

    return (
      <div style={{
        minHeight: '100vh', width: '100%',
        background: `
          radial-gradient(60% 50% at 50% 0%, ${t.accent.b}1a, transparent 70%),
          radial-gradient(40% 40% at 50% 100%, ${t.accent.a}10, transparent 70%),
          ${t.bg}
        `,
        color: t.fg,
        font: `400 14px/1.5 ${t.fonts.body}`,
        display: 'flex', alignItems: 'center', justifyContent: 'center',
        padding: 40,
        position: 'relative',
      }}>
        {/* tiny mark — top-left */}
        <div style={{
          position: 'absolute', top: 28, left: 32,
          display: 'flex', alignItems: 'center', gap: 10,
        }}>
          <span style={{
            width: 32, height: 32, borderRadius: 10,
            background: t.accentGradient,
            display: 'flex', alignItems: 'center', justifyContent: 'center',
            color: '#0b0d18', fontWeight: 800, fontSize: 15,
            fontFamily: t.fonts.display,
            boxShadow: `0 8px 24px -8px ${t.accent.b}88`,
          }}>L</span>
          <span style={{ font: `600 14px/1 ${t.fonts.display}`, color: t.fg2 }}>Ledger</span>
        </div>

        {/* center card */}
        <div style={{
          width: 380, maxWidth: '100%',
          display: 'flex', flexDirection: 'column', alignItems: 'stretch',
          gap: 28,
        }}>
          {/* greeting */}
          <div style={{ textAlign: 'center' }}>
            <div style={{ font: `500 11px/1 ${t.fonts.mono}`, color: t.fg3, letterSpacing: '0.2em', textTransform: 'uppercase', marginBottom: 14 }}>
              Welcome back
            </div>
            <h1 style={{
              margin: 0,
              font: `500 44px/1.05 ${t.fonts.display}`,
              color: t.fg, letterSpacing: '-0.022em',
            }}>
              Hi <span style={{ color: t.accent.a }}>Beno</span>.
            </h1>
            <p style={{
              margin: '12px 0 0',
              font: `400 14px/1.5 ${t.fonts.body}`, color: t.fg3,
            }}>
              Sign in to continue to your ledger.
            </p>
          </div>

          {/* fields */}
          <form onSubmit={(e) => { e.preventDefault(); onContinue && onContinue(); }}
            style={{ display: 'grid', gap: 12 }}>
            {/* email — pre-filled, deemphasized to suggest "you" */}
            <div style={{
              display: 'flex', alignItems: 'center', gap: 12,
              padding: '14px 16px',
              background: 'rgba(255,255,255,0.025)',
              border: `1px solid ${t.card.border}`,
              borderRadius: 12,
            }}>
              <span style={{
                width: 32, height: 32, borderRadius: '50%',
                background: t.accentGradient, color: '#0b0d18',
                display: 'flex', alignItems: 'center', justifyContent: 'center',
                fontWeight: 700, fontSize: 12, flexShrink: 0,
                fontFamily: t.fonts.body,
              }}>B</span>
              <div style={{ flex: 1, minWidth: 0 }}>
                <div style={{ font: `500 13px/1.2 ${t.fonts.body}`, color: t.fg }}>Beno</div>
                <div style={{ font: `400 12px/1 ${t.fonts.mono}`, color: t.fg3, marginTop: 4 }}>beno@ledger.app</div>
              </div>
              <button type="button" style={{
                background: 'transparent', border: 'none', cursor: 'pointer',
                color: t.fg3, font: `500 12px/1 ${t.fonts.body}`,
              }}>switch</button>
            </div>

            {/* password */}
            <div style={{
              display: 'flex', alignItems: 'center', gap: 12,
              padding: '14px 16px',
              background: 'rgba(255,255,255,0.025)',
              border: `1px solid ${t.card.border}`,
              borderRadius: 12,
            }}>
              <div style={{ flex: 1, minWidth: 0 }}>
                <div style={{ font: `500 10px/1 ${t.fonts.mono}`, color: t.fg3, letterSpacing: '0.16em', textTransform: 'uppercase', marginBottom: 6 }}>
                  Password
                </div>
                <input
                  type={showPw ? 'text' : 'password'}
                  value={pw}
                  onChange={(e) => setPw(e.target.value)}
                  autoFocus
                  style={{
                    background: 'transparent', border: 'none', outline: 'none',
                    color: t.fg, font: `500 16px/1.2 ${t.fonts.mono}`,
                    letterSpacing: showPw ? '0.04em' : '0.18em',
                    width: '100%', padding: 0,
                  }} />
              </div>
              <button type="button" onClick={() => setShowPw(s => !s)} style={{
                background: 'transparent', border: 'none', cursor: 'pointer',
                color: t.fg3, padding: 6, borderRadius: 8,
                display: 'flex', alignItems: 'center', justifyContent: 'center',
              }} title={showPw ? 'Hide' : 'Show'}>
                <Icon name="eye" size={18} />
              </button>
            </div>

            <VButton variant="primary" size="lg" fullWidth iconRight="arrowRight"
              onClick={onContinue} style={{ marginTop: 4 }}>
              Continue
            </VButton>
          </form>

          {/* tiny secondary action */}
          <div style={{ textAlign: 'center' }}>
            <button style={{
              background: 'transparent', border: 'none', cursor: 'pointer',
              color: t.fg3, font: `400 12px/1 ${t.fonts.body}`,
            }}>Forgot your password?</button>
          </div>
        </div>

        {/* tiny footer */}
        <div style={{
          position: 'absolute', bottom: 24, left: 0, right: 0, textAlign: 'center',
          font: `400 11px/1 ${t.fonts.mono}`, color: t.fg4, letterSpacing: '0.08em',
        }}>
          Ledger · personal
        </div>
      </div>
    );
  }

  window.VaultLogin = Login;
})();
