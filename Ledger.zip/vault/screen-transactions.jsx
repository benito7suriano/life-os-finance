// Vault · Transactions list + filters + detail modal

(function () {
  const { useState, useMemo, useEffect } = React;
  const { fmt, fmtDate, VCard, VButton, VBadge, VChip, VInput, VIconButton, VToggle, VEmpty, Icon } = window.V;

  // ─── Filter bar ───────────────────────────────────────────────────
  function Filters({ filters, setFilters, accounts, cats }) {
    const t = window.theme;
    return (
      <VCard pad={16}>
        <div style={{ display: 'flex', gap: 10, alignItems: 'center', flexWrap: 'wrap' }}>
          <VInput icon="search" placeholder="Search by merchant or note…" value={filters.q}
            onChange={(e) => setFilters({ ...filters, q: e.target.value })}
            style={{ minWidth: 280, flex: 1 }} kbd="⌘K" />

          <div style={{ display: 'flex', gap: 6, flexWrap: 'wrap' }}>
            {[
              { v: 'all', l: 'All' },
              { v: '7d', l: '7 days' },
              { v: '30d', l: '30 days' },
              { v: 'mtd', l: 'MTD', icon: 'calendar' },
              { v: 'ytd', l: 'YTD' },
            ].map(o => (
              <VChip key={o.v} active={filters.range === o.v} icon={o.icon}
                onClick={() => setFilters({ ...filters, range: o.v })}>{o.l}</VChip>
            ))}
          </div>

          <span style={{ width: 1, height: 24, background: t.card.border }} />

          <div style={{ display: 'flex', gap: 6, flexWrap: 'wrap' }}>
            {[
              { v: 'all',     l: 'All' },
              { v: 'expense', l: 'Expense', icon: 'arrowDownLeft' },
              { v: 'income',  l: 'Income',  icon: 'arrowUpRight' },
            ].map(o => (
              <VChip key={o.v} active={filters.type === o.v} icon={o.icon}
                onClick={() => setFilters({ ...filters, type: o.v })}>{o.l}</VChip>
            ))}
          </div>

          <span style={{ width: 1, height: 24, background: t.card.border }} />

          <div style={{ display: 'flex', gap: 6, flexWrap: 'wrap' }}>
            {[
              { v: 'all',      l: 'All sources' },
              { v: 'telegram', l: 'Telegram',    icon: 'sendMoney' },
              { v: 'manual',   l: 'Manual',      icon: 'edit' },
            ].map(o => (
              <VChip key={o.v} active={filters.source === o.v} icon={o.icon}
                onClick={() => setFilters({ ...filters, source: o.v })}>{o.l}</VChip>
            ))}
          </div>

          <span style={{ flex: 1 }} />
          <VButton variant="ghost" icon="download" size="sm">Export</VButton>
        </div>
      </VCard>
    );
  }

  // ─── Summary strip ────────────────────────────────────────────────
  function SummaryStrip({ filtered }) {
    const t = window.theme;
    const total = filtered.reduce((s, tr) => s + tr.amount, 0);
    const expenses = filtered.filter(tr => tr.amount < 0).reduce((s, tr) => s + Math.abs(tr.amount), 0);
    const income = filtered.filter(tr => tr.amount > 0).reduce((s, tr) => s + tr.amount, 0);
    const avgTxn = filtered.length ? expenses / filtered.filter(tr => tr.amount < 0).length || 0 : 0;
    const autoCount = filtered.filter(tr => tr.source === 'telegram').length;
    const stats = [
      { l: 'Total movimientos', v: filtered.length },
      { l: 'Ingresos',          v: fmt(income),  c: t.good },
      { l: 'Gastos',            v: fmt(expenses), c: t.bad },
      { l: 'Promedio gasto',    v: fmt(avgTxn) },
      { l: 'Auto-capturados',   v: `${autoCount} · ${filtered.length ? Math.round(autoCount/filtered.length*100) : 0}%`, c: t.accent.a },
    ];
    return (
      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(5, 1fr)', gap: 16 }}>
        {stats.map((s, i) => (
          <VCard key={i} pad={16}>
            <div style={{ font: `400 11px/1 ${t.fonts.mono}`, color: t.fg3, letterSpacing: '0.14em', textTransform: 'uppercase' }}>{s.l}</div>
            <div style={{ font: `600 22px/1 ${t.fonts.display}`, color: s.c || t.fg, marginTop: 8 }}>{s.v}</div>
          </VCard>
        ))}
      </div>
    );
  }

  // ─── Transaction row ──────────────────────────────────────────────
  function TxnRow({ tr, accounts, cats, onClick }) {
    const t = window.theme;
    const isInc = tr.amount > 0;
    const acc = accounts.find(a => a.id === tr.account);
    const cat = cats.find(c => c.name === tr.cat);
    const catColor = cat?.color || t.fg3;
    return (
      <button onClick={onClick} style={{
        width: '100%', textAlign: 'left',
        display: 'grid',
        gridTemplateColumns: '34px 1.4fr 1fr 0.8fr 90px 120px',
        gap: 16, alignItems: 'center',
        padding: '14px 20px',
        background: 'transparent', border: 'none',
        borderTop: `1px solid ${t.card.border}`,
        cursor: 'pointer',
        transition: 'background .12s',
      }} onMouseEnter={(e) => e.currentTarget.style.background = 'rgba(255,255,255,0.02)'}
         onMouseLeave={(e) => e.currentTarget.style.background = 'transparent'}>
        <span style={{
          width: 30, height: 30, borderRadius: 8,
          background: isInc ? 'rgba(74,222,128,0.12)' : t.accent.soft,
          color: isInc ? t.good : t.accent.a,
          display: 'flex', alignItems: 'center', justifyContent: 'center',
        }}><Icon name={isInc ? 'arrowUpRight' : 'arrowDownLeft'} size={14} /></span>
        <div style={{ minWidth: 0 }}>
          <div style={{ font: `500 14px/1.2 ${t.fonts.body}`, color: t.fg, overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>{tr.desc}</div>
          {tr.note && <div style={{ font: `400 11px/1.3 ${t.fonts.body}`, color: t.fg3, marginTop: 3, overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>{tr.note}</div>}
        </div>
        <div style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
          <span style={{ width: 8, height: 8, borderRadius: '50%', background: catColor }} />
          <span style={{ font: `400 12px/1 ${t.fonts.body}`, color: t.fg2 }}>{tr.cat}</span>
        </div>
        <span style={{ font: `400 12px/1 ${t.fonts.body}`, color: t.fg2 }}>{acc?.name || ''}</span>
        <span style={{ font: `400 11px/1.3 ${t.fonts.mono}`, color: t.fg3 }}>
          {tr.date.slice(5).replace('-','/')}<br />
          <span style={{ color: t.fg4 }}>{tr.time}</span>
        </span>
        <span style={{ font: `500 14px/1 ${t.fonts.mono}`, color: isInc ? t.good : t.fg, textAlign: 'right' }}>
          {isInc ? '+' : '\u2212'}${Math.abs(tr.amount).toFixed(2)}
        </span>
      </button>
    );
  }

  // ─── Group header ─────────────────────────────────────────────────
  function GroupHeader({ date, sum, count }) {
    const t = window.theme;
    const day = new Date(date);
    const today = new Date(); today.setHours(0,0,0,0);
    const yest = new Date(today); yest.setDate(yest.getDate()-1);
    let label;
    if (day.toDateString() === today.toDateString()) label = 'Hoy';
    else if (day.toDateString() === yest.toDateString()) label = 'Ayer';
    else label = day.toLocaleDateString('es-SV', { weekday: 'long', day: 'numeric', month: 'long' });
    return (
      <div style={{
        display: 'flex', alignItems: 'center', gap: 14,
        padding: '14px 20px',
        background: 'rgba(255,255,255,0.015)',
        borderTop: `1px solid ${t.card.border}`,
      }}>
        <span style={{ font: `500 12px/1 ${t.fonts.body}`, color: t.fg, letterSpacing: '0.02em', textTransform: 'capitalize' }}>
          {label}
        </span>
        <span style={{ font: `400 11px/1 ${t.fonts.mono}`, color: t.fg3 }}>{date}</span>
        <span style={{ flex: 1 }} />
        <span style={{ font: `400 11px/1 ${t.fonts.mono}`, color: t.fg3 }}>{count} txn{count !== 1 ? 's' : ''}</span>
        <span style={{ font: `500 12px/1 ${t.fonts.mono}`, color: sum < 0 ? t.fg : t.good }}>
          {sum >= 0 ? '+' : '\u2212'}${Math.abs(sum).toFixed(2)}
        </span>
      </div>
    );
  }

  // ─── Filter + group helper ────────────────────────────────────────
  function useFiltered(filters, data) {
    return useMemo(() => {
      let list = [...data.transactions];
      if (filters.q) {
        const q = filters.q.toLowerCase();
        list = list.filter(tr => tr.desc.toLowerCase().includes(q) || tr.note.toLowerCase().includes(q) || tr.cat.toLowerCase().includes(q));
      }
      if (filters.type === 'expense') list = list.filter(tr => tr.amount < 0);
      if (filters.type === 'income')  list = list.filter(tr => tr.amount > 0);
      if (filters.source !== 'all')   list = list.filter(tr => tr.source === filters.source);
      // range filter is mostly cosmetic in this prototype since dates are static
      return list;
    }, [filters, data]);
  }

  function groupByDate(list) {
    const groups = {};
    for (const tr of list) {
      (groups[tr.date] = groups[tr.date] || []).push(tr);
    }
    return Object.entries(groups).sort((a, b) => a[0] < b[0] ? 1 : -1);
  }

  // ─── Detail modal ─────────────────────────────────────────────────
  function TxnDetailModal({ open, txn, onClose }) {
    const t = window.theme;
    const d = window.VAULT_DATA;
    if (!txn) return null;
    const acc = d.accounts.find(a => a.id === txn.account);
    const cat = d.categories.find(c => c.name === txn.cat);
    const isInc = txn.amount > 0;
    return (
      <window.VShell.Modal open={open} onClose={onClose} width={580}>
        {/* Header band */}
        <div style={{ padding: '24px 24px 18px', borderBottom: `1px solid ${t.card.border}`, position: 'relative' }}>
          <div aria-hidden style={{
            position: 'absolute', right: 0, top: 0, bottom: 0, width: 200,
            background: `radial-gradient(circle at right, ${cat?.color || t.accent.a}22, transparent 70%)`,
            pointerEvents: 'none',
          }} />
          <div style={{ display: 'flex', alignItems: 'center', gap: 12, position: 'relative' }}>
            <span style={{
              width: 40, height: 40, borderRadius: 12,
              background: isInc ? 'rgba(74,222,128,0.16)' : `${cat?.color || t.accent.a}22`,
              color: isInc ? t.good : (cat?.color || t.accent.a),
              display: 'flex', alignItems: 'center', justifyContent: 'center',
            }}><Icon name={isInc ? 'arrowUpRight' : 'arrowDownLeft'} size={20} /></span>
            <div style={{ flex: 1, minWidth: 0 }}>
              <div style={{ font: `400 11px/1 ${t.fonts.mono}`, color: t.fg3, letterSpacing: '0.12em', textTransform: 'uppercase', marginBottom: 4 }}>
                {isInc ? 'income' : 'expense'}
              </div>
              <div style={{ font: `600 22px/1.2 ${t.fonts.display}`, color: t.fg, letterSpacing: '-0.01em' }}>{txn.desc}</div>
            </div>
            <button onClick={onClose} style={{
              width: 36, height: 36, borderRadius: 10, border: 'none',
              background: 'rgba(255,255,255,0.04)', color: t.fg2, cursor: 'pointer',
              display: 'flex', alignItems: 'center', justifyContent: 'center',
            }}><Icon name="x" size={18} /></button>
          </div>
          {/* big amount */}
          <div style={{
            font: `600 56px/1 ${t.fonts.display}`,
            color: isInc ? t.good : t.fg,
            letterSpacing: '-0.025em', marginTop: 22,
            position: 'relative',
          }}>
            {isInc ? '+' : '\u2212'}${Math.abs(txn.amount).toFixed(2)}
          </div>
          <div style={{ display: 'flex', gap: 8, marginTop: 14 }}>
            {txn.source === 'telegram' && (
              <VBadge tone="accent" dot>auto · telegram</VBadge>
            )}
            {txn.source === 'manual' && <VBadge tone="neutral">manual entry</VBadge>}
            {cat && <VBadge style={{ color: cat.color, background: `${cat.color}22` }}>{cat.name}</VBadge>}
          </div>
        </div>

        {/* Metadata */}
        <div style={{ padding: '6px 24px' }}>
          {[
            { k: 'Cuenta',    v: <>{acc?.name} <span style={{ color: t.fg3, marginLeft: 6 }}>· {acc?.bank || 'Efectivo'}{acc?.last4 ? ` ····${acc.last4}` : ''}</span></> },
            { k: 'Fecha',     v: <>{txn.date} <span style={{ color: t.fg3, marginLeft: 6 }}>· {txn.time}</span></> },
            { k: 'Merchant',  v: txn.merchant },
            { k: 'Categoría', v: (
              <div style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
                <span style={{ width: 10, height: 10, borderRadius: '50%', background: cat?.color }} />
                <span>{txn.cat}</span>
                <button style={{ background: 'transparent', border: 'none', color: t.accent.a, font: `500 12px/1 ${t.fonts.body}`, cursor: 'pointer', marginLeft: 4 }}>Change →</button>
              </div>
            ) },
            { k: 'Origen', v: txn.source === 'telegram'
              ? <span style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
                  <span style={{ width: 16, height: 16, borderRadius: 4, background: 'linear-gradient(135deg, #29b6f6, #0288d1)' }} />
                  Telegram · @ledger_bot
                </span>
              : 'Manual' },
            { k: 'Nota', v: txn.note ? <span style={{ color: t.fg }}>{txn.note}</span> : <span style={{ color: t.fg3, fontStyle: 'italic' }}>Sin nota</span> },
          ].map((row, i) => (
            <div key={i} style={{
              display: 'grid', gridTemplateColumns: '120px 1fr', gap: 14,
              padding: '12px 0',
              borderTop: i ? `1px dashed ${t.card.border}` : 'none',
              font: `400 13px/1.4 ${t.fonts.body}`,
              alignItems: 'baseline',
            }}>
              <span style={{ color: t.fg3, font: `500 11px/1 ${t.fonts.mono}`, letterSpacing: '0.12em', textTransform: 'uppercase' }}>{row.k}</span>
              <span style={{ color: t.fg }}>{row.v}</span>
            </div>
          ))}
        </div>

        {/* Telegram original message preview (only for telegram-sourced) */}
        {txn.source === 'telegram' && (
          <div style={{ padding: '14px 24px 20px' }}>
            <div style={{ font: `500 11px/1 ${t.fonts.mono}`, color: t.fg3, letterSpacing: '0.14em', textTransform: 'uppercase', marginBottom: 10 }}>
              Mensaje original
            </div>
            <div style={{
              background: 'rgba(41, 182, 246, 0.08)',
              border: `1px solid rgba(41, 182, 246, 0.18)`,
              borderRadius: 14,
              padding: '12px 14px',
              maxWidth: 360,
              position: 'relative',
              borderTopLeftRadius: 4,
            }}>
              <div style={{ font: `400 13px/1.5 ${t.fonts.body}`, color: t.fg }}>"Pagué 45.32 en Super Selectos"</div>
              <div style={{ font: `400 11px/1 ${t.fonts.mono}`, color: t.fg3, marginTop: 8, display: 'flex', justifyContent: 'space-between' }}>
                <span>@beno</span><span>14:32 · enero 23</span>
              </div>
            </div>
            <div style={{ font: `400 12px/1.4 ${t.fonts.body}`, color: t.fg3, marginTop: 10 }}>
              Bot logged this transaction <strong style={{ color: t.fg2 }}>0.4s</strong> after receipt. Confidence: <strong style={{ color: t.good }}>98%</strong>.
            </div>
          </div>
        )}

        {/* Footer actions */}
        <div style={{
          padding: '16px 24px',
          borderTop: `1px solid ${t.card.border}`,
          display: 'flex', gap: 10, justifyContent: 'space-between',
          background: 'rgba(255,255,255,0.02)',
        }}>
          <VButton variant="danger" icon="trash" size="sm">Delete</VButton>
          <div style={{ display: 'flex', gap: 8 }}>
            <VButton variant="ghost" icon="arrowExchange" size="sm">Split</VButton>
            <VButton variant="secondary" icon="edit" size="sm">Edit</VButton>
            <VButton variant="primary" icon="check" size="sm" onClick={onClose}>Done</VButton>
          </div>
        </div>
      </window.VShell.Modal>
    );
  }

  // ─── Screen ───────────────────────────────────────────────────────
  function TransactionsScreen() {
    const t = window.theme;
    const d = window.VAULT_DATA;
    const [filters, setFilters] = useState({ q: '', range: 'mtd', type: 'all', source: 'all' });
    const [open, setOpen] = useState(null); // txn id

    // open from hash if dashboard linked to a specific txn
    useEffect(() => {
      const h = window.location.hash;
      const m = h.match(/transactions\?id=(t\d+)/);
      if (m) {
        setOpen(m[1]);
        window.location.hash = 'transactions';
      }
    }, []);

    const filtered = useFiltered(filters, d);
    const groups = groupByDate(filtered);
    const txn = open && d.transactions.find(tr => tr.id === open);

    return (
      <div style={{ padding: '24px 32px 40px', display: 'grid', gap: 16 }}>
        <SummaryStrip filtered={filtered} />
        <Filters filters={filters} setFilters={setFilters} accounts={d.accounts} cats={d.categories} />
        <VCard pad={0} style={{ overflow: 'hidden' }}>
          {/* sticky-ish header */}
          <div style={{
            display: 'grid',
            gridTemplateColumns: '34px 1.4fr 1fr 0.8fr 90px 120px',
            gap: 16,
            padding: '14px 20px',
            font: `500 10px/1 ${t.fonts.mono}`,
            color: t.fg3, letterSpacing: '0.16em', textTransform: 'uppercase',
          }}>
            <span></span>
            <span>Description</span>
            <span>Category</span>
            <span>Account</span>
            <span>Date</span>
            <span style={{ textAlign: 'right' }}>Amount</span>
          </div>
          {groups.length === 0 ? (
            <VEmpty icon="search" title="No matches" body="Try clearing some filters." />
          ) : groups.map(([date, items]) => {
            const sum = items.reduce((s, tr) => s + tr.amount, 0);
            return (
              <React.Fragment key={date}>
                <GroupHeader date={date} sum={sum} count={items.length} />
                {items.map(tr => (
                  <TxnRow key={tr.id} tr={tr} accounts={d.accounts} cats={d.categories}
                    onClick={() => setOpen(tr.id)} />
                ))}
              </React.Fragment>
            );
          })}
          <div style={{
            padding: '14px 20px',
            font: `400 12px/1 ${t.fonts.body}`,
            color: t.fg3,
            borderTop: `1px solid ${t.card.border}`,
            textAlign: 'center',
          }}>
            Showing {filtered.length} transactions
          </div>
        </VCard>

        <TxnDetailModal open={!!txn} txn={txn} onClose={() => setOpen(null)} />
      </div>
    );
  }

  window.VaultTransactions = TransactionsScreen;
})();
