// Vault app shell — fixed left sidebar, top bar, and a routed main area.
// Routes are kept in URL hash so a refresh keeps you in place.

(function () {
  const { useState, useEffect, useCallback } = React;

  // ─── route handling ─────────────────────────────────────────────────
  const ROUTES = ['dashboard', 'transactions', 'accounts', 'budgets', 'automation', 'settings', 'login'];
  function useRoute() {
    const initial = (() => {
      const h = window.location.hash.replace('#', '');
      return ROUTES.includes(h) ? h : 'dashboard';
    })();
    const [route, setRoute] = useState(initial);
    useEffect(() => {
      const onHash = () => {
        const h = window.location.hash.replace('#', '');
        if (ROUTES.includes(h)) setRoute(h);
      };
      window.addEventListener('hashchange', onHash);
      return () => window.removeEventListener('hashchange', onHash);
    }, []);
    const go = useCallback((r) => {
      window.location.hash = r;
      setRoute(r);
    }, []);
    return [route, go];
  }

  // ─── sidebar item ───────────────────────────────────────────────────
  function SidebarItem({ icon, label, active, onClick }) {
    const t = window.theme;
    const [hover, setHover] = useState(false);
    return (
      <button onClick={onClick} title={label}
        onMouseEnter={() => setHover(true)} onMouseLeave={() => setHover(false)}
        style={{
          width: 52, height: 52, borderRadius: 14, border: 'none',
          background: active ? t.accent.soft : hover ? 'rgba(255,255,255,0.04)' : 'transparent',
          color: active ? t.accent.a : t.fg3,
          display: 'flex', alignItems: 'center', justifyContent: 'center',
          cursor: 'pointer', position: 'relative',
          transition: 'background .15s, color .15s',
        }}>
        <V.Icon name={icon} size={22} />
        {active && (
          <span style={{
            position: 'absolute', left: -3, top: '50%', transform: 'translateY(-50%)',
            width: 3, height: 22, background: t.accent.solid, borderRadius: 2,
            boxShadow: `0 0 8px ${t.accent.solid}`,
          }} />
        )}
      </button>
    );
  }

  // ─── Sidebar ────────────────────────────────────────────────────────
  function Sidebar({ route, go }) {
    const t = window.theme;
    return (
      <aside style={{
        background: 'rgba(255,255,255,0.02)',
        borderRight: `1px solid ${t.card.border}`,
        padding: '22px 0',
        display: 'flex', flexDirection: 'column', alignItems: 'center', gap: 6,
      }}>
        {/* logo */}
        <button onClick={() => go('dashboard')} style={{
          width: 44, height: 44, borderRadius: 14, border: 'none',
          background: t.accentGradient,
          display: 'flex', alignItems: 'center', justifyContent: 'center',
          color: '#0b0d18', fontWeight: 800, fontSize: 18, letterSpacing: '0.05em',
          marginBottom: 24, cursor: 'pointer',
          boxShadow: `0 8px 24px -8px ${t.accent.b}88`,
          fontFamily: t.fonts.display,
        }}>L</button>
        {[
          { id: 'dashboard',    icon: 'dashboard',    label: 'Dashboard' },
          { id: 'transactions', icon: 'transactions', label: 'Transactions' },
          { id: 'accounts',     icon: 'wallet',       label: 'Accounts' },
          { id: 'budgets',      icon: 'pig',          label: 'Budgets' },
          { id: 'automation',   icon: 'bot',          label: 'Automation' },
        ].map(it => (
          <SidebarItem key={it.id} icon={it.icon} label={it.label}
            active={route === it.id} onClick={() => go(it.id)} />
        ))}
        <div style={{ flex: 1 }} />
        <SidebarItem icon="settings" label="Settings"
          active={route === 'settings'} onClick={() => go('settings')} />
        <SidebarItem icon="help" label="Help" onClick={() => {}} />
      </aside>
    );
  }

  // ─── TopBar ─────────────────────────────────────────────────────────
  function TopBar({ route, onOpenTweaks, onNewTransaction }) {
    const t = window.theme;
    const d = window.VAULT_DATA;
    const titles = {
      dashboard: 'Dashboard',
      transactions: 'Transactions',
      accounts: 'Accounts',
      budgets: 'Budgets',
      automation: 'Automation',
      settings: 'Settings',
    };
    return (
      <header style={{ display: 'flex', alignItems: 'center', gap: 14, padding: '20px 32px 20px 24px', borderBottom: `1px solid ${t.card.border}` }}>
        <div>
          <div style={{ font: `400 11px/1 ${t.fonts.mono}`, color: t.fg3, letterSpacing: '0.12em', textTransform: 'uppercase' }}>
            {new Date().toLocaleDateString('es-SV', { weekday: 'long', day: 'numeric', month: 'long' })}
          </div>
          <div style={{ font: `600 22px/1.1 ${t.fonts.display}`, color: t.fg, marginTop: 4, letterSpacing: '-0.01em' }}>
            {titles[route]}
          </div>
        </div>
        <div style={{ flex: 1 }} />
        <V.VInput icon="search" placeholder="Search transactions, accounts, categories…" kbd="⌘K" style={{ minWidth: 360 }} />
        <V.VButton variant="primary" icon="plus" onClick={onNewTransaction}>New transaction</V.VButton>
        <V.VIconButton icon="bell" badge label="Notifications" />
        <V.VIconButton icon="sliders" label="Tweaks" onClick={onOpenTweaks} />
        <V.VAvatar initials={d.user.initials} size={40} />
      </header>
    );
  }

  // ─── Drawer (right-side overlay, used for account/txn details) ──────
  function Drawer({ open, onClose, width=460, children }) {
    const t = window.theme;
    useEffect(() => {
      const k = (e) => { if (e.key === 'Escape') onClose && onClose(); };
      if (open) document.addEventListener('keydown', k);
      return () => document.removeEventListener('keydown', k);
    }, [open, onClose]);
    return (
      <>
        <div onClick={onClose} style={{
          position: 'absolute', inset: 0, background: 'rgba(0,0,0,0.5)',
          opacity: open ? 1 : 0, pointerEvents: open ? 'auto' : 'none',
          transition: 'opacity .2s', zIndex: 50,
          backdropFilter: 'blur(2px)',
        }} />
        <div style={{
          position: 'absolute', right: 0, top: 0, bottom: 0, width,
          background: t.bg2,
          borderLeft: `1px solid ${t.card.border}`,
          transform: `translateX(${open ? 0 : width}px)`,
          transition: 'transform .25s cubic-bezier(.2,.7,.3,1)',
          zIndex: 51,
          overflow: 'auto',
          boxShadow: '-30px 0 80px -30px rgba(0,0,0,0.7)',
        }}>
          {children}
        </div>
      </>
    );
  }

  // ─── Modal (centered overlay) ───────────────────────────────────────
  function Modal({ open, onClose, width=560, children }) {
    const t = window.theme;
    useEffect(() => {
      const k = (e) => { if (e.key === 'Escape') onClose && onClose(); };
      if (open) document.addEventListener('keydown', k);
      return () => document.removeEventListener('keydown', k);
    }, [open, onClose]);
    if (!open) return null;
    return (
      <div style={{
        position: 'absolute', inset: 0, zIndex: 60,
        background: 'rgba(0,0,0,0.6)', backdropFilter: 'blur(3px)',
        display: 'flex', alignItems: 'center', justifyContent: 'center',
      }} onClick={onClose}>
        <div onClick={(e) => e.stopPropagation()} style={{
          width, maxWidth: '90%', maxHeight: '85%',
          background: t.bg2,
          border: `1px solid ${t.card.border}`,
          borderRadius: 18,
          overflow: 'auto',
          boxShadow: '0 40px 100px -30px rgba(0,0,0,0.7)',
        }}>
          {children}
        </div>
      </div>
    );
  }

  window.VShell = { useRoute, Sidebar, TopBar, Drawer, Modal };
})();
