// Vault · Accounts overview + per-account drawer

(function () {
  const { useState, useMemo } = React;
  const { fmt, fmtPct, VCard, VButton, VBadge, VSpark, VProgress, VIconButton, Icon, ACCOUNT_LABELS } = window.V;

  // ─── Decorative card visual that adapts to account type/color ──────
  function AccountChip({ account }) {
    const t = window.theme;
    const debt = account.type === 'credit_card' || account.type === 'loan';
    // pick a tint per account so each looks distinct
    const tints = {
      a1: ['#3b82f6', '#1e40af'],
      a2: ['#10b981', '#047857'],
      a3: [t.accent.a, t.accent.b],
      a4: ['#f59e0b', '#b45309'],
    };
    const tint = tints[account.id] || [t.accent.a, t.accent.b];
    return (
      <div style={{
        width: '100%', aspectRatio: '1.7/1', borderRadius: 14, position: 'relative', overflow: 'hidden',
        background: `
          radial-gradient(120% 100% at 0% 0%, rgba(255,255,255,0.4), transparent 50%),
          linear-gradient(135deg, ${tint[1]} 0%, ${tint[0]} 100%)
        `,
        boxShadow: `0 18px 36px -22px ${tint[1]}aa`,
        color: '#fff',
        padding: 14, boxSizing: 'border-box',
        display: 'flex', flexDirection: 'column',
      }}>
        <div aria-hidden style={{
          position: 'absolute', inset: 0,
          backgroundImage: 'repeating-linear-gradient(115deg, rgba(255,255,255,0.06) 0 2px, transparent 2px 14px)',
          mixBlendMode: 'overlay',
        }} />
        <div style={{ position: 'relative', display: 'flex', alignItems: 'center', justifyContent: 'space-between' }}>
          <span style={{ font: `500 11px/1 ${t.fonts.mono}`, letterSpacing: '0.12em', textTransform: 'uppercase', opacity: 0.8 }}>
            {ACCOUNT_LABELS[account.type]}
          </span>
          {account.type === 'credit_card' && (
            <span style={{ font: `500 10px/1 ${t.fonts.mono}`, opacity: 0.7 }}>VISA</span>
          )}
        </div>
        <div style={{ position: 'relative', marginTop: 'auto' }}>
          <div style={{ font: `600 14px/1.2 ${t.fonts.display}`, marginBottom: 4 }}>{account.name}</div>
          <div style={{ font: `400 11px/1 ${t.fonts.body}`, opacity: 0.7 }}>
            {account.bank || 'Efectivo'}{account.last4 ? ` ····${account.last4}` : ''}
          </div>
        </div>
      </div>
    );
  }

  // ─── Account card (grid item) ──────────────────────────────────────
  function AccountCard({ account, onOpen }) {
    const t = window.theme;
    const debt = account.type === 'credit_card' || account.type === 'loan';
    return (
      <VCard hoverable onClick={onOpen} pad={20}>
        <AccountChip account={account} />
        <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'baseline', marginTop: 16 }}>
          <span style={{ font: `400 11px/1 ${t.fonts.mono}`, color: t.fg3, letterSpacing: '0.14em', textTransform: 'uppercase' }}>
            {debt ? 'deuda' : 'saldo'}
          </span>
          {account.type === 'credit_card' && (
            <VBadge tone="neutral">{Math.round(Math.abs(account.balance)/account.limit*100)}% utilizado</VBadge>
          )}
          {account.type === 'savings' && account.apy && (
            <VBadge tone="good">{account.apy}% APY</VBadge>
          )}
        </div>
        <div style={{ font: `600 32px/1 ${t.fonts.display}`, color: debt ? t.bad : t.fg, marginTop: 8, letterSpacing: '-0.02em' }}>
          {debt ? '\u2212' : ''}${Math.abs(account.balance).toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
        </div>
        <div style={{ display: 'flex', justifyContent: 'space-between', marginTop: 12 }}>
          <span style={{
            font: `500 12px/1 ${t.fonts.mono}`,
            color: account.change > 0 ? t.good : account.change < 0 ? t.bad : t.fg3,
          }}>
            {account.change > 0 ? '↑' : account.change < 0 ? '↓' : '·'} {fmt(account.change, { sign: true })} este mes
          </span>
          <Icon name="chevronRight" size={16} style={{ color: t.fg3 }} />
        </div>
      </VCard>
    );
  }

  // ─── "Add account" placeholder card ─────────────────────────────────
  function AddAccountCard() {
    const t = window.theme;
    return (
      <button style={{
        background: 'transparent',
        border: `2px dashed ${t.card.border}`,
        borderRadius: t.card.radius,
        padding: 20, minHeight: 240,
        color: t.fg3, font: `500 14px/1.4 ${t.fonts.body}`,
        cursor: 'pointer',
        display: 'flex', alignItems: 'center', justifyContent: 'center', flexDirection: 'column', gap: 10,
        transition: 'border-color .15s, color .15s',
      }} onMouseEnter={(e) => { e.currentTarget.style.borderColor = t.accent.a; e.currentTarget.style.color = t.accent.a; }}
         onMouseLeave={(e) => { e.currentTarget.style.borderColor = t.card.border; e.currentTarget.style.color = t.fg3; }}>
        <span style={{
          width: 36, height: 36, borderRadius: 10,
          background: 'rgba(255,255,255,0.04)',
          display: 'flex', alignItems: 'center', justifyContent: 'center',
        }}><Icon name="plus" size={18} /></span>
        Conectar otra cuenta
      </button>
    );
  }

  // ─── Per-account drawer ─────────────────────────────────────────────
  function AccountDrawer({ account, open, onClose }) {
    const t = window.theme;
    if (!account) return null;
    const d = window.VAULT_DATA;
    const accountTxns = d.transactions.filter(tr => tr.account === account.id).slice(0, 8);
    const debt = account.type === 'credit_card' || account.type === 'loan';

    // synthetic 6-month series
    const seriesByAccount = {
      a1: [2840, 2950, 3120, 3200, 3065, 3245.80],
      a2: [7500, 7700, 7850, 8200, 8350, 8500],
      a3: [-900, -1080, -1210, -890, -1080, -1420.80],
      a4: [220, 195, 170, 180, 170, 125],
    };
    const series = seriesByAccount[account.id] || [0,0,0,0,0,0];

    return (
      <window.VShell.Drawer open={open} onClose={onClose} width={480}>
        <div style={{ padding: '24px' }}>
          <div style={{ display: 'flex', alignItems: 'center', gap: 10, marginBottom: 18 }}>
            <span style={{ font: `400 11px/1 ${t.fonts.mono}`, color: t.fg3, letterSpacing: '0.14em', textTransform: 'uppercase' }}>
              Detalle de cuenta
            </span>
            <span style={{ flex: 1 }} />
            <VIconButton icon="x" onClick={onClose} label="Close" />
          </div>

          <AccountChip account={account} />

          <div style={{ marginTop: 22 }}>
            <div style={{ font: `400 11px/1 ${t.fonts.mono}`, color: t.fg3, letterSpacing: '0.14em', textTransform: 'uppercase' }}>
              {debt ? 'deuda' : 'saldo'}
            </div>
            <div style={{ font: `600 44px/1 ${t.fonts.display}`, color: debt ? t.bad : t.fg, letterSpacing: '-0.022em', marginTop: 6 }}>
              {debt ? '\u2212' : ''}${Math.abs(account.balance).toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
            </div>
            <div style={{ display: 'flex', alignItems: 'center', gap: 10, marginTop: 8 }}>
              <span style={{
                font: `500 13px/1 ${t.fonts.mono}`,
                color: account.change > 0 ? t.good : account.change < 0 ? t.bad : t.fg3,
              }}>
                {account.change > 0 ? '↑' : '↓'} {fmt(Math.abs(account.change))}
              </span>
              <span style={{ font: `400 12px/1 ${t.fonts.body}`, color: t.fg3 }}>vs último mes</span>
            </div>
          </div>

          {/* Sparkline */}
          <div style={{ marginTop: 22, padding: 16, background: 'rgba(255,255,255,0.025)', borderRadius: 14, border: `1px solid ${t.card.border}` }}>
            <div style={{ font: `400 11px/1 ${t.fonts.mono}`, color: t.fg3, letterSpacing: '0.14em', textTransform: 'uppercase', marginBottom: 12 }}>
              Últimos 6 meses
            </div>
            <VSpark data={series.map(v => Math.abs(v))} width={420} height={70} color={debt ? t.bad : t.accent.a} fill />
            <div style={{ display: 'flex', justifyContent: 'space-between', font: `400 10px/1 ${t.fonts.mono}`, color: t.fg3, marginTop: 6 }}>
              {['Ago','Sep','Oct','Nov','Dic','Ene'].map(l => <span key={l}>{l}</span>)}
            </div>
          </div>

          {/* Credit card specific: limit + due date */}
          {account.type === 'credit_card' && (
            <div style={{ marginTop: 16, padding: 16, background: 'rgba(255,255,255,0.025)', borderRadius: 14, border: `1px solid ${t.card.border}` }}>
              <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: 10 }}>
                <span style={{ font: `400 11px/1 ${t.fonts.mono}`, color: t.fg3, letterSpacing: '0.14em', textTransform: 'uppercase' }}>línea de crédito</span>
                <span style={{ font: `500 12px/1 ${t.fonts.mono}`, color: t.fg }}>${Math.abs(account.balance).toFixed(0)} / ${account.limit}</span>
              </div>
              <VProgress value={Math.abs(account.balance)/account.limit*100} color={`linear-gradient(90deg, ${t.warn}, ${t.bad})`} />
              <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 14, marginTop: 14 }}>
                <div>
                  <div style={{ font: `400 10px/1 ${t.fonts.mono}`, color: t.fg3, letterSpacing: '0.14em', textTransform: 'uppercase' }}>pago mínimo</div>
                  <div style={{ font: `500 16px/1 ${t.fonts.mono}`, color: t.fg, marginTop: 6 }}>${account.minPayment.toFixed(2)}</div>
                </div>
                <div>
                  <div style={{ font: `400 10px/1 ${t.fonts.mono}`, color: t.fg3, letterSpacing: '0.14em', textTransform: 'uppercase' }}>vence</div>
                  <div style={{ font: `500 16px/1 ${t.fonts.mono}`, color: t.warn, marginTop: 6 }}>5 feb</div>
                </div>
              </div>
              <VButton variant="primary" size="sm" fullWidth style={{ marginTop: 12 }}>Pagar tarjeta</VButton>
            </div>
          )}

          {/* Savings APY */}
          {account.type === 'savings' && (
            <div style={{ marginTop: 16, padding: 16, background: 'rgba(255,255,255,0.025)', borderRadius: 14, border: `1px solid ${t.card.border}` }}>
              <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
                <div>
                  <div style={{ font: `400 10px/1 ${t.fonts.mono}`, color: t.fg3, letterSpacing: '0.14em', textTransform: 'uppercase' }}>tasa de interés</div>
                  <div style={{ font: `500 24px/1 ${t.fonts.display}`, color: t.good, marginTop: 6 }}>{account.apy}% APY</div>
                </div>
                <div style={{ textAlign: 'right' }}>
                  <div style={{ font: `400 10px/1 ${t.fonts.mono}`, color: t.fg3, letterSpacing: '0.14em', textTransform: 'uppercase' }}>interés acumulado · ytd</div>
                  <div style={{ font: `500 18px/1 ${t.fonts.mono}`, color: t.fg, marginTop: 6 }}>$23.10</div>
                </div>
              </div>
            </div>
          )}

          {/* Recent transactions */}
          <div style={{ marginTop: 22 }}>
            <div style={{ display: 'flex', alignItems: 'center', marginBottom: 12 }}>
              <span style={{ font: `500 12px/1 ${t.fonts.body}`, color: t.fg, letterSpacing: '0.02em' }}>Movimientos recientes</span>
              <span style={{ flex: 1 }} />
              <span style={{ font: `400 11px/1 ${t.fonts.mono}`, color: t.fg3 }}>{accountTxns.length} mostrados</span>
            </div>
            {accountTxns.map((tr, i) => {
              const isInc = tr.amount > 0;
              return (
                <div key={tr.id} style={{
                  display: 'grid', gridTemplateColumns: '1fr auto auto', gap: 10, alignItems: 'center',
                  padding: '10px 0',
                  borderTop: i === 0 ? 'none' : `1px solid ${t.card.border}`,
                }}>
                  <div>
                    <div style={{ font: `500 13px/1.2 ${t.fonts.body}`, color: t.fg }}>{tr.desc}</div>
                    <div style={{ font: `400 11px/1 ${t.fonts.body}`, color: t.fg3, marginTop: 3 }}>{tr.cat}</div>
                  </div>
                  <span style={{ font: `400 11px/1 ${t.fonts.mono}`, color: t.fg3 }}>{tr.date.slice(5)}</span>
                  <span style={{ font: `500 13px/1 ${t.fonts.mono}`, color: isInc ? t.good : t.fg, minWidth: 70, textAlign: 'right' }}>
                    {isInc ? '+' : '\u2212'}${Math.abs(tr.amount).toFixed(2)}
                  </span>
                </div>
              );
            })}
          </div>

          {/* Footer actions */}
          <div style={{ display: 'flex', gap: 8, marginTop: 24, paddingTop: 16, borderTop: `1px solid ${t.card.border}` }}>
            <VButton variant="secondary" icon="edit" size="sm" fullWidth>Editar</VButton>
            <VButton variant="ghost" icon="download" size="sm" fullWidth>Exportar</VButton>
            <VButton variant="ghost" icon="trash" size="sm" fullWidth style={{ color: t.bad }}>Archivar</VButton>
          </div>
        </div>
      </window.VShell.Drawer>
    );
  }

  // ─── Summary header strip ───────────────────────────────────────────
  function AccountsHeader() {
    const t = window.theme;
    const d = window.VAULT_DATA;
    const assets = d.accounts.filter(a => a.balance > 0).reduce((s, a) => s + a.balance, 0);
    const debts = d.accounts.filter(a => a.balance < 0).reduce((s, a) => s + Math.abs(a.balance), 0);
    const net = assets - debts;
    return (
      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(4, 1fr)', gap: 16 }}>
        {[
          { l: 'Patrimonio neto', v: `$${net.toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}`, sub: '+$310.50 MoM', subColor: t.good, big: true },
          { l: 'Activos',         v: `$${assets.toLocaleString('en-US', { minimumFractionDigits: 2 })}`, sub: '3 cuentas' },
          { l: 'Deudas',          v: `\u2212$${debts.toLocaleString('en-US', { minimumFractionDigits: 2 })}`, sub: '1 tarjeta', valColor: t.bad },
          { l: 'Liquidez',        v: '$3,370.80', sub: 'corriente + efectivo' },
        ].map((s, i) => (
          <VCard key={i} pad={20} accent={s.big}>
            <div style={{ font: `400 11px/1 ${t.fonts.mono}`, color: t.fg3, letterSpacing: '0.14em', textTransform: 'uppercase' }}>{s.l}</div>
            <div style={{ font: `600 ${s.big ? 30 : 24}px/1 ${t.fonts.display}`, color: s.valColor || t.fg, marginTop: 10, letterSpacing: '-0.02em' }}>{s.v}</div>
            <div style={{ font: `500 12px/1 ${t.fonts.mono}`, color: s.subColor || t.fg3, marginTop: 8 }}>{s.sub}</div>
          </VCard>
        ))}
      </div>
    );
  }

  // ─── Screen ─────────────────────────────────────────────────────────
  function AccountsScreen() {
    const d = window.VAULT_DATA;
    const t = window.theme;
    const [openId, setOpenId] = useState(null);
    const account = openId && d.accounts.find(a => a.id === openId);

    return (
      <div style={{ padding: '24px 32px 40px', display: 'grid', gap: 16 }}>
        <AccountsHeader />

        <div style={{ display: 'flex', alignItems: 'center', marginTop: 6 }}>
          <span style={{ font: `500 12px/1 ${t.fonts.body}`, color: t.fg, letterSpacing: '0.05em', textTransform: 'uppercase', opacity: 0.7 }}>
            Mis cuentas
          </span>
          <span style={{ flex: 1 }} />
          <VButton variant="secondary" icon="plus" size="sm">Conectar cuenta</VButton>
        </div>

        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fill, minmax(280px, 1fr))', gap: 16 }}>
          {d.accounts.map(a => (
            <AccountCard key={a.id} account={a} onOpen={() => setOpenId(a.id)} />
          ))}
          <AddAccountCard />
        </div>

        <AccountDrawer account={account} open={!!openId} onClose={() => setOpenId(null)} />
      </div>
    );
  }

  window.VaultAccounts = AccountsScreen;
})();
