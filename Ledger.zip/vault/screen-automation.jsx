// Vault · Automation — Telegram only.
// Connected state with live conversation feed, capture stats, and settings.

(function () {
  const { useState } = React;
  const { fmt, VCard, VButton, VBadge, VToggle, VProgress, VChip, Icon } = window.V;

  // Telegram brand-y blue (we don't recreate Telegram chrome, just a hint)
  const TG_BLUE = '#29b6f6';
  const TG_BLUE2 = '#0288d1';

  // ─── Bot avatar ────────────────────────────────────────────────────
  function BotAvatar({ size=40 }) {
    return (
      <span style={{
        width: size, height: size, borderRadius: 12,
        background: `linear-gradient(135deg, ${TG_BLUE}, ${TG_BLUE2})`,
        display: 'inline-flex', alignItems: 'center', justifyContent: 'center',
        color: '#fff', flexShrink: 0,
        boxShadow: `0 8px 20px -10px ${TG_BLUE2}`,
      }}>
        <svg width={size * 0.5} height={size * 0.5} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
          <path d="M22 2L11 13M22 2l-7 20-4-9-9-4 20-7z" />
        </svg>
      </span>
    );
  }

  // ─── Connection hero ───────────────────────────────────────────────
  function ConnectionHero({ onDisconnect }) {
    const t = window.theme;
    const d = window.VAULT_DATA;
    const a = d.automation.telegram;
    return (
      <VCard pad={28} style={{ overflow: 'hidden' }}>
        <div aria-hidden style={{
          position: 'absolute', right: -80, top: -80, width: 320, height: 320, borderRadius: '50%',
          background: `radial-gradient(circle, ${TG_BLUE}22, transparent 60%)`, pointerEvents: 'none',
        }} />
        <div style={{ position: 'relative', display: 'grid', gridTemplateColumns: '1fr auto', gap: 32, alignItems: 'center' }}>
          <div style={{ display: 'flex', alignItems: 'center', gap: 18 }}>
            <BotAvatar size={64} />
            <div>
              <div style={{ display: 'flex', alignItems: 'center', gap: 10 }}>
                <span style={{ font: `400 11px/1 ${t.fonts.mono}`, color: t.fg3, letterSpacing: '0.16em', textTransform: 'uppercase' }}>
                  Telegram · @ledger_bot
                </span>
                <VBadge tone="good" dot>connected</VBadge>
              </div>
              <div style={{ font: `600 30px/1.1 ${t.fonts.display}`, color: t.fg, marginTop: 6, letterSpacing: '-0.015em' }}>
                Conectado como <span style={{ color: TG_BLUE }}>{a.handle}</span>
              </div>
              <div style={{ font: `400 13px/1.55 ${t.fonts.body}`, color: t.fg2, marginTop: 8, maxWidth: 540 }}>
                Send text, voice notes, or photos of receipts and the bot logs them automatically.
                Last sync <strong style={{ color: t.fg }}>{a.lastSync}</strong>.
              </div>
            </div>
          </div>
          <div style={{ display: 'flex', flexDirection: 'column', gap: 10 }}>
            <VButton variant="secondary" icon="bot" size="md">Open in Telegram</VButton>
            <VButton variant="ghost" icon="logOut" size="md" onClick={onDisconnect}>Disconnect</VButton>
          </div>
        </div>
      </VCard>
    );
  }

  // ─── Metrics strip ─────────────────────────────────────────────────
  function Metrics() {
    const t = window.theme;
    const d = window.VAULT_DATA;
    const a = d.automation.telegram;
    const captureRate = a.capturedThisMonth / a.totalThisMonth * 100;
    return (
      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(4, 1fr)', gap: 16 }}>
        {[
          { l: 'Auto-capturados', v: `${a.autoLoggedThisMonth}`, sub: `de ${a.totalThisMonth} txns este mes`, accent: true },
          { l: 'Capture rate',    v: `${captureRate.toFixed(1)}%`, sub: 'subió +4% vs diciembre', subColor: t.good },
          { l: 'Confianza promedio', v: '94.2%', sub: 'todas las categorías', subColor: t.fg3 },
          { l: 'Tiempo ahorrado',  v: '~2h 18m', sub: 'este mes · vs entrada manual', subColor: t.accent.a },
        ].map((s, i) => (
          <VCard key={i} pad={18} accent={s.accent}>
            <div style={{ font: `400 11px/1 ${t.fonts.mono}`, color: t.fg3, letterSpacing: '0.14em', textTransform: 'uppercase' }}>{s.l}</div>
            <div style={{ font: `600 28px/1 ${t.fonts.display}`, color: t.fg, marginTop: 10, letterSpacing: '-0.02em' }}>{s.v}</div>
            <div style={{ font: `500 12px/1 ${t.fonts.mono}`, color: s.subColor || t.fg3, marginTop: 8 }}>{s.sub}</div>
          </VCard>
        ))}
      </div>
    );
  }

  // ─── Conversation feed ─────────────────────────────────────────────
  // Renders a Telegram-style chat (without recreating their chrome) to show
  // what messages came in and what got captured.
  function ConversationFeed() {
    const t = window.theme;
    const messages = [
      { from: 'user', kind: 'text',  body: 'Pagué 45.32 en Super Selectos', time: '14:32' },
      { from: 'bot',  kind: 'capture', body: { merchant: 'Super Selectos', amount: 45.32, cat: 'Supermercado', confidence: 98, account: 'Visa Gold' }, time: '14:32' },

      { from: 'user', kind: 'voice', body: '0:04 · "Uber Eats dieciocho cuarenta"', time: '19:14' },
      { from: 'bot',  kind: 'capture', body: { merchant: 'Uber Eats', amount: 18.40, cat: 'Restaurantes', confidence: 91, account: 'Visa Gold' }, time: '19:14' },

      { from: 'user', kind: 'image', body: 'recibo_puma.jpg', time: '17:02' },
      { from: 'bot',  kind: 'capture', body: { merchant: 'Puma', amount: 42.00, cat: 'Transporte', confidence: 96, account: 'Visa Gold' }, time: '17:03' },

      { from: 'user', kind: 'text',  body: 'cuanto gasté en restaurantes este mes', time: '09:15' },
      { from: 'bot',  kind: 'answer', body: 'Llevas $312.80 en Restaurantes este mes en 8 transacciones. La más alta fue $24.50 en La Pampa.', time: '09:15' },

      { from: 'user', kind: 'text',  body: 'Café 3.50', time: '12:01' },
      { from: 'bot',  kind: 'confirm', body: { merchant: 'Café', amount: 3.50, suggestedCat: 'Restaurantes', confidence: 64, account: 'Efectivo' }, time: '12:01' },
    ];

    const Bubble = ({ children, side, accent, style: extra={} }) => (
      <div style={{
        maxWidth: '78%',
        background: side === 'user' ? `linear-gradient(135deg, ${TG_BLUE}, ${TG_BLUE2})` : t.card.bg,
        color: side === 'user' ? '#fff' : t.fg,
        border: side === 'user' ? 'none' : `1px solid ${t.card.border}`,
        borderRadius: 16,
        borderTopLeftRadius: side === 'user' ? 16 : 4,
        borderTopRightRadius: side === 'user' ? 4 : 16,
        padding: '10px 14px',
        font: `400 13px/1.45 ${t.fonts.body}`,
        ...extra,
      }}>{children}</div>
    );

    return (
      <VCard pad={0} style={{ overflow: 'hidden' }}>
        {/* Bot header */}
        <div style={{
          display: 'flex', alignItems: 'center', gap: 12,
          padding: '14px 20px', borderBottom: `1px solid ${t.card.border}`,
          background: 'rgba(255,255,255,0.02)',
        }}>
          <BotAvatar size={36} />
          <div>
            <div style={{ font: `600 14px/1.2 ${t.fonts.display}`, color: t.fg }}>@ledger_bot</div>
            <div style={{ font: `400 11px/1 ${t.fonts.body}`, color: t.good, marginTop: 3 }}>
              <span style={{ display: 'inline-block', width: 6, height: 6, borderRadius: '50%', background: t.good, marginRight: 6 }} />
              online · responding
            </div>
          </div>
          <span style={{ flex: 1 }} />
          <button style={{
            background: 'transparent', border: 'none', cursor: 'pointer', color: t.fg2,
            padding: 6, borderRadius: 8,
          }}><Icon name="more" size={18} /></button>
        </div>

        {/* Date band */}
        <div style={{ padding: '14px 0', textAlign: 'center' }}>
          <span style={{
            font: `500 10px/1 ${t.fonts.mono}`, color: t.fg3, letterSpacing: '0.16em', textTransform: 'uppercase',
            padding: '4px 10px', borderRadius: 999,
            background: 'rgba(255,255,255,0.04)',
          }}>Today</span>
        </div>

        {/* Messages */}
        <div style={{ padding: '0 20px 18px', display: 'grid', gap: 8 }}>
          {messages.map((m, i) => (
            <div key={i} style={{ display: 'flex', justifyContent: m.from === 'user' ? 'flex-end' : 'flex-start' }}>
              {m.from === 'user' && m.kind === 'text' && (
                <Bubble side="user">{m.body}<TimeStamp light>{m.time}</TimeStamp></Bubble>
              )}
              {m.from === 'user' && m.kind === 'voice' && (
                <Bubble side="user">
                  <div style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
                    <Icon name="mic" size={14} />
                    {/* fake waveform */}
                    <svg width="120" height="20" viewBox="0 0 120 20">
                      {Array.from({length: 24}).map((_,j) => {
                        const h = 4 + Math.abs(Math.sin(j*1.7)) * 12;
                        return <rect key={j} x={j*5} y={(20-h)/2} width="2" height={h} fill="rgba(255,255,255,0.7)" rx="1" />;
                      })}
                    </svg>
                    <span style={{ font: `400 11px/1 ${t.fonts.mono}` }}>0:04</span>
                  </div>
                  <div style={{ marginTop: 6, font: `400 12px/1.3 ${t.fonts.body}`, opacity: 0.85 }}>
                    "Uber Eats dieciocho cuarenta"
                  </div>
                  <TimeStamp light>{m.time}</TimeStamp>
                </Bubble>
              )}
              {m.from === 'user' && m.kind === 'image' && (
                <Bubble side="user" style={{ padding: 6 }}>
                  {/* receipt placeholder */}
                  <div style={{
                    width: 200, height: 140, borderRadius: 10,
                    background: `repeating-linear-gradient(135deg, rgba(255,255,255,0.18) 0 6px, transparent 6px 14px), #c8d2dc`,
                    display: 'flex', alignItems: 'flex-end', padding: 8, color: '#0b0d18',
                    font: `500 11px/1 ${t.fonts.mono}`, position: 'relative',
                  }}>
                    <span style={{
                      position: 'absolute', top: 8, left: 8,
                      padding: '2px 6px', borderRadius: 4,
                      background: 'rgba(11,13,24,0.5)', color: '#fff', fontSize: 10,
                    }}>RECIBO</span>
                    <span>{m.body}</span>
                  </div>
                  <TimeStamp light style={{ marginTop: 6 }}>{m.time}</TimeStamp>
                </Bubble>
              )}
              {m.from === 'bot' && m.kind === 'capture' && (
                <Bubble side="bot">
                  <div style={{ display: 'flex', alignItems: 'center', gap: 8, marginBottom: 8 }}>
                    <Icon name="check" size={14} style={{ color: t.good }} />
                    <span style={{ font: `500 12px/1 ${t.fonts.mono}`, color: t.good, letterSpacing: '0.08em' }}>LOGGED</span>
                    <span style={{ flex: 1 }} />
                    <span style={{ font: `400 10px/1 ${t.fonts.mono}`, color: t.fg3 }}>confidence {m.body.confidence}%</span>
                  </div>
                  <div style={{
                    display: 'grid', gridTemplateColumns: '1fr auto', gap: 4,
                    padding: '10px 12px', borderRadius: 10,
                    background: 'rgba(255,255,255,0.03)', border: `1px solid ${t.card.border}`,
                  }}>
                    <div style={{ minWidth: 0 }}>
                      <div style={{ font: `500 13px/1.2 ${t.fonts.body}`, color: t.fg }}>{m.body.merchant}</div>
                      <div style={{ font: `400 11px/1 ${t.fonts.body}`, color: t.fg3, marginTop: 3 }}>{m.body.cat} · {m.body.account}</div>
                    </div>
                    <span style={{ font: `600 16px/1 ${t.fonts.mono}`, color: t.fg }}>−${m.body.amount.toFixed(2)}</span>
                  </div>
                  <div style={{ display: 'flex', gap: 6, marginTop: 8, justifyContent: 'flex-end' }}>
                    <button style={{ background: 'rgba(255,255,255,0.04)', border: 'none', borderRadius: 6, color: t.fg2, font: `500 11px/1 ${t.fonts.body}`, padding: '5px 8px', cursor: 'pointer' }}>edit</button>
                    <button style={{ background: 'rgba(255,255,255,0.04)', border: 'none', borderRadius: 6, color: t.fg2, font: `500 11px/1 ${t.fonts.body}`, padding: '5px 8px', cursor: 'pointer' }}>recategorize</button>
                  </div>
                  <TimeStamp>{m.time}</TimeStamp>
                </Bubble>
              )}
              {m.from === 'bot' && m.kind === 'answer' && (
                <Bubble side="bot">
                  <div style={{ display: 'flex', alignItems: 'center', gap: 6, marginBottom: 6 }}>
                    <Icon name="sparkles" size={13} style={{ color: t.accent.a }} />
                    <span style={{ font: `500 11px/1 ${t.fonts.mono}`, color: t.accent.a, letterSpacing: '0.08em' }}>ANSWER</span>
                  </div>
                  {m.body}
                  <TimeStamp>{m.time}</TimeStamp>
                </Bubble>
              )}
              {m.from === 'bot' && m.kind === 'confirm' && (
                <Bubble side="bot">
                  <div style={{ display: 'flex', alignItems: 'center', gap: 6, marginBottom: 8 }}>
                    <Icon name="help" size={14} style={{ color: t.warn }} />
                    <span style={{ font: `500 12px/1 ${t.fonts.mono}`, color: t.warn, letterSpacing: '0.08em' }}>NEEDS CONFIRMATION</span>
                  </div>
                  <div style={{ color: t.fg2, marginBottom: 8 }}>
                    Detecté <strong style={{ color: t.fg }}>{m.body.merchant} · ${m.body.amount.toFixed(2)}</strong>. Sugiero categoría <strong style={{ color: t.fg }}>{m.body.suggestedCat}</strong>. ¿Confirmas?
                  </div>
                  <div style={{ display: 'flex', gap: 6 }}>
                    <button style={{
                      background: t.accent.soft, border: 'none', borderRadius: 8,
                      color: t.accent.a, font: `500 12px/1 ${t.fonts.body}`, padding: '7px 12px', cursor: 'pointer',
                    }}>✓ Confirmar</button>
                    <button style={{
                      background: 'rgba(255,255,255,0.04)', border: 'none', borderRadius: 8,
                      color: t.fg2, font: `500 12px/1 ${t.fonts.body}`, padding: '7px 12px', cursor: 'pointer',
                    }}>Cambiar categoría</button>
                  </div>
                  <TimeStamp>{m.time}</TimeStamp>
                </Bubble>
              )}
            </div>
          ))}
        </div>

        {/* Compose row — disabled, just decorative */}
        <div style={{
          padding: '12px 16px', borderTop: `1px solid ${t.card.border}`,
          background: 'rgba(255,255,255,0.02)',
          display: 'flex', alignItems: 'center', gap: 10,
        }}>
          <Icon name="image" size={18} style={{ color: t.fg3 }} />
          <Icon name="mic" size={18} style={{ color: t.fg3 }} />
          <div style={{
            flex: 1, background: 'rgba(255,255,255,0.04)',
            border: `1px solid ${t.card.border}`,
            borderRadius: 10, padding: '8px 12px',
            font: `400 12px/1 ${t.fonts.body}`, color: t.fg3,
          }}>Envía mensajes desde Telegram · este preview es de solo lectura</div>
        </div>
      </VCard>
    );

    function TimeStamp({ children, light, style: extra={} }) {
      return (
        <div style={{
          font: `400 9px/1 ${t.fonts.mono}`,
          color: light ? 'rgba(255,255,255,0.6)' : t.fg3,
          textAlign: 'right',
          marginTop: 6,
          letterSpacing: '0.04em',
          ...extra,
        }}>{children}</div>
      );
    }
  }

  // ─── Settings panel ────────────────────────────────────────────────
  function SettingsPanel() {
    const t = window.theme;
    const d = window.VAULT_DATA;
    const [voice,    setVoice]    = useState(d.automation.telegram.voiceEnabled);
    const [image,    setImage]    = useState(d.automation.telegram.imageEnabled);
    const [auto,     setAuto]     = useState(d.automation.telegram.autoCategorize);
    const [confirm,  setConfirm]  = useState(d.automation.telegram.requireConfirmation);

    return (
      <VCard pad={22}>
        <div style={{ display: 'flex', alignItems: 'center', marginBottom: 18 }}>
          <span style={{ font: `600 16px/1 ${t.fonts.display}`, color: t.fg }}>Settings</span>
          <span style={{ flex: 1 }} />
          <span style={{ font: `400 11px/1 ${t.fonts.mono}`, color: t.fg3 }}>guardado automáticamente</span>
        </div>

        <div style={{ display: 'grid', gap: 4 }}>
          {[
            { label: 'Capturar mensajes de voz', sub: 'Transcribir audio y extraer transacciones', val: voice, set: setVoice },
            { label: 'Procesar fotos de recibos', sub: 'OCR + clasificación automática', val: image, set: setImage },
            { label: 'Categorizar automáticamente', sub: 'Usar IA para asignar categoría según merchant', val: auto, set: setAuto },
            { label: 'Pedir confirmación', sub: 'Confirmar antes de guardar (recomendado si confianza < 80%)', val: confirm, set: setConfirm },
          ].map((row, i) => (
            <div key={i} style={{
              padding: '14px 0',
              borderTop: i ? `1px solid ${t.card.border}` : 'none',
            }}>
              <VToggle checked={row.val} onChange={row.set} label={row.label} sublabel={row.sub} />
            </div>
          ))}
        </div>

        <div style={{ marginTop: 20, paddingTop: 16, borderTop: `1px solid ${t.card.border}` }}>
          <div style={{ font: `500 11px/1 ${t.fonts.mono}`, color: t.fg3, letterSpacing: '0.14em', textTransform: 'uppercase', marginBottom: 10 }}>
            Cuenta por defecto
          </div>
          <select style={{
            width: '100%', padding: '10px 12px', borderRadius: 10,
            background: 'rgba(255,255,255,0.04)',
            border: `1px solid ${t.card.border}`,
            color: t.fg, font: `500 13px/1 ${t.fonts.body}`,
          }}>
            <option>Visa Gold · BAC (auto-detectada en mayoría)</option>
            <option>Cuenta Corriente · BAC</option>
            <option>Ahorros · Banco Agricola</option>
            <option>Efectivo</option>
          </select>
          <div style={{ font: `400 11px/1.4 ${t.fonts.body}`, color: t.fg3, marginTop: 6 }}>
            Si no especificas cuenta en el mensaje, se usa ésta.
          </div>
        </div>

        <div style={{ marginTop: 20, paddingTop: 16, borderTop: `1px solid ${t.card.border}` }}>
          <div style={{ font: `500 11px/1 ${t.fonts.mono}`, color: t.fg3, letterSpacing: '0.14em', textTransform: 'uppercase', marginBottom: 10 }}>
            Idioma del bot
          </div>
          <div style={{ display: 'flex', gap: 6 }}>
            {['Español', 'English', 'Auto'].map((l, i) => (
              <VChip key={l} active={i === 0}>{l}</VChip>
            ))}
          </div>
        </div>
      </VCard>
    );
  }

  // ─── How-it-works ──────────────────────────────────────────────────
  function HowItWorks() {
    const t = window.theme;
    const examples = [
      { kind: 'text',  example: '"Pagué 45.32 en Super Selectos"',     icon: 'type' },
      { kind: 'text',  example: '"Almuerzo 12 con Visa"',              icon: 'type' },
      { kind: 'voice', example: '🎙 "Uber dieciocho con cincuenta"',    icon: 'mic' },
      { kind: 'image', example: '📷 foto de recibo',                    icon: 'image' },
      { kind: 'query', example: '"cuanto gasté en restaurantes?"',     icon: 'sparkles' },
      { kind: 'query', example: '"balance"',                           icon: 'sparkles' },
    ];
    return (
      <VCard>
        <div style={{ display: 'flex', alignItems: 'center', marginBottom: 14 }}>
          <span style={{ font: `600 15px/1 ${t.fonts.display}`, color: t.fg }}>Cómo usar el bot</span>
        </div>
        <div style={{ display: 'grid', gap: 8 }}>
          {examples.map((ex, i) => (
            <div key={i} style={{
              display: 'flex', alignItems: 'center', gap: 12,
              padding: '10px 12px',
              background: 'rgba(255,255,255,0.03)',
              borderRadius: 10,
            }}>
              <span style={{
                width: 28, height: 28, borderRadius: 8,
                background: t.accent.soft, color: t.accent.a,
                display: 'flex', alignItems: 'center', justifyContent: 'center',
                flexShrink: 0,
              }}><Icon name={ex.icon} size={14} /></span>
              <span style={{ font: `400 13px/1.3 ${t.fonts.body}`, color: t.fg, flex: 1 }}>{ex.example}</span>
            </div>
          ))}
        </div>
      </VCard>
    );
  }

  // ─── Screen ────────────────────────────────────────────────────────
  function AutomationScreen() {
    const [showDisconnect, setShowDisconnect] = useState(false);
    return (
      <div style={{ padding: '24px 32px 40px', display: 'grid', gap: 16 }}>
        <ConnectionHero onDisconnect={() => setShowDisconnect(true)} />
        <Metrics />
        <div style={{ display: 'grid', gridTemplateColumns: '1.4fr 1fr', gap: 16 }}>
          <ConversationFeed />
          <div style={{ display: 'grid', gap: 16, alignContent: 'start' }}>
            <SettingsPanel />
            <HowItWorks />
          </div>
        </div>
      </div>
    );
  }

  window.VaultAutomation = AutomationScreen;
})();
