// Vault · Budgets — category budgets + sinking funds (goals)

(function () {
  const { useState } = React;
  const { fmt, VCard, VButton, VBadge, VProgress, VChip, Icon } = window.V;

  // ─── Big monthly budget ring ───────────────────────────────────────
  function MonthlyBudgetRing({ size=160, stroke=14 }) {
    const t = window.theme;
    const d = window.VAULT_DATA;
    const pct = d.month.budgetUsed;
    const projPct = Math.min((d.month.budget + d.month.projectedOverspend) / d.month.budget, 1.5);
    const cx = size/2, cy = size/2;
    const r = (size - stroke) / 2;
    const circ = 2 * Math.PI * r;
    return (
      <div style={{ position: 'relative', width: size, height: size }}>
        <svg viewBox={`0 0 ${size} ${size}`} style={{ transform: 'rotate(-90deg)' }}>
          <circle cx={cx} cy={cy} r={r} fill="none" stroke="rgba(255,255,255,0.06)" strokeWidth={stroke} />
          {/* projected ghost */}
          <circle cx={cx} cy={cy} r={r} fill="none" stroke={t.bad} strokeWidth={stroke} strokeOpacity="0.18"
            strokeDasharray={`${Math.min(projPct, 1) * circ} ${circ}`} />
          {/* actual */}
          <circle cx={cx} cy={cy} r={r} fill="none" stroke={pct > 0.9 ? t.warn : t.accent.a} strokeWidth={stroke}
            strokeLinecap="round" strokeDasharray={`${pct * circ} ${circ}`} />
        </svg>
        <div style={{ position: 'absolute', inset: 0, display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center' }}>
          <div style={{ font: `400 10px/1 ${t.fonts.mono}`, color: t.fg3, letterSpacing: '0.16em', textTransform: 'uppercase' }}>usado</div>
          <div style={{ font: `600 28px/1 ${t.fonts.display}`, color: t.fg, marginTop: 6 }}>{Math.round(pct*100)}%</div>
        </div>
      </div>
    );
  }

  // ─── Big overview card with stacked summary ────────────────────────
  function BudgetOverview() {
    const t = window.theme;
    const d = window.VAULT_DATA;
    const remaining = d.month.budget - d.month.expenses;
    return (
      <VCard pad={28} style={{ overflow: 'hidden' }}>
        <div aria-hidden style={{
          position: 'absolute', right: -60, top: -60, width: 240, height: 240, borderRadius: '50%',
          background: `radial-gradient(circle, ${t.accent.soft}, transparent 60%)`, pointerEvents: 'none',
        }} />
        <div style={{ position: 'relative', display: 'grid', gridTemplateColumns: '180px 1fr', gap: 32, alignItems: 'center' }}>
          <MonthlyBudgetRing />
          <div>
            <div style={{ display: 'flex', alignItems: 'center', gap: 10, marginBottom: 8 }}>
              <span style={{ font: `500 10px/1 ${t.fonts.mono}`, color: t.fg3, letterSpacing: '0.18em', textTransform: 'uppercase' }}>
                Presupuesto · {d.month.label}
              </span>
              <VBadge tone="warn" dot>en advertencia</VBadge>
            </div>
            <div style={{ display: 'flex', alignItems: 'baseline', gap: 12 }}>
              <span style={{ font: `600 48px/1 ${t.fonts.display}`, color: t.fg, letterSpacing: '-0.025em' }}>
                $2,340<span style={{ color: t.fg3, fontSize: 26 }}>.50</span>
              </span>
              <span style={{ font: `500 16px/1 ${t.fonts.mono}`, color: t.fg3 }}>/ $2,800.00</span>
            </div>
            <div style={{ display: 'grid', gridTemplateColumns: 'repeat(3, 1fr)', gap: 18, marginTop: 22 }}>
              {[
                { k: 'Disponible', v: fmt(remaining), sub: '8 días restantes', color: t.fg },
                { k: 'Proyectado', v: '+$312.00', sub: 'al final del mes', color: t.warn },
                { k: 'Diario',     v: '$73.14',   sub: 'meta: $57.43',       color: t.warn },
              ].map((row, i) => (
                <div key={row.k} style={{ paddingLeft: i ? 18 : 0, borderLeft: i ? `1px solid ${t.card.border}` : 'none' }}>
                  <div style={{ font: `500 10px/1 ${t.fonts.mono}`, color: t.fg3, letterSpacing: '0.14em', textTransform: 'uppercase' }}>{row.k}</div>
                  <div style={{ font: `600 22px/1 ${t.fonts.display}`, color: row.color, marginTop: 8 }}>{row.v}</div>
                  <div style={{ font: `400 11px/1 ${t.fonts.body}`, color: t.fg3, marginTop: 4 }}>{row.sub}</div>
                </div>
              ))}
            </div>
          </div>
        </div>
      </VCard>
    );
  }

  // ─── Category budget row ───────────────────────────────────────────
  function CategoryBudget({ cat }) {
    const t = window.theme;
    const pct = (cat.amount / cat.budget) * 100;
    const over = pct > 100;
    const left = cat.budget - cat.amount;
    return (
      <VCard pad={18} hoverable>
        <div style={{ display: 'flex', alignItems: 'center', gap: 12, marginBottom: 14 }}>
          <span style={{
            width: 32, height: 32, borderRadius: 10,
            background: `${cat.color}22`, color: cat.color,
            display: 'flex', alignItems: 'center', justifyContent: 'center',
            fontFamily: t.fonts.mono, fontWeight: 600, fontSize: 13,
          }}>{cat.name.slice(0,2).toUpperCase()}</span>
          <div style={{ flex: 1, minWidth: 0 }}>
            <div style={{ font: `500 14px/1.2 ${t.fonts.body}`, color: t.fg }}>{cat.name}</div>
            <div style={{ font: `400 11px/1 ${t.fonts.body}`, color: t.fg3, marginTop: 3 }}>{cat.count} transacciones</div>
          </div>
          {over ? <VBadge tone="bad" dot>sobrepasado</VBadge>
            : pct > 85 ? <VBadge tone="warn" dot>cerca del límite</VBadge>
            : <VBadge tone="good" dot>al día</VBadge>}
        </div>
        <div style={{ display: 'flex', alignItems: 'baseline', gap: 10, marginBottom: 8 }}>
          <span style={{ font: `600 22px/1 ${t.fonts.display}`, color: t.fg, letterSpacing: '-0.015em' }}>
            ${cat.amount.toFixed(0)}
          </span>
          <span style={{ font: `400 13px/1 ${t.fonts.mono}`, color: t.fg3 }}>de ${cat.budget}</span>
        </div>
        <div style={{ position: 'relative' }}>
          <VProgress value={Math.min(pct, 100)} height={8} color={over ? t.bad : pct > 85 ? t.warn : cat.color} />
          {over && (
            <div style={{
              position: 'absolute', left: 0, right: 0, top: 0, bottom: 0,
              borderRadius: 4,
              background: `repeating-linear-gradient(45deg, transparent, transparent 4px, rgba(251,113,133,0.12) 4px, rgba(251,113,133,0.12) 8px)`,
            }} />
          )}
        </div>
        <div style={{ display: 'flex', justifyContent: 'space-between', marginTop: 10, font: `400 11px/1 ${t.fonts.mono}`, color: t.fg3 }}>
          <span>{pct.toFixed(0)}% usado</span>
          <span style={{ color: over ? t.bad : t.fg2 }}>
            {over ? `+$${(cat.amount - cat.budget).toFixed(2)} sobre` : `$${left.toFixed(2)} restante`}
          </span>
        </div>
      </VCard>
    );
  }

  // ─── Sinking fund (goal) card ──────────────────────────────────────
  function GoalCard({ goal }) {
    const t = window.theme;
    const pct = (goal.current / goal.target) * 100;
    const remaining = goal.target - goal.current;
    const monthsLeft = Math.ceil(remaining / goal.monthly);
    const dueDate = new Date(goal.due);
    const monthsToDue = Math.max(0, Math.round((dueDate - new Date(window.VAULT_DATA.asOf)) / (1000*60*60*24*30)));
    const onTrack = monthsLeft <= monthsToDue;

    return (
      <VCard pad={20} hoverable>
        <div style={{ display: 'flex', alignItems: 'center', gap: 12, marginBottom: 18 }}>
          <span style={{
            width: 40, height: 40, borderRadius: 12,
            background: t.accent.soft, color: t.accent.a,
            display: 'flex', alignItems: 'center', justifyContent: 'center',
          }}><Icon name={goal.icon} size={20} /></span>
          <div style={{ flex: 1, minWidth: 0 }}>
            <div style={{ font: `500 14px/1.2 ${t.fonts.body}`, color: t.fg }}>{goal.name}</div>
            <div style={{ font: `400 11px/1 ${t.fonts.body}`, color: t.fg3, marginTop: 3 }}>
              vence {dueDate.toLocaleDateString('es-SV', { day: 'numeric', month: 'short', year: 'numeric' })}
            </div>
          </div>
          {onTrack ? <VBadge tone="good" dot>en camino</VBadge>
            : <VBadge tone="warn" dot>atrasado</VBadge>}
        </div>

        {/* Progress visual: two-tone arc bar with current/target */}
        <div style={{ display: 'flex', alignItems: 'baseline', gap: 10, marginBottom: 6 }}>
          <span style={{ font: `600 28px/1 ${t.fonts.display}`, color: t.fg, letterSpacing: '-0.02em' }}>
            ${goal.current.toFixed(0)}
          </span>
          <span style={{ font: `400 13px/1 ${t.fonts.mono}`, color: t.fg3 }}>de ${goal.target}</span>
        </div>
        <div style={{ marginTop: 8 }}>
          <VProgress value={pct} height={8} />
        </div>
        <div style={{ display: 'flex', justifyContent: 'space-between', marginTop: 10, font: `400 11px/1 ${t.fonts.mono}`, color: t.fg3 }}>
          <span>{pct.toFixed(0)}% completo</span>
          <span>${remaining.toFixed(0)} faltan · {monthsLeft} mes{monthsLeft !== 1 ? 'es' : ''}</span>
        </div>

        {/* Monthly contribution */}
        <div style={{ marginTop: 16, padding: '10px 12px', background: 'rgba(255,255,255,0.03)', borderRadius: 10, display: 'flex', alignItems: 'center', gap: 10 }}>
          <Icon name="arrowDown" size={14} style={{ color: t.accent.a }} />
          <div style={{ flex: 1 }}>
            <div style={{ font: `400 11px/1 ${t.fonts.mono}`, color: t.fg3 }}>contribución mensual</div>
            <div style={{ font: `500 14px/1.1 ${t.fonts.mono}`, color: t.fg, marginTop: 2 }}>${goal.monthly}/mes</div>
          </div>
          <button style={{ background: 'transparent', border: 'none', color: t.accent.a, font: `500 12px/1 ${t.fonts.body}`, cursor: 'pointer' }}>Ajustar →</button>
        </div>
      </VCard>
    );
  }

  // ─── Add card ──────────────────────────────────────────────────────
  function AddCard({ label }) {
    const t = window.theme;
    return (
      <button style={{
        background: 'transparent',
        border: `2px dashed ${t.card.border}`,
        borderRadius: t.card.radius,
        padding: 20, minHeight: 200,
        color: t.fg3, font: `500 13px/1.4 ${t.fonts.body}`,
        cursor: 'pointer',
        display: 'flex', alignItems: 'center', justifyContent: 'center', flexDirection: 'column', gap: 10,
        transition: 'border-color .15s, color .15s',
      }} onMouseEnter={(e) => { e.currentTarget.style.borderColor = t.accent.a; e.currentTarget.style.color = t.accent.a; }}
         onMouseLeave={(e) => { e.currentTarget.style.borderColor = t.card.border; e.currentTarget.style.color = t.fg3; }}>
        <span style={{
          width: 32, height: 32, borderRadius: 10,
          background: 'rgba(255,255,255,0.04)',
          display: 'flex', alignItems: 'center', justifyContent: 'center',
        }}><Icon name="plus" size={16} /></span>
        {label}
      </button>
    );
  }

  // ─── Screen ────────────────────────────────────────────────────────
  function BudgetsScreen() {
    const t = window.theme;
    const d = window.VAULT_DATA;
    const [tab, setTab] = useState('categories');

    return (
      <div style={{ padding: '24px 32px 40px', display: 'grid', gap: 20 }}>
        <BudgetOverview />

        {/* Tabs */}
        <div style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
          <div style={{
            display: 'inline-flex', padding: 4, gap: 2,
            background: 'rgba(255,255,255,0.03)',
            border: `1px solid ${t.card.border}`,
            borderRadius: 12,
          }}>
            {[
              { v: 'categories', l: 'Categorías', icon: 'sliders' },
              { v: 'goals',      l: 'Sinking funds', icon: 'star' },
            ].map(o => (
              <button key={o.v} onClick={() => setTab(o.v)} style={{
                padding: '8px 14px', borderRadius: 9,
                background: tab === o.v ? t.accent.soft : 'transparent',
                border: 'none', cursor: 'pointer',
                color: tab === o.v ? t.accent.a : t.fg2,
                font: `500 12px/1 ${t.fonts.body}`,
                display: 'inline-flex', alignItems: 'center', gap: 6,
              }}><Icon name={o.icon} size={14} />{o.l}</button>
            ))}
          </div>
          <span style={{ flex: 1 }} />
          {tab === 'categories' ? (
            <VButton variant="secondary" icon="plus" size="sm">Nueva categoría</VButton>
          ) : (
            <VButton variant="secondary" icon="plus" size="sm">Nuevo fondo</VButton>
          )}
        </div>

        {tab === 'categories' && (
          <>
            <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fill, minmax(300px, 1fr))', gap: 16 }}>
              {d.categories.map(c => <CategoryBudget key={c.id} cat={c} />)}
              <AddCard label="Nueva categoría" />
            </div>
          </>
        )}

        {tab === 'goals' && (
          <>
            {/* funds summary */}
            <div style={{ display: 'grid', gridTemplateColumns: 'repeat(4, 1fr)', gap: 16 }}>
              {[
                { l: 'Total ahorrado', v: '$2,370', sub: '4 fondos activos' },
                { l: 'Meta total', v: '$5,400' },
                { l: 'Contribución/mes', v: '$465' },
                { l: 'Progreso global', v: '43.9%', subColor: t.accent.a },
              ].map((s, i) => (
                <VCard key={i} pad={18}>
                  <div style={{ font: `400 11px/1 ${t.fonts.mono}`, color: t.fg3, letterSpacing: '0.14em', textTransform: 'uppercase' }}>{s.l}</div>
                  <div style={{ font: `600 22px/1 ${t.fonts.display}`, color: s.subColor || t.fg, marginTop: 8 }}>{s.v}</div>
                  {s.sub && <div style={{ font: `400 12px/1 ${t.fonts.body}`, color: t.fg3, marginTop: 4 }}>{s.sub}</div>}
                </VCard>
              ))}
            </div>

            <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fill, minmax(320px, 1fr))', gap: 16 }}>
              {d.goals.map(g => <GoalCard key={g.id} goal={g} />)}
              <AddCard label="Nuevo sinking fund" />
            </div>
          </>
        )}
      </div>
    );
  }

  window.VaultBudgets = BudgetsScreen;
})();
