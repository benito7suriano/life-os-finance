// Vault theme — single source of truth for colors, type, and surface treatment.
// All values that the Tweaks panel can change live here and are reapplied to
// the running app via a small subscriber.

(function () {
  const ACCENTS = {
    mint:   { a: '#5eead4', b: '#22d3ee', soft: 'rgba(94,234,212,0.16)', solid: '#2dd4bf', name: 'Mint' },
    teal:   { a: '#2dd4bf', b: '#0891b2', soft: 'rgba(45,212,191,0.16)', solid: '#14b8a6', name: 'Teal' },
    violet: { a: '#a78bfa', b: '#7c5cff', soft: 'rgba(167,139,250,0.16)', solid: '#a78bfa', name: 'Violet' },
    amber:  { a: '#fcd34d', b: '#f59e0b', soft: 'rgba(252,211,77,0.16)',  solid: '#f59e0b', name: 'Amber' },
    coral:  { a: '#fda4af', b: '#f43f5e', soft: 'rgba(253,164,175,0.16)', solid: '#f43f5e', name: 'Coral' },
    sky:    { a: '#7dd3fc', b: '#0284c7', soft: 'rgba(125,211,252,0.16)', solid: '#0ea5e9', name: 'Sky' },
  };

  const CARD_STYLES = {
    glassy: {
      bg: 'linear-gradient(180deg, rgba(255,255,255,0.025), rgba(255,255,255,0)) , #161a2b',
      border: 'rgba(255,255,255,0.06)',
      borderHi: 'rgba(255,255,255,0.10)',
      shadow: '0 1px 0 rgba(255,255,255,0.04) inset, 0 20px 40px -28px rgba(0,0,0,0.6)',
      radius: 18,
      name: 'Glassy',
    },
    flat: {
      bg: '#141727',
      border: 'rgba(255,255,255,0.04)',
      borderHi: 'rgba(255,255,255,0.08)',
      shadow: 'none',
      radius: 14,
      name: 'Flat',
    },
    bordered: {
      bg: 'transparent',
      border: 'rgba(255,255,255,0.12)',
      borderHi: 'rgba(255,255,255,0.20)',
      shadow: 'none',
      radius: 12,
      name: 'Bordered',
    },
  };

  const TYPE_PAIRS = {
    geist: {
      display: '"Geist", system-ui, sans-serif',
      body:    '"Geist", system-ui, sans-serif',
      mono:    '"JetBrains Mono", ui-monospace, monospace',
      name: 'Geist',
    },
    inter: {
      display: '"Inter", system-ui, sans-serif',
      body:    '"Inter", system-ui, sans-serif',
      mono:    '"JetBrains Mono", ui-monospace, monospace',
      name: 'Inter',
    },
    serif_display: {
      display: '"Instrument Serif", Georgia, serif',
      body:    '"Geist", system-ui, sans-serif',
      mono:    '"JetBrains Mono", ui-monospace, monospace',
      name: 'Serif display',
    },
    mono_all: {
      display: '"JetBrains Mono", ui-monospace, monospace',
      body:    '"Geist", system-ui, sans-serif',
      mono:    '"JetBrains Mono", ui-monospace, monospace',
      name: 'Mono display',
    },
  };

  // Tone-of-meaning colors (don't change with accent)
  const COLOR = {
    bg:      '#0b0d18',
    bg2:     '#0e1124',
    fg:      '#f1f0f5',
    fg2:     '#a5a3b8',
    fg3:     '#6e6c83',
    fg4:     '#4a4960',
    good:    '#4ade80',
    bad:     '#fb7185',
    warn:    '#fbbf24',
    info:    '#67e8f9',
  };

  // ─── compute the full theme from selections ───
  function buildTheme({ accent='mint', card='glassy', type='geist' } = {}) {
    const A = ACCENTS[accent] || ACCENTS.mint;
    const CS = CARD_STYLES[card] || CARD_STYLES.glassy;
    const TP = TYPE_PAIRS[type] || TYPE_PAIRS.geist;
    return {
      key: { accent, card, type },
      accent: A,
      card: CS,
      fonts: TP,
      ...COLOR,
      // gradient helper
      accentGradient: `linear-gradient(135deg, ${A.b}, ${A.a})`,
    };
  }

  window.VaultTheme = {
    ACCENTS, CARD_STYLES, TYPE_PAIRS, COLOR,
    build: buildTheme,
  };
})();
