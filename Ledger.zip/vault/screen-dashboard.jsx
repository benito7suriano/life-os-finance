// Vault · Dashboard
// Refined from the canvas direction: net worth is now a wide hero, the AI
// insight gets a real moment alongside it, automation surfaces Telegram only.

(function () {
  const { fmt, fmtPct, VCard, VButton, VBadge, VSpark, VMiniBars, VProgress, Icon, ACCOUNT_LABELS } = window.V;

  // ─── Hero · Net Worth ───────────────────────────────────────────────
  function HeroNetWorth() {
    const t = window.theme;
    const d = window.VAULT_DATA;
    const series = d.netWorth.series;
    return (
      <VCard pad={28} style={{ overflow: 'hidden' }}>
        {/* faint accent glow corner */}
        <div aria-hidden style={{
          position: 'absolute', right: -80, top: -80,
          width: 280, height: 280, borderRadius: '50%',
          background: `radial-gradient(circle, ${t.accent.soft}, transparent 60%)`,
          pointerEvents: 'none',
        }} />
        <div style={{ position: 'relative', display: 'grid', gridTemplateColumns: '1fr auto', gap: 24, alignItems: 'start' }}>
          <div>
            <div style={{ display: 'flex', alignItems: 'center', gap: 10, marginBottom: 12 }}>
              <span style={{ font: `500 10px/1 ${t.fonts.mono}`, color: t.fg3, letterSpacing: '0.18em', textTransform: 'uppercase' }}>
                Patrimonio neto
              </span>
              <VBadge tone="good" dot>+2.56% MoM</VBadge>
            </div>
            <div style={{ display: 'flex', alignItems: 'baseline', gap: 14 }}>
              <span style={{
                font: `600 64px/1 ${t.fonts.display}`,
                color: t.fg, letterSpacing: '-0.025em',
              }}>$12,450<span style={{ color: t.fg3, fontSize: 32 }}>.00</span></span>
              <span style={{ font: `500 16px/1 ${t.fonts.mono}`, color: t.good }}>+$310.50</span>
            </div>
            {/* breakdown */}
            <div style={{ display: 'flex', gap: 28, marginTop: 18 }}>
              {[
                { k: 'Activos',  v: '$13,870.80', sub: 'corriente · ahorros · efectivo', color: t.fg },
                { k: 'Deudas',   v: '\u2212$1,420.80', sub: 'Visa Gold · 28% utilizado',  color: t.bad },
                { k: 'YTD',      v: '+$2,630.00',  sub: '12 meses · +26.78%',             color: t.good },
              ].map((row, i) => (
                <div key={row.k} style={{ paddingLeft: i ? 28 : 0, borderLeft: i ? `1px solid ${t.card.border}` : 'none' }}>
                  <div style={{ font: `500 10px/1 ${t.fonts.mono}`, color: t.fg3, letterSpacing: '0.14em', textTransform: 'uppercase' }}>{row.k}</div>
                  <div style={{ font: `500 18px/1.1 ${t.fonts.mono}`, color: row.color, marginTop: 6 }}>{row.v}</div>
                  <div style={{ font: `400 11px/1.3 ${t.fonts.body}`, color: t.fg3, marginTop: 4 }}>{row.sub}</div>
                </div>
              ))}
            </div>
          </div>
          {/* big sparkline on the right */}
          <div style={{ width: 360, paddingTop: 6 }}>
            <VSpark data={series} width={360} height={140} color={t.accent.a} fill />
            <div style={{ display: 'flex', justifyContent: 'space-between', font: `400 10px/1 ${t.fonts.mono}`, color: t.fg3, marginTop: 6 }}>
              <span>{d.netWorth.labels[0]} '25</span>
              <span style={{ color: t.fg2 }}>actual</span>
              <span>{d.netWorth.labels[d.netWorth.labels.length-1]} '26</span>
            </div>
          </div>
        </div>
      </VCard>
    );
  }

  // ─── AI Insight hero card ───────────────────────────────────────────
  function InsightHero({ onSeeTransactions }) {
    const t = window.theme;
    return (
      <VCard pad={24} accent style={{ overflow: 'hidden', display: 'flex', flexDirection: 'column' }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: 8, marginBottom: 14 }}>
          <span style={{
            width: 28, height: 28, borderRadius: 8,
            background: t.accentGradient,
            display: 'inline-flex', alignItems: 'center', justifyContent: 'center',
            color: '#0b0d18',
          }}><Icon name="sparkles" size={15} strokeWidth={2} /></span>
          <span style={{ font: `500 10px/1 ${t.fonts.mono}`, color: t.accent.a, letterSpacing: '0.18em', textTransform: 'uppercase' }}>
            AI Insight
          </span>
          <span style={{ flex: 1 }} />
          <span style={{ font: `400 11px/1 ${t.fonts.mono}`, color: t.fg3 }}>generated 06:01</span>
        </div>
        <h3 style={{
          margin: 0,
          font: `500 22px/1.25 ${t.fonts.display}`,
          color: t.fg, letterSpacing: '-0.01em',
        }}>
          You're on pace to overspend by <span style={{ color: t.accent.a }}>$312</span> this month.
        </h3>
        <p style={{ margin: '12px 0 0', font: `400 13px/1.55 ${t.fonts.body}`, color: t.fg2 }}>
          Most of the drift is in Restaurantes and Uber Eats. Cutting two weekday delivery orders gets you back to neutral by Jan 31.
        </p>
        <div style={{ flex: 1 }} />
        <div style={{ display: 'flex', gap: 8, marginTop: 18 }}>
          <VButton variant="primary" size="sm" onClick={onSeeTransactions}>Show me where</VButton>
          <VButton variant="ghost" size="sm">Dismiss</VButton>
        </div>
      </VCard>
    );
  }

  // ─── KPI tile ───────────────────────────────────────────────────────
  function KpiTile({ label, value, sub, trend, trendTone='neutral', chart, chartColor }) {
    const t = window.theme;
    return (
      <VCard>
        <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start' }}>
          <div>
            <div style={{ font: `400 12px/1 ${t.fonts.body}`, color: t.fg3 }}>{label}</div>
            <div style={{ font: `600 30px/1.05 ${t.fonts.display}`, color: t.fg, marginTop: 10, letterSpacing: '-0.015em' }}>
              {value}
            </div>
            {trend && (
              <div style={{ font: `500 12px/1 ${t.fonts.mono}`, color: { good: t.good, warn: t.warn, bad: t.bad, neutral: t.fg2 }[trendTone], marginTop: 8 }}>
                {trend}
              </div>
            )}
            {sub && <div style={{ font: `400 11px/1.3 ${t.fonts.body}`, color: t.fg3, marginTop: trend ? 4 : 8 }}>{sub}</div>}
          </div>
          <div>{chart}</div>
        </div>
      </VCard>
    );
  }

  // ─── Statistic chart — wide multi-series ────────────────────────────
  function StatisticChart() {
    const t = window.theme;
    const [view, setView] = React.useState('all');
    const months = ['Feb','Mar','Apr','May','Jun','Jul','Aug','Sep','Oct','Nov','Dec','Jan'];
    const incomeData =   [3800, 4200, 4200, 4450, 4200, 4200, 4200, 4200, 4450, 4200, 5800, 4200];
    const expensesData = [2050, 1880, 2320, 2180, 2400, 2120, 2050, 2320, 2180, 2890, 3450, 2340];
    const savedData = incomeData.map((v,i) => v - expensesData[i]);

    const width = 760, height = 230;
    const padX = 36, padY = 18;
    const all = view === 'all' ? [incomeData, expensesData, savedData] : view === 'income' ? [incomeData] : view === 'expenses' ? [expensesData] : [savedData];
    const max = Math.max(...all.flat()) * 1.1;
    const xs = months.map((_, i) => padX + (i * (width - padX*2)) / (months.length - 1));
    const pathOf = (data) => {
      const ys = data.map(v => height - padY - 16 - (v / max) * (height - padY*2 - 16));
      let p = `M ${xs[0]} ${ys[0]}`;
      for (let i = 1; i < xs.length; i++) {
        const mx = (xs[i-1] + xs[i]) / 2;
        p += ` C ${mx} ${ys[i-1]}, ${mx} ${ys[i]}, ${xs[i]} ${ys[i]}`;
      }
      return { p, ys };
    };
    const series = [];
    if (view === 'all' || view === 'income')   series.push({ key: 'income', color: t.accent.a, data: incomeData, label: 'Income', width: 2.2, glow: true });
    if (view === 'all' || view === 'expenses') series.push({ key: 'expenses', color: t.bad, data: expensesData, label: 'Expenses', width: 1.6 });
    if (view === 'all' || view === 'saved')    series.push({ key: 'saved', color: t.good, data: savedData, label: 'Saved', width: 1.4 });

    // highlight point: current month income
    const hiIdx = months.length - 1;
    const incomeYs = pathOf(incomeData).ys;
    const hiX = xs[hiIdx];
    const hiY = incomeYs[hiIdx];

    return (
      <VCard pad={24}>
        <div style={{ display: 'flex', alignItems: 'center', marginBottom: 14 }}>
          <span style={{ font: `600 16px/1 ${t.fonts.display}`, color: t.fg }}>Statistic</span>
          <span style={{ font: `400 12px/1 ${t.fonts.body}`, color: t.fg3, marginLeft: 8 }}>· 12 months</span>
          <div style={{ flex: 1 }} />
          {[
            { v: 'all', l: 'All' },
            { v: 'income', l: 'Income' },
            { v: 'expenses', l: 'Expenses' },
            { v: 'saved', l: 'Saved' },
          ].map(opt => (
            <button key={opt.v} onClick={() => setView(opt.v)} style={{
              marginLeft: 6,
              padding: '6px 12px', borderRadius: 999,
              background: view === opt.v ? t.accent.soft : 'transparent',
              border: `1px solid ${view === opt.v ? 'transparent' : t.card.border}`,
              color: view === opt.v ? t.accent.a : t.fg2,
              font: `500 11px/1 ${t.fonts.body}`,
              cursor: 'pointer',
            }}>{opt.l}</button>
          ))}
        </div>
        <svg viewBox={`0 0 ${width} ${height + 22}`} style={{ width: '100%', height: 'auto' }}>
          <defs>
            <filter id="vault-spark-glow" x="-30%" y="-30%" width="160%" height="160%">
              <feGaussianBlur stdDeviation="2" />
              <feMerge><feMergeNode /><feMergeNode in="SourceGraphic" /></feMerge>
            </filter>
            <linearGradient id="vault-fill" x1="0" y1="0" x2="0" y2="1">
              <stop offset="0%" stopColor={t.accent.a} stopOpacity="0.18" />
              <stop offset="100%" stopColor={t.accent.a} stopOpacity="0" />
            </linearGradient>
          </defs>
          {[0,1,2,3,4].map(i => {
            const y = padY + (i * (height - padY*2 - 16)) / 4;
            return <line key={i} x1={padX} x2={width-padX} y1={y} y2={y} stroke="rgba(255,255,255,0.04)" />;
          })}
          {/* income area fill (only when income visible) */}
          {(view === 'all' || view === 'income') && (
            (() => {
              const { ys } = pathOf(incomeData);
              const linePath = pathOf(incomeData).p;
              const area = `${linePath} L ${xs[xs.length-1]} ${height-padY} L ${xs[0]} ${height-padY} Z`;
              return <path d={area} fill="url(#vault-fill)" />;
            })()
          )}
          {series.map((s, i) => {
            const { p } = pathOf(s.data);
            return <path key={s.key} d={p} stroke={s.color} strokeWidth={s.width} fill="none" strokeLinecap="round"
              filter={s.glow ? 'url(#vault-spark-glow)' : undefined} />;
          })}
          {/* highlight line + tooltip on current month */}
          {(view === 'all' || view === 'income') && (
            <>
              <line x1={hiX} x2={hiX} y1={padY} y2={height-padY} stroke={t.accent.a} strokeOpacity="0.4" strokeDasharray="3 3" />
              <circle cx={hiX} cy={hiY} r={5} fill={t.bg} stroke={t.accent.a} strokeWidth="2" />
              <g transform={`translate(${hiX - 50}, ${hiY - 44})`}>
                <rect x="0" y="0" width="100" height="32" rx="8" fill={t.bg2} stroke={t.card.borderHi} />
                <text x="50" y="14" fill={t.fg3} fontSize="9" fontFamily={t.fonts.mono} textAnchor="middle" letterSpacing="0.1em">JAN INCOME</text>
                <text x="50" y="27" fill={t.fg} fontSize="13" fontFamily={t.fonts.mono} textAnchor="middle" fontWeight="500">$4,200</text>
              </g>
            </>
          )}
          {xs.map((x, i) => (
            <text key={i} x={x} y={height + 14} fill={t.fg3} fontSize="10" fontFamily={t.fonts.body} textAnchor="middle">{months[i]}</text>
          ))}
        </svg>
        <div style={{ display: 'flex', justifyContent: 'center', gap: 22, marginTop: 10 }}>
          {[
            { c: t.accent.a, l: 'Income' },
            { c: t.bad, l: 'Expenses' },
            { c: t.good, l: 'Saved' },
          ].map(it => (
            <span key={it.l} style={{ display: 'inline-flex', alignItems: 'center', gap: 8, color: t.fg2, font: `500 12px/1 ${t.fonts.body}` }}>
              <span style={{ width: 8, height: 8, borderRadius: '50%', background: it.c }} />{it.l}
            </span>
          ))}
        </div>
      </VCard>
    );
  }

  // ─── Recent Transactions card ──────────────────────────────────────
  function RecentTransactions({ onView, onViewAll }) {
    const t = window.theme;
    const d = window.VAULT_DATA;
    return (
      <VCard>
        <div style={{ display: 'flex', alignItems: 'center', marginBottom: 14 }}>
          <span style={{ font: `600 16px/1 ${t.fonts.display}`, color: t.fg }}>Recent</span>
          <span style={{ font: `400 12px/1 ${t.fonts.body}`, color: t.fg3, marginLeft: 8 }}>· últimos movimientos</span>
          <div style={{ flex: 1 }} />
          <button onClick={onViewAll} style={{
            background: 'transparent', border: 'none', cursor: 'pointer',
            color: t.accent.a, font: `500 12px/1 ${t.fonts.body}`,
          }}>View all →</button>
        </div>
        <div>
          {d.transactions.slice(0, 6).map((tr, i) => {
            const isInc = tr.amount > 0;
            return (
              <button key={tr.id} onClick={() => onView(tr.id)} style={{
                width: '100%', textAlign: 'left',
                display: 'grid', gridTemplateColumns: '34px 1fr auto auto', gap: 12, alignItems: 'center',
                padding: '12px 0',
                borderTop: i === 0 ? 'none' : `1px solid ${t.card.border}`,
                background: 'transparent', border: 'none', borderRadius: 0,
                cursor: 'pointer',
              }}>
                <span style={{
                  width: 30, height: 30, borderRadius: 8,
                  background: isInc ? 'rgba(74,222,128,0.12)' : t.accent.soft,
                  color: isInc ? t.good : t.accent.a,
                  display: 'flex', alignItems: 'center', justifyContent: 'center',
                }}><Icon name={isInc ? 'arrowUpRight' : 'arrowDownLeft'} size={14} /></span>
                <div style={{ minWidth: 0 }}>
                  <div style={{ font: `500 13px/1.2 ${t.fonts.body}`, color: t.fg, whiteSpace: 'nowrap', overflow: 'hidden', textOverflow: 'ellipsis' }}>{tr.desc}</div>
                  <div style={{ font: `400 11px/1.3 ${t.fonts.body}`, color: t.fg3, marginTop: 2 }}>
                    {tr.cat}{tr.source === 'telegram' && <span style={{ color: t.accent.a }}> · auto</span>}
                  </div>
                </div>
                <span style={{ font: `400 11px/1 ${t.fonts.mono}`, color: t.fg3 }}>{tr.date.slice(5).replace('-','/')}</span>
                <span style={{
                  font: `500 13px/1 ${t.fonts.mono}`,
                  color: isInc ? t.good : t.fg,
                  minWidth: 70, textAlign: 'right',
                }}>{isInc ? '+' : '\u2212'}${Math.abs(tr.amount).toFixed(2)}</span>
              </button>
            );
          })}
        </div>
      </VCard>
    );
  }

  // ─── Telegram automation card ──────────────────────────────────────
  function TelegramCard({ onGo }) {
    const t = window.theme;
    const d = window.VAULT_DATA;
    const a = d.automation.telegram;
    const captureRate = (a.capturedThisMonth / a.totalThisMonth) * 100;
    return (
      <VCard pad={22} hoverable onClick={onGo}>
        <div style={{ display: 'flex', alignItems: 'center', gap: 10, marginBottom: 16 }}>
          <span style={{
            width: 32, height: 32, borderRadius: 10,
            background: 'linear-gradient(135deg, #29b6f6, #0288d1)',
            display: 'inline-flex', alignItems: 'center', justifyContent: 'center',
            color: '#fff',
          }}>
            {/* paper plane (Telegram-ish glyph) */}
            <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
              <path d="M22 2L11 13M22 2l-7 20-4-9-9-4 20-7z" />
            </svg>
          </span>
          <span style={{ font: `600 15px/1 ${t.fonts.display}`, color: t.fg }}>Telegram</span>
          <VBadge tone="good" dot>connected</VBadge>
          <span style={{ flex: 1 }} />
          <Icon name="chevronRight" size={16} style={{ color: t.fg3 }} />
        </div>

        <div style={{ display: 'flex', alignItems: 'baseline', gap: 10 }}>
          <span style={{ font: `600 36px/1 ${t.fonts.display}`, color: t.fg, letterSpacing: '-0.02em' }}>
            {a.autoLoggedThisMonth}
          </span>
          <span style={{ font: `400 13px/1 ${t.fonts.body}`, color: t.fg3 }}>of {a.totalThisMonth} txns auto-logged</span>
        </div>
        <div style={{ marginTop: 12 }}>
          <VProgress value={captureRate} />
          <div style={{ display: 'flex', justifyContent: 'space-between', marginTop: 6, font: `400 11px/1 ${t.fonts.mono}`, color: t.fg3 }}>
            <span>{captureRate.toFixed(0)}% capture rate</span>
            <span>last sync {a.lastSync}</span>
          </div>
        </div>
        <div style={{ marginTop: 16, padding: '10px 12px', background: 'rgba(255,255,255,0.03)', borderRadius: 10, font: `400 12px/1.5 ${t.fonts.body}`, color: t.fg2 }}>
          <span style={{ color: t.accent.a, fontFamily: t.fonts.mono, fontSize: 11 }}>{a.handle}</span> → <span style={{ color: t.fg3 }}>via</span> <span style={{ color: t.fg, fontFamily: t.fonts.mono, fontSize: 11 }}>{a.botName}</span>
          <div style={{ marginTop: 6, color: t.fg3 }}>
            Send <strong style={{ color: t.fg2 }}>text</strong>, <strong style={{ color: t.fg2 }}>voice notes</strong>, or <strong style={{ color: t.fg2 }}>receipt photos</strong>. The bot logs them automatically.
          </div>
        </div>
      </VCard>
    );
  }

  // ─── Card visual (the iridescent credit card) ──────────────────────
  function CardVisualMini() {
    const t = window.theme;
    return (
      <VCard pad={18}>
        <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 14 }}>
          <span style={{ font: `600 15px/1 ${t.fonts.display}`, color: t.fg }}>Mi tarjeta</span>
          <button style={{ background: 'transparent', border: 'none', color: t.accent.a, font: `500 12px/1 ${t.fonts.body}`, cursor: 'pointer' }}>Manage →</button>
        </div>
        {/* Tilted card */}
        <div style={{
          width: '100%', aspectRatio: '1.6/1', borderRadius: 16, position: 'relative', overflow: 'hidden',
          background: `
            radial-gradient(120% 100% at 0% 0%, rgba(255,255,255,0.45), transparent 50%),
            radial-gradient(120% 100% at 100% 100%, ${t.accent.b}aa, transparent 60%),
            linear-gradient(135deg, #2a2440 0%, ${t.accent.b} 45%, ${t.accent.a} 70%, #1a1830 100%)
          `,
          boxShadow: `0 30px 60px -30px ${t.accent.b}80, inset 0 1px 0 rgba(255,255,255,0.3)`,
          color: '#0b0d18',
        }}>
          <div style={{
            position: 'absolute', inset: 0,
            backgroundImage: 'repeating-linear-gradient(115deg, rgba(255,255,255,0.08) 0 2px, transparent 2px 14px)',
            mixBlendMode: 'overlay',
          }} />
          <div style={{ padding: 16, position: 'relative', display: 'flex', flexDirection: 'column', height: '100%', boxSizing: 'border-box' }}>
            <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
              <span style={{ fontFamily: t.fonts.display, fontWeight: 700, fontSize: 13 }}>BAC · Visa Gold</span>
              <svg width="18" height="20" viewBox="0 0 20 22" fill="none">
                <path d="M5 5 C 9 8, 9 14, 5 17" stroke="rgba(11,13,24,0.6)" strokeWidth="1.5" />
                <path d="M9 3 C 15 7, 15 15, 9 19" stroke="rgba(11,13,24,0.4)" strokeWidth="1.5" />
              </svg>
            </div>
            <div style={{ marginTop: 14, width: 32, height: 24, borderRadius: 4, background: 'linear-gradient(135deg, #ffd76b, #b48623)' }} />
            <div style={{ flex: 1 }} />
            <div style={{ fontFamily: t.fonts.mono, fontSize: 13, letterSpacing: '0.16em', color: 'rgba(11,13,24,0.85)' }}>
              4218 ····  ····  4218
            </div>
            <div style={{ display: 'flex', justifyContent: 'space-between', marginTop: 6, color: 'rgba(11,13,24,0.7)' }}>
              <div style={{ fontSize: 10 }}>BENO</div>
              <div style={{ fontSize: 10, fontFamily: t.fonts.mono }}>09/28</div>
            </div>
          </div>
        </div>
        <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'baseline', marginTop: 14 }}>
          <div>
            <div style={{ font: `400 11px/1 ${t.fonts.mono}`, color: t.fg3, letterSpacing: '0.1em', textTransform: 'uppercase' }}>balance used</div>
            <div style={{ font: `500 16px/1.1 ${t.fonts.mono}`, color: t.fg, marginTop: 4 }}>$1,420 <span style={{ color: t.fg3, fontSize: 13 }}>/ $5,000</span></div>
          </div>
          <span style={{ font: `500 14px/1 ${t.fonts.mono}`, color: t.accent.a }}>28%</span>
        </div>
        <div style={{ marginTop: 8 }}><VProgress value={28} /></div>
      </VCard>
    );
  }

  // ─── Budget glance ─────────────────────────────────────────────────
  function BudgetGlance({ onGo }) {
    const t = window.theme;
    const d = window.VAULT_DATA;
    return (
      <VCard hoverable onClick={onGo}>
        <div style={{ display: 'flex', alignItems: 'center', marginBottom: 12 }}>
          <span style={{ font: `600 15px/1 ${t.fonts.display}`, color: t.fg }}>Budget · January</span>
          <span style={{ flex: 1 }} />
          <VBadge tone="warn" dot>on warning</VBadge>
        </div>
        <div style={{ display: 'flex', alignItems: 'baseline', gap: 10 }}>
          <span style={{ font: `600 30px/1 ${t.fonts.display}`, color: t.fg, letterSpacing: '-0.015em' }}>
            $2,340<span style={{ color: t.fg3, fontSize: 18 }}>.50</span>
          </span>
          <span style={{ font: `400 13px/1 ${t.fonts.body}`, color: t.fg3 }}>of $2,800</span>
        </div>
        <div style={{ marginTop: 10 }}>
          <VProgress value={d.month.budgetUsed * 100} color={`linear-gradient(90deg, ${t.warn}, ${t.bad})`} />
          <div style={{ display: 'flex', justifyContent: 'space-between', marginTop: 6, font: `400 11px/1 ${t.fonts.mono}`, color: t.fg3 }}>
            <span>83.6% used · 8 days left</span>
            <span style={{ color: t.warn }}>+$312 proj.</span>
          </div>
        </div>
        {/* top 3 categories */}
        <div style={{ marginTop: 16, display: 'grid', gap: 8 }}>
          {d.categories.slice(0, 3).map(c => {
            const pct = c.amount / c.budget * 100;
            return (
              <div key={c.id} style={{ display: 'grid', gridTemplateColumns: '1fr 80px 60px', gap: 10, alignItems: 'center' }}>
                <span style={{ font: `500 12px/1 ${t.fonts.body}`, color: t.fg }}>{c.name}</span>
                <div style={{ height: 4, background: 'rgba(255,255,255,0.05)', borderRadius: 2, overflow: 'hidden' }}>
                  <div style={{ width: `${Math.min(pct, 100)}%`, height: '100%', background: pct > 100 ? t.bad : c.color, borderRadius: 2 }} />
                </div>
                <span style={{ font: `500 11px/1 ${t.fonts.mono}`, color: pct > 100 ? t.bad : t.fg2, textAlign: 'right' }}>{Math.round(pct)}%</span>
              </div>
            );
          })}
        </div>
      </VCard>
    );
  }

  // ─── Accounts list mini ────────────────────────────────────────────
  function AccountsList({ onGo }) {
    const t = window.theme;
    const d = window.VAULT_DATA;
    const total = d.accounts.reduce((sum, a) => sum + a.balance, 0);
    return (
      <VCard hoverable onClick={onGo}>
        <div style={{ display: 'flex', alignItems: 'center', marginBottom: 12 }}>
          <span style={{ font: `600 15px/1 ${t.fonts.display}`, color: t.fg }}>Cuentas</span>
          <span style={{ flex: 1 }} />
          <span style={{ font: `400 12px/1 ${t.fonts.body}`, color: t.fg3 }}>{d.accounts.length} activas</span>
        </div>
        <div style={{ marginBottom: 14, padding: '10px 12px', background: 'rgba(255,255,255,0.03)', borderRadius: 10 }}>
          <div style={{ font: `400 11px/1 ${t.fonts.mono}`, color: t.fg3, letterSpacing: '0.12em', textTransform: 'uppercase' }}>balance combinado</div>
          <div style={{ font: `600 22px/1 ${t.fonts.display}`, color: t.fg, marginTop: 6 }}>${total.toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}</div>
        </div>
        {d.accounts.map(a => {
          const debt = a.type === 'credit_card' || a.type === 'loan';
          return (
            <div key={a.id} style={{
              display: 'grid', gridTemplateColumns: '28px 1fr auto', gap: 10, alignItems: 'center',
              padding: '8px 0', borderTop: `1px solid ${t.card.border}`,
            }}>
              <span style={{
                width: 26, height: 26, borderRadius: 7,
                background: debt ? 'rgba(251,113,133,0.14)' : t.accent.soft,
                color: debt ? t.bad : t.accent.a,
                display: 'flex', alignItems: 'center', justifyContent: 'center',
                fontFamily: t.fonts.mono, fontSize: 11, fontWeight: 600,
              }}>{a.type === 'checking' ? 'CH' : a.type === 'savings' ? 'SV' : a.type === 'credit_card' ? 'CC' : '$'}</span>
              <div style={{ minWidth: 0 }}>
                <div style={{ font: `500 13px/1.2 ${t.fonts.body}`, color: t.fg, overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>{a.name}</div>
                <div style={{ font: `400 11px/1 ${t.fonts.body}`, color: t.fg3, marginTop: 3 }}>{a.bank || 'Efectivo'}</div>
              </div>
              <span style={{ font: `500 13px/1 ${t.fonts.mono}`, color: debt ? t.bad : t.fg }}>
                {debt ? '\u2212' : ''}${Math.abs(a.balance).toFixed(0)}
              </span>
            </div>
          );
        })}
      </VCard>
    );
  }

  // ─── Dashboard composition ─────────────────────────────────────────
  function Dashboard({ go }) {
    return (
      <div style={{ padding: '24px 32px 40px', display: 'grid', gap: 16 }}>
        {/* row 1 — net worth hero + AI insight */}
        <div style={{ display: 'grid', gridTemplateColumns: '1.7fr 1fr', gap: 16 }}>
          <HeroNetWorth />
          <InsightHero onSeeTransactions={() => go('transactions')} />
        </div>
        {/* row 2 — KPI tiles */}
        <KpiRow />
        {/* row 3 — chart + recent */}
        <div style={{ display: 'grid', gridTemplateColumns: '1.55fr 1fr', gap: 16 }}>
          <StatisticChart />
          <RecentTransactions
            onView={(id) => { go('transactions'); window.location.hash = 'transactions?id=' + id; }}
            onViewAll={() => go('transactions')} />
        </div>
        {/* row 4 — telegram + card + budget + accounts */}
        <div style={{ display: 'grid', gridTemplateColumns: '1.2fr 1fr 1fr 1fr', gap: 16, alignItems: 'stretch' }}>
          <TelegramCard onGo={() => go('automation')} />
          <CardVisualMini />
          <BudgetGlance onGo={() => go('budgets')} />
          <AccountsList onGo={() => go('accounts')} />
        </div>
      </div>
    );
  }

  function KpiRow() {
    const t = window.theme;
    const d = window.VAULT_DATA;
    return (
      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(4, 1fr)', gap: 16 }}>
        <KpiTile
          label="Ingresos · enero"
          value={<>$4,200<span style={{ color: t.fg3, fontSize: 18 }}>.00</span></>}
          trend="↗ +0% MoM · estable"
          trendTone="neutral"
          sub="Salario · 1 depósito"
          chart={<VMiniBars data={[3800, 4200, 4200, 4450, 4200, 5800, 4200]} color={t.accent.a} width={100} height={48} />}
        />
        <KpiTile
          label="Gastos · enero"
          value={<>$2,340<span style={{ color: t.fg3, fontSize: 18 }}>.50</span></>}
          trend="↗ +7.4% MoM"
          trendTone="warn"
          sub="63 transacciones · 8 días"
          chart={<VMiniBars data={[2050, 2320, 2180, 2890, 3450, 2340]} color={t.bad} width={100} height={48} />}
        />
        <KpiTile
          label="Ahorro · enero"
          value={<>$1,859<span style={{ color: t.fg3, fontSize: 18 }}>.50</span></>}
          trend="↗ best since aug"
          trendTone="good"
          sub="44.3% de los ingresos"
          chart={<VSpark data={[42, 39, 41, 31, 28, 44.3]} color={t.good} width={100} height={48} fill />}
        />
        <KpiTile
          label="Pace diario"
          value={<>$73<span style={{ color: t.fg3, fontSize: 18 }}>.14</span></>}
          trend="↗ target $57.43/d"
          trendTone="warn"
          sub="Para volver a meta: −$15.71/d"
          chart={<VSpark data={[60, 55, 70, 65, 80, 90, 73]} color={t.warn} width={100} height={48} />}
        />
      </div>
    );
  }

  window.VaultDashboard = Dashboard;
})();
