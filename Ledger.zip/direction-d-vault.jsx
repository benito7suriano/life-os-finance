// Direction D — Vault
// Modern dark fintech. Deep navy, soft glassy cards, an iridescent card visual,
// violet/lavender accent, layered chart curves. Inspired by the user's reference.

const D = {
  bg:      '#0b0d18',
  bg2:     '#11132140',
  card:    '#161a2b',       // panel surface
  card2:   '#1b1f33',
  border:  'rgba(255,255,255,0.06)',
  border2: 'rgba(255,255,255,0.1)',
  fg:      '#f1f0f5',
  fg2:     '#a5a3b8',
  fg3:     '#6e6c83',
  accent:  '#a78bfa',       // lavender
  accent2: '#7c5cff',       // violet
  good:    '#4ade80',
  bad:     '#fb7185',
  warn:    '#fbbf24',
  cyan:    '#67e8f9',
};

const dFonts = {
  display: '"Geist", "Inter", system-ui, sans-serif',
  body:    '"Geist", "Inter", system-ui, sans-serif',
  mono:    '"JetBrains Mono", ui-monospace, monospace',
};

function dFmt(n, { sign=false, decimals=2 } = {}) {
  const abs = Math.abs(n).toLocaleString('en-US', { minimumFractionDigits: decimals, maximumFractionDigits: decimals });
  if (sign && n > 0) return '+$' + abs;
  if (n < 0) return '\u2212$' + abs;
  return '$' + abs;
}

// Glassy card wrapper
function DCard({ children, style={}, pad=22 }) {
  return (
    <div style={{
      background: `linear-gradient(180deg, rgba(255,255,255,0.025), rgba(255,255,255,0)) , ${D.card}`,
      border: `1px solid ${D.border}`,
      borderRadius: 18,
      padding: pad,
      boxShadow: '0 1px 0 rgba(255,255,255,0.04) inset, 0 20px 40px -28px rgba(0,0,0,0.6)',
      position: 'relative',
      overflow: 'hidden',
      ...style,
    }}>{children}</div>
  );
}

// Multi-line layered chart (the "Statistic" reference)
function DLayeredChart({ width=640, height=210 }) {
  // Two contrasting curves over the last year, plus a softer base curve
  const series = [
    { color: D.accent,  data: [22, 30, 26, 38, 30, 44, 36, 52, 42, 56, 48, 64], label: 'Income' },
    { color: D.cyan,    data: [15, 22, 18, 24, 28, 20, 30, 26, 36, 28, 40, 30], label: 'Spend' },
    { color: '#4b3f7f', data: [10, 14, 12, 18, 16, 22, 18, 28, 22, 30, 26, 34], label: 'Saved' },
  ];
  const padX = 32, padY = 16;
  const max = Math.max(...series.flatMap(s => s.data));
  const xs = series[0].data.map((_, i) => padX + (i * (width - padX*2)) / (series[0].data.length - 1));

  const linePath = (data) => {
    const ys = data.map(v => height - padY - (v / max) * (height - padY*2 - 16));
    // smooth via simple cubic Bezier between points
    let p = `M ${xs[0]} ${ys[0]}`;
    for (let i = 1; i < xs.length; i++) {
      const cx1 = (xs[i-1] + xs[i]) / 2;
      const cx2 = (xs[i-1] + xs[i]) / 2;
      p += ` C ${cx1} ${ys[i-1]}, ${cx2} ${ys[i]}, ${xs[i]} ${ys[i]}`;
    }
    return p;
  };

  const months = ['Feb','Mar','Apr','May','Jun','Jul','Aug','Sep','Oct','Nov','Dec','Jan'];
  // highlight point on Income at index 9 (Nov)
  const hiIdx = 9;
  const hiX = xs[hiIdx];
  const hiY = height - padY - (series[0].data[hiIdx] / max) * (height - padY*2 - 16);

  return (
    <svg viewBox={`0 0 ${width} ${height + 24}`} style={{ width: '100%', height: 'auto', display: 'block' }}>
      <defs>
        <linearGradient id="d-line-grad" x1="0" y1="0" x2="1" y2="0">
          <stop offset="0%"  stopColor={D.accent}  stopOpacity="0.4" />
          <stop offset="100%" stopColor={D.accent} stopOpacity="1" />
        </linearGradient>
        <filter id="d-glow" x="-30%" y="-30%" width="160%" height="160%">
          <feGaussianBlur stdDeviation="3" />
          <feMerge><feMergeNode /><feMergeNode in="SourceGraphic" /></feMerge>
        </filter>
      </defs>
      {/* horizontal gridlines */}
      {[0,1,2,3,4].map(i => {
        const y = padY + (i * (height - padY*2 - 16)) / 4;
        return (
          <line key={i} x1={padX} x2={width-padX} y1={y} y2={y}
            stroke="rgba(255,255,255,0.04)" />
        );
      })}
      {/* vertical guide on highlighted point */}
      <line x1={hiX} x2={hiX} y1={padY} y2={height - padY} stroke="rgba(167,139,250,0.18)" strokeDasharray="3 3" />

      {series.map((s, i) => (
        <path key={i}
          d={linePath(s.data)}
          stroke={i === 0 ? 'url(#d-line-grad)' : s.color}
          strokeWidth={i === 0 ? 2.5 : 1.5}
          strokeOpacity={i === 0 ? 1 : 0.6}
          fill="none"
          filter={i === 0 ? 'url(#d-glow)' : undefined}
        />
      ))}

      {/* highlight dot + tooltip-ish chip */}
      <circle cx={hiX} cy={hiY} r={5} fill={D.bg} stroke={D.accent} strokeWidth="2" />
      <g transform={`translate(${hiX - 36}, ${hiY - 36})`}>
        <rect x="0" y="0" width="72" height="24" rx="6" fill="#1b1f33" stroke={D.border2} />
        <text x="36" y="16" fill={D.fg} fontSize="11" fontFamily={dFonts.mono} textAnchor="middle">$4,200</text>
      </g>

      {/* month labels */}
      {xs.map((x, i) => (
        <text key={i} x={x} y={height + 14} fill={D.fg3} fontSize="10" fontFamily={dFonts.body} textAnchor="middle">{months[i]}</text>
      ))}
    </svg>
  );
}

// Mini sparkline for KPI cards
function DMiniLine({ data, color, width=120, height=40 }) {
  const min = Math.min(...data), max = Math.max(...data);
  const xs = data.map((_, i) => (i * width) / (data.length - 1));
  const ys = data.map(v => height - 4 - ((v - min) / (max - min || 1)) * (height - 10));
  let p = `M ${xs[0]} ${ys[0]}`;
  for (let i = 1; i < xs.length; i++) {
    const cx = (xs[i-1] + xs[i]) / 2;
    p += ` C ${cx} ${ys[i-1]}, ${cx} ${ys[i]}, ${xs[i]} ${ys[i]}`;
  }
  return (
    <svg viewBox={`0 0 ${width} ${height}`} style={{ width, height, display: 'block' }}>
      <path d={p} stroke={color} strokeWidth="1.6" fill="none" />
    </svg>
  );
}

function DMiniBars({ data, color, width=120, height=40 }) {
  const max = Math.max(...data);
  const bw = (width - (data.length - 1) * 3) / data.length;
  return (
    <svg viewBox={`0 0 ${width} ${height}`} style={{ width, height, display: 'block' }}>
      {data.map((v, i) => {
        const h = (v / max) * (height - 4);
        return <rect key={i} x={i * (bw + 3)} y={height - h} width={bw} height={h} rx="2" fill={color} opacity={i === data.length - 1 ? 1 : 0.45} />;
      })}
    </svg>
  );
}

// The iridescent credit card
function DCardVisual() {
  return (
    <div style={{
      width: '100%', aspectRatio: '1.6/1', borderRadius: 18,
      position: 'relative', overflow: 'hidden',
      background: `
        radial-gradient(120% 100% at 0% 0%, rgba(255,255,255,0.4), transparent 50%),
        radial-gradient(120% 100% at 100% 100%, rgba(167,139,250,0.4), transparent 60%),
        linear-gradient(135deg, #4d3a8c 0%, #8a6dd6 35%, #c9b6f0 55%, #6b4ec9 80%, #2d1f5c 100%)
      `,
      boxShadow: '0 30px 60px -30px rgba(124,92,255,0.5), inset 0 1px 0 rgba(255,255,255,0.3)',
      color: '#fff',
      padding: 22,
      boxSizing: 'border-box',
      fontFamily: dFonts.body,
    }}>
      {/* holographic streaks */}
      <div style={{
        position: 'absolute', inset: 0,
        backgroundImage: 'repeating-linear-gradient(115deg, rgba(255,255,255,0.07) 0 2px, transparent 2px 14px)',
        mixBlendMode: 'overlay',
      }} />
      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', position: 'relative' }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
          <span style={{
            width: 26, height: 26, borderRadius: 6,
            background: 'rgba(255,255,255,0.25)',
            display: 'inline-flex', alignItems: 'center', justifyContent: 'center',
            fontWeight: 700, fontSize: 14,
          }}>L</span>
          <span style={{ fontWeight: 600, fontSize: 14, letterSpacing: '0.02em' }}>Ledger · BAC</span>
        </div>
        {/* contactless icon */}
        <svg width="20" height="22" viewBox="0 0 20 22" fill="none">
          <path d="M5 5 C 9 8, 9 14, 5 17" stroke="rgba(255,255,255,0.6)" strokeWidth="1.5" />
          <path d="M9 3 C 15 7, 15 15, 9 19" stroke="rgba(255,255,255,0.5)" strokeWidth="1.5" />
          <path d="M13 1 C 21 6, 21 16, 13 21" stroke="rgba(255,255,255,0.3)" strokeWidth="1.5" />
        </svg>
      </div>

      {/* EMV chip */}
      <div style={{
        marginTop: 32,
        width: 42, height: 32, borderRadius: 6,
        background: 'linear-gradient(135deg, #ffd76b, #b48623)',
        position: 'relative',
      }}>
        <div style={{ position: 'absolute', inset: 4, border: '1px solid rgba(0,0,0,0.25)', borderRadius: 4,
          backgroundImage: 'linear-gradient(0deg, rgba(0,0,0,0.2) 1px, transparent 1px), linear-gradient(90deg, rgba(0,0,0,0.2) 1px, transparent 1px)',
          backgroundSize: '8px 8px' }} />
      </div>

      <div style={{
        position: 'absolute', left: 22, bottom: 56,
        fontFamily: dFonts.mono, fontSize: 16, letterSpacing: '0.18em',
      }}>
        4218 5673 21•• ••12
      </div>
      <div style={{ position: 'absolute', left: 22, bottom: 22, display: 'flex', gap: 26 }}>
        <div>
          <div style={{ fontSize: 9, opacity: 0.6, letterSpacing: '0.14em', textTransform: 'uppercase' }}>Holder</div>
          <div style={{ fontSize: 12, fontWeight: 500, marginTop: 2 }}>Carlos Mendoza</div>
        </div>
        <div>
          <div style={{ fontSize: 9, opacity: 0.6, letterSpacing: '0.14em', textTransform: 'uppercase' }}>Valid</div>
          <div style={{ fontSize: 12, fontWeight: 500, marginTop: 2 }}>09/28</div>
        </div>
      </div>

      {/* network mark */}
      <div style={{ position: 'absolute', right: 22, bottom: 18, display: 'flex' }}>
        <span style={{ width: 22, height: 22, borderRadius: '50%', background: '#eb001b', opacity: 0.85 }} />
        <span style={{ width: 22, height: 22, borderRadius: '50%', background: '#f79e1b', marginLeft: -8, opacity: 0.85, mixBlendMode: 'screen' }} />
      </div>
    </div>
  );
}

function ModernVault() {
  const d = window.LEDGER_DATA;
  return (
    <div style={{
      width: '100%', minHeight: '100%',
      background: `
        radial-gradient(60% 50% at 15% 0%, rgba(124,92,255,0.12), transparent 60%),
        radial-gradient(50% 40% at 95% 30%, rgba(103,232,249,0.06), transparent 60%),
        ${D.bg}
      `,
      color: D.fg,
      font: `400 14px/1.55 ${dFonts.body}`,
      display: 'grid',
      gridTemplateColumns: '88px 1fr',
      boxSizing: 'border-box',
    }}>
      {/* ─────── sidebar ─────── */}
      <aside style={{
        background: 'rgba(255,255,255,0.02)',
        borderRight: `1px solid ${D.border}`,
        padding: '22px 0',
        display: 'flex', flexDirection: 'column', alignItems: 'center', gap: 6,
      }}>
        {/* logo */}
        <div style={{
          width: 44, height: 44, borderRadius: 14,
          background: `linear-gradient(135deg, ${D.accent2}, ${D.accent})`,
          display: 'flex', alignItems: 'center', justifyContent: 'center',
          color: '#fff', fontWeight: 700, fontSize: 18, letterSpacing: '0.05em',
          marginBottom: 24,
          boxShadow: '0 8px 24px -8px rgba(124,92,255,0.7)',
        }}>L</div>
        {[
          { name: 'Dashboard', icon: 'M3 12l9-9 9 9v9a2 2 0 0 1-2 2h-3v-7H8v7H5a2 2 0 0 1-2-2v-9z', active: true },
          { name: 'Wallet',    icon: 'M3 7h15v3H21v6h-3v3H3V7zm15 5h2v2h-2v-2z' },
          { name: 'Analytics', icon: 'M3 20V8m6 12V4m6 16v-8m6 8V12' },
          { name: 'Txns',      icon: 'M7 7h14m-4-4 4 4-4 4m0 6H3m4 4-4-4 4-4' },
          { name: 'Auto',      icon: 'M11.99 2 4.5 14h6.5v8l7.5-12h-6.5V2z' },
          { name: 'Account',   icon: 'M12 12a4 4 0 1 0 0-8 4 4 0 0 0 0 8zm0 2c-4.42 0-8 2.24-8 5v3h16v-3c0-2.76-3.58-5-8-5z' },
        ].map(item => (
          <button key={item.name} style={{
            width: 52, height: 52, borderRadius: 14, border: 'none',
            background: item.active ? 'rgba(167,139,250,0.16)' : 'transparent',
            color: item.active ? D.accent : D.fg3,
            display: 'flex', alignItems: 'center', justifyContent: 'center',
            cursor: 'pointer',
            position: 'relative',
          }} title={item.name}>
            <svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round">
              <path d={item.icon} />
            </svg>
            {item.active && <span style={{ position: 'absolute', left: -3, top: '50%', transform: 'translateY(-50%)', width: 3, height: 22, background: D.accent, borderRadius: 2 }} />}
          </button>
        ))}
        <div style={{ flex: 1 }} />
        <button style={{
          width: 52, height: 52, borderRadius: 14, border: 'none',
          background: 'transparent', color: D.fg3,
          display: 'flex', alignItems: 'center', justifyContent: 'center',
          cursor: 'pointer',
        }} title="Help">
          <svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round">
            <circle cx="12" cy="12" r="9" />
            <path d="M9.1 9a3 3 0 0 1 5.8 1c0 2-3 3-3 3M12 17h.01" />
          </svg>
        </button>
      </aside>

      {/* ─────── main ─────── */}
      <div style={{ padding: '24px 32px 32px' }}>
        {/* top bar */}
        <header style={{ display: 'flex', alignItems: 'center', gap: 14, marginBottom: 22 }}>
          <div style={{
            flex: 1, maxWidth: 420,
            background: 'rgba(255,255,255,0.04)',
            border: `1px solid ${D.border}`,
            borderRadius: 12, padding: '10px 14px',
            display: 'flex', alignItems: 'center', gap: 10,
            color: D.fg3,
          }}>
            <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><circle cx="11" cy="11" r="7" /><path d="m21 21-4.3-4.3" /></svg>
            <span>Search transactions, merchants, categories…</span>
            <span style={{ marginLeft: 'auto', fontFamily: dFonts.mono, fontSize: 11, padding: '2px 6px', border: `1px solid ${D.border2}`, borderRadius: 5 }}>⌘K</span>
          </div>
          <div style={{ flex: 1 }} />
          <button style={{
            background: 'rgba(255,255,255,0.04)', border: `1px solid ${D.border}`,
            color: D.fg, padding: '9px 14px', borderRadius: 12,
            font: `500 13px/1 ${dFonts.body}`, display: 'flex', alignItems: 'center', gap: 8,
          }}>
            <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><path d="M12 5v14m-7-7h14" /></svg>
            New transaction
          </button>
          <button style={{
            width: 40, height: 40, borderRadius: 12,
            background: 'rgba(255,255,255,0.04)', border: `1px solid ${D.border}`,
            color: D.fg2, display: 'flex', alignItems: 'center', justifyContent: 'center',
            position: 'relative',
          }}>
            <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><path d="M6 8a6 6 0 1 1 12 0c0 7 3 9 3 9H3s3-2 3-9M10 21a2 2 0 0 0 4 0" /></svg>
            <span style={{ position: 'absolute', top: 6, right: 7, width: 7, height: 7, borderRadius: '50%', background: D.accent2, boxShadow: `0 0 0 2px ${D.bg}` }} />
          </button>
          <div style={{
            width: 40, height: 40, borderRadius: 999,
            background: `linear-gradient(135deg, ${D.accent2}, ${D.accent})`,
            color: '#fff', display: 'flex', alignItems: 'center', justifyContent: 'center',
            fontWeight: 600, fontSize: 13,
          }}>CM</div>
        </header>

        {/* ───── row 1: card + income/expense + profile ───── */}
        <div style={{ display: 'grid', gridTemplateColumns: '1.05fr 1fr 0.9fr', gap: 18, marginBottom: 18 }}>
          {/* Cards panel */}
          <DCard>
            <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 14 }}>
              <span style={{ font: `500 14px/1 ${dFonts.body}`, color: D.fg }}>Cards</span>
              <span style={{ font: `500 12px/1 ${dFonts.body}`, color: D.accent, cursor: 'pointer' }}>See all →</span>
            </div>
            <DCardVisual />
            <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginTop: 14, gap: 10 }}>
              <div>
                <div style={{ font: `400 11px/1 ${dFonts.body}`, color: D.fg3, letterSpacing: '0.1em', textTransform: 'uppercase' }}>balance used</div>
                <div style={{ font: `500 18px/1.1 ${dFonts.mono}`, color: D.fg, marginTop: 4 }}>$1,420 <span style={{ color: D.fg3, fontSize: 13 }}>/ $5,000</span></div>
              </div>
              <div style={{ flex: 1, height: 6, background: 'rgba(255,255,255,0.05)', borderRadius: 3, overflow: 'hidden' }}>
                <div style={{ width: '28.4%', height: '100%', background: `linear-gradient(90deg, ${D.accent2}, ${D.accent})`, borderRadius: 3 }} />
              </div>
              <span style={{ font: `500 12px/1 ${dFonts.mono}`, color: D.accent }}>28%</span>
            </div>
          </DCard>

          {/* Income / Expenses */}
          <div style={{ display: 'grid', gridTemplateRows: '1fr 1fr', gap: 18 }}>
            <DCard>
              <div style={{ display: 'flex', justifyContent: 'space-between' }}>
                <div>
                  <div style={{ font: `400 12px/1 ${dFonts.body}`, color: D.fg3, marginBottom: 8 }}>Your income</div>
                  <div style={{ font: `500 30px/1 ${dFonts.display}`, color: D.fg, letterSpacing: '-0.01em' }}>$8,293<span style={{ color: D.fg3, fontSize: 16 }}>.00</span></div>
                  <div style={{ font: `500 12px/1 ${dFonts.mono}`, color: D.good, marginTop: 8 }}>↗ +12.4% vs last quarter</div>
                </div>
                <DMiniLine data={[40, 55, 50, 65, 60, 80, 72, 90]} color={D.good} width={140} height={56} />
              </div>
            </DCard>
            <DCard>
              <div style={{ display: 'flex', justifyContent: 'space-between' }}>
                <div>
                  <div style={{ font: `400 12px/1 ${dFonts.body}`, color: D.fg3, marginBottom: 8 }}>Your expenses · this week</div>
                  <div style={{ font: `500 30px/1 ${dFonts.display}`, color: D.fg, letterSpacing: '-0.01em' }}>$305<span style={{ color: D.fg3, fontSize: 16 }}>.42</span></div>
                  <div style={{ font: `500 12px/1 ${dFonts.mono}`, color: D.warn, marginTop: 8 }}>↗ +7.4% vs last week</div>
                </div>
                <DMiniBars data={[30, 45, 28, 55, 38, 62, 48]} color={D.accent} width={140} height={56} />
              </div>
            </DCard>
          </div>

          {/* Profile / Total balance */}
          <DCard pad={22}>
            <div style={{ display: 'flex', justifyContent: 'space-between' }}>
              <span style={{ font: `500 14px/1 ${dFonts.body}`, color: D.fg }}>Profile</span>
              <span style={{
                font: `500 10px/1 ${dFonts.mono}`, color: D.good, letterSpacing: '0.12em', textTransform: 'uppercase',
                padding: '4px 8px', borderRadius: 999, background: 'rgba(74,222,128,0.1)',
              }}>● synced</span>
            </div>
            <div style={{ display: 'flex', flexDirection: 'column', alignItems: 'center', marginTop: 14 }}>
              <div style={{
                width: 80, height: 80, borderRadius: '50%',
                background: `linear-gradient(135deg, ${D.accent2}, #ec4899)`,
                display: 'flex', alignItems: 'center', justifyContent: 'center',
                fontWeight: 600, fontSize: 28, color: '#fff',
                boxShadow: '0 0 0 4px rgba(167,139,250,0.18)',
              }}>CM</div>
              <div style={{ font: `400 13px/1 ${dFonts.body}`, color: D.fg2, marginTop: 12 }}>Carlos Mendoza</div>
              <div style={{ font: `400 11px/1 ${dFonts.mono}`, color: D.fg3, marginTop: 4 }}>net worth</div>
              <div style={{ font: `500 28px/1 ${dFonts.display}`, color: D.fg, marginTop: 6, letterSpacing: '-0.01em' }}>$12,450<span style={{ color: D.fg3, fontSize: 16 }}>.00</span></div>
              <div style={{ font: `500 12px/1 ${dFonts.mono}`, color: D.good, marginTop: 6 }}>+$310.50 (+2.56%) MoM</div>
            </div>
          </DCard>
        </div>

        {/* ───── row 2: big chart + transactions ───── */}
        <div style={{ display: 'grid', gridTemplateColumns: '1.55fr 1fr', gap: 18, marginBottom: 18 }}>
          <DCard pad={24}>
            <div style={{ display: 'flex', alignItems: 'center', marginBottom: 18 }}>
              <span style={{ font: `500 16px/1 ${dFonts.body}`, color: D.fg }}>Statistic</span>
              <div style={{ flex: 1 }} />
              {['All members', 'Category: Expenses ▾', 'Top week ▾'].map((t, i) => (
                <button key={t} style={{
                  marginLeft: 8,
                  padding: '6px 12px', borderRadius: 999,
                  background: i === 0 ? 'rgba(167,139,250,0.16)' : 'rgba(255,255,255,0.04)',
                  border: `1px solid ${i === 0 ? 'rgba(167,139,250,0.3)' : D.border}`,
                  color: i === 0 ? D.accent : D.fg2,
                  font: `500 11px/1 ${dFonts.body}`,
                }}>{t}</button>
              ))}
            </div>
            <DLayeredChart width={760} height={210} />
            <div style={{ display: 'flex', justifyContent: 'center', gap: 22, marginTop: 14 }}>
              {[
                { c: D.accent, l: 'Income' },
                { c: D.cyan, l: 'Spend' },
                { c: '#6e5fb0', l: 'Saved' },
              ].map(it => (
                <span key={it.l} style={{ display: 'inline-flex', alignItems: 'center', gap: 8, color: D.fg2, font: `500 12px/1 ${dFonts.body}` }}>
                  <span style={{ width: 10, height: 10, borderRadius: '50%', background: it.c }} />{it.l}
                </span>
              ))}
            </div>
          </DCard>

          <DCard>
            <div style={{ display: 'flex', alignItems: 'center', marginBottom: 14 }}>
              <span style={{ font: `500 16px/1 ${dFonts.body}`, color: D.fg }}>Transactions</span>
              <div style={{ flex: 1 }} />
              <span style={{ font: `500 12px/1 ${dFonts.body}`, color: D.accent, cursor: 'pointer' }}>View all →</span>
            </div>
            <div>
              {d.transactions.slice(0, 6).map((t, i) => {
                const isInc = t.amount > 0;
                return (
                  <div key={t.id} style={{
                    display: 'grid', gridTemplateColumns: '34px 1fr auto auto', gap: 12, alignItems: 'center',
                    padding: '12px 0',
                    borderTop: i === 0 ? 'none' : `1px solid ${D.border}`,
                  }}>
                    <span style={{
                      width: 30, height: 30, borderRadius: 8,
                      background: isInc ? 'rgba(74,222,128,0.12)' : 'rgba(167,139,250,0.12)',
                      color: isInc ? D.good : D.accent,
                      display: 'flex', alignItems: 'center', justifyContent: 'center',
                      fontFamily: dFonts.mono, fontSize: 13,
                    }}>{isInc ? '↗' : '↙'}</span>
                    <div>
                      <div style={{ font: `500 13px/1.2 ${dFonts.body}`, color: D.fg }}>{t.desc}</div>
                      <div style={{ font: `400 11px/1.3 ${dFonts.body}`, color: D.fg3, marginTop: 2 }}>{t.cat}</div>
                    </div>
                    <span style={{ font: `400 11px/1 ${dFonts.mono}`, color: D.fg3 }}>{t.date.slice(5).replace('-','/')}</span>
                    <span style={{
                      font: `500 13px/1 ${dFonts.mono}`,
                      color: isInc ? D.good : D.fg,
                      minWidth: 70, textAlign: 'right',
                    }}>{isInc ? '+' : '\u2212'}${Math.abs(t.amount).toFixed(2)}</span>
                  </div>
                );
              })}
            </div>
          </DCard>
        </div>

        {/* ───── row 3: AI insight + automation + accounts ───── */}
        <div style={{ display: 'grid', gridTemplateColumns: '1.4fr 1fr 1fr', gap: 18 }}>
          <DCard pad={24} style={{ background: `linear-gradient(135deg, rgba(167,139,250,0.16), rgba(124,92,255,0.06)), ${D.card}` }}>
            <div style={{ display: 'flex', alignItems: 'center', gap: 10, marginBottom: 16 }}>
              <span style={{
                width: 28, height: 28, borderRadius: 8,
                background: `linear-gradient(135deg, ${D.accent2}, ${D.accent})`,
                display: 'inline-flex', alignItems: 'center', justifyContent: 'center',
                color: '#fff', fontSize: 14,
              }}>✦</span>
              <span style={{ font: `500 10px/1 ${dFonts.mono}`, color: D.accent, letterSpacing: '0.18em', textTransform: 'uppercase' }}>AI Insight</span>
            </div>
            <div style={{ font: `500 22px/1.25 ${dFonts.display}`, color: D.fg, letterSpacing: '-0.012em' }}>
              You're on pace to overspend by <span style={{ color: D.accent }}>$312</span> this month.
            </div>
            <div style={{ font: `400 13px/1.55 ${dFonts.body}`, color: D.fg2, marginTop: 10 }}>
              Mostly Restaurantes and Uber Eats. Cutting two weekday delivery orders gets you back to neutral by Jan 31.
            </div>
            <div style={{ display: 'flex', gap: 8, marginTop: 16 }}>
              <button style={{
                padding: '9px 14px', borderRadius: 10,
                background: `linear-gradient(135deg, ${D.accent2}, ${D.accent})`,
                color: '#fff', border: 'none', font: `500 12px/1 ${dFonts.body}`,
              }}>Show me where</button>
              <button style={{
                padding: '9px 14px', borderRadius: 10,
                background: 'rgba(255,255,255,0.04)',
                color: D.fg, border: `1px solid ${D.border2}`, font: `500 12px/1 ${dFonts.body}`,
              }}>Dismiss</button>
            </div>
          </DCard>

          <DCard>
            <div style={{ display: 'flex', alignItems: 'center', marginBottom: 14 }}>
              <span style={{ font: `500 14px/1 ${dFonts.body}`, color: D.fg }}>Automation</span>
              <div style={{ flex: 1 }} />
              <span style={{ font: `500 10px/1 ${dFonts.mono}`, color: D.good, letterSpacing: '0.12em', textTransform: 'uppercase' }}>2 active</span>
            </div>
            <div style={{ font: `500 32px/1 ${dFonts.display}`, color: D.fg, letterSpacing: '-0.01em' }}>35<span style={{ color: D.fg3, fontSize: 20 }}> / 63</span></div>
            <div style={{ font: `400 12px/1 ${dFonts.body}`, color: D.fg2, marginTop: 6 }}>txns auto-captured this month</div>
            <div style={{ marginTop: 16, display: 'grid', gap: 8 }}>
              {[
                { name: 'WhatsApp', count: 24, last: '2m ago', color: '#25D366' },
                { name: 'Email', count: 11, last: '12m ago', color: D.accent },
              ].map(ch => (
                <div key={ch.name} style={{
                  display: 'flex', alignItems: 'center', gap: 10,
                  padding: '9px 12px',
                  background: 'rgba(255,255,255,0.03)',
                  borderRadius: 10,
                }}>
                  <span style={{ width: 8, height: 8, borderRadius: '50%', background: ch.color, boxShadow: `0 0 12px ${ch.color}` }} />
                  <span style={{ font: `500 13px/1 ${dFonts.body}`, color: D.fg }}>{ch.name}</span>
                  <span style={{ flex: 1 }} />
                  <span style={{ font: `500 13px/1 ${dFonts.mono}`, color: D.fg }}>{ch.count}</span>
                  <span style={{ font: `400 11px/1 ${dFonts.mono}`, color: D.fg3 }}>{ch.last}</span>
                </div>
              ))}
            </div>
          </DCard>

          <DCard>
            <div style={{ display: 'flex', alignItems: 'center', marginBottom: 14 }}>
              <span style={{ font: `500 14px/1 ${dFonts.body}`, color: D.fg }}>Accounts</span>
              <div style={{ flex: 1 }} />
              <span style={{ font: `500 12px/1 ${dFonts.body}`, color: D.accent, cursor: 'pointer' }}>Manage →</span>
            </div>
            <div style={{ display: 'grid', gap: 10 }}>
              {d.accounts.map(a => {
                const debt = a.type === 'credit_card' || a.type === 'loan';
                return (
                  <div key={a.id} style={{
                    display: 'grid', gridTemplateColumns: '28px 1fr auto', gap: 12, alignItems: 'center',
                    padding: '9px 12px',
                    background: 'rgba(255,255,255,0.03)',
                    borderRadius: 10,
                  }}>
                    <span style={{
                      width: 28, height: 28, borderRadius: 8,
                      background: debt ? 'rgba(251,113,133,0.14)' : 'rgba(167,139,250,0.14)',
                      color: debt ? D.bad : D.accent,
                      display: 'flex', alignItems: 'center', justifyContent: 'center',
                      fontFamily: dFonts.mono, fontSize: 12, fontWeight: 600,
                    }}>{a.type === 'checking' ? 'CH' : a.type === 'savings' ? 'SV' : a.type === 'credit_card' ? 'CC' : 'C$'}</span>
                    <div>
                      <div style={{ font: `500 13px/1.2 ${dFonts.body}`, color: D.fg }}>{a.name}</div>
                      <div style={{ font: `400 11px/1 ${dFonts.body}`, color: D.fg3, marginTop: 3 }}>{a.bank || 'Efectivo'}</div>
                    </div>
                    <span style={{
                      font: `500 13px/1 ${dFonts.mono}`,
                      color: debt ? D.bad : D.fg,
                    }}>{debt ? '\u2212' : ''}${Math.abs(a.balance).toFixed(0)}</span>
                  </div>
                );
              })}
            </div>
          </DCard>
        </div>
      </div>
    </div>
  );
}

window.ModernVault = ModernVault;
